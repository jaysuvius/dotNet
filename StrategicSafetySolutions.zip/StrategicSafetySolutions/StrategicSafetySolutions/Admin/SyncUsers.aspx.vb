﻿Public Partial Class SyncUsers
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub SyncButton_Click(ByVal sender As Object, ByVal e As EventArgs) Handles SyncButton.Click
        Dim DQFUserDataAdapter As New UserDataTableAdapters.DQFUsersTableAdapter
        Dim DQFUT As New UserData.DQFUsersDataTable
        Dim WSUsersToCompsTA As New UserDataTableAdapters.WSUsersToCompaniesTableAdapter
        Dim wsudt As New UserData.WSUsersToCompaniesDataTable


        DQFUserDataAdapter.FillBySyncUsers(DQFUT)



        For Each dr As DataRow In DQFUT.Rows
            Dim u As MembershipUserCollection
            u = Membership.FindUsersByName(dr("DF_UR_LOGIN"))
            If u.Count > 0 Then
                Membership.DeleteUser(dr("DF_UR_LOGIN"), True)
            End If
            Dim pword As String
            If Len(dr("DF_UR_PASSWORD")) < 5 Then
                pword = "P@$$w0rd"
            Else
                pword = dr("DF_UR_PASSWORD") & "@1"
            End If
            Dim email As String = dr("DF_UR_EMAIL").ToString
            If dr("DF_UR_EMAIL").ToString = String.Empty Then
                email = "No Email Supplied"
            Else
                email = dr("DF_UR_EMAIL").ToString
            End If
            Try
                Dim us As MembershipUser = Membership.CreateUser(dr("DF_UR_LOGIN"), pword, email)
                If us IsNot Nothing Then
                    Membership.UpdateUser(us)
                    If Not Roles.IsUserInRole(dr("DF_UR_LOGIN"), "User") Then
                        Roles.AddUserToRole(dr("DF_UR_LOGIN"), "User")
                    End If

                    WSUsersToCompsTA.FillByWSUName(wsudt, dr("DF_UR_LOGIN"))

                    If wsudt.Rows.Count > 0 Then
                        Dim CompExists As Boolean = False
                        For Each dr2 As DataRow In wsudt.Rows
                            If dr2("DQFCompanyID") = dr("DF_UR_DF_CR_ID") Then
                                CompExists = True
                            End If
                        Next
                        If Not CompExists Then
                            WSUsersToCompsTA.InsertSyncUser(Guid.NewGuid, dr("DF_UR_LOGIN"), dr("DF_UR_DF_CR_ID"), dr("DF_UR_ID"))
                        End If
                    Else
                        WSUsersToCompsTA.InsertSyncUser(Guid.NewGuid, dr("DF_UR_LOGIN"), dr("DF_UR_DF_CR_ID"), dr("DF_UR_ID"))
                    End If
                End If
            Catch ex As Exception

            End Try

        Next
        Label4.Visible = True

    End Sub
End Class