﻿Partial Public Class ManageUsers
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Me.LookupDQFUserID.Visible = False
            GridView1.DataBind()
        End If
    End Sub

    Public Sub GetUser(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName = "GetUser" Then
            Me.UserDataPanel.Visible = True
            Me.UserGridPanel.Visible = False
            Dim u As MembershipUserCollection
            u = Membership.FindUsersByName(GridView1.Rows(e.CommandArgument).Cells(1).Text)
            If u.Count = 1 Then
                Dim us As MembershipUser
                us = u(GridView1.Rows(e.CommandArgument).Cells(1).Text)
                UserNameTextBox.Text = us.UserName
                Session("UserName") = us.UserName
                EmailAddressTextBox.Text = us.Email
                CommentTextBox.Text = us.Comment
                ApprovedCheckBox.Checked = us.IsApproved
                Dim WSUsersToCompaniesTableAdapter As New UserDataTableAdapters.WSUsersToCompaniesTableAdapter
                Dim dt As DataTable = WSUsersToCompaniesTableAdapter.GetDataByWSUName(us.UserName)
                Dim dr As DataRow
                If dt.Rows.Count > 0 Then
                    dr = dt.Rows(0)
                    '        CompanyIDTextBox.Text = dr("DQFCompanyID")
                    Session("UserID") = dr("DQFUserID")
                End If
            End If
        End If
    End Sub

    'Private Sub LookupUserButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LookupUserButton.Click
    '    DQFUserGridview.DataSourceID = "ObjectDataSource1"
    '    DQFUserGridview.DataBind()
    '    Me.LookupDQFUserID.Visible = True
    'End Sub

    'Private Sub FilterButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FilterButton1.Click


    'End Sub

    Private Sub DQFUserGridview_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles DQFUserGridview.PageIndexChanging
        DQFUserGridview.PageIndex = e.NewPageIndex
        DQFUserGridview.DataSource = Session("DQFGridView_Datasource")
        DQFUserGridview.DataBind()
    End Sub

    Private Sub DQFUserGridview_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles DQFUserGridview.Sorting
        Dim dt As DataTable = Session("DQFGridView_Datasource")

        If dt IsNot Nothing Then
            Dim dv As New DataView(dt)
            dv.Sort = e.SortExpression & " " & ConvertSortDirectionToSQL(e.SortDirection)
            DQFUserGridview.DataSource = dv
            DQFUserGridview.DataBind()
        End If
    End Sub

    Private Function ConvertSortDirectionToSQL(ByVal sd As SortDirection) As String
        Dim NewSortDirection As String = String.Empty
        Select Case sd
            Case SortDirection.Ascending
                NewSortDirection = "ASC"
                Exit Select
            Case SortDirection.Descending
                NewSortDirection = "DESC"
                Exit Select
        End Select
        Return NewSortDirection
    End Function

    Public Sub GetUserAndCorpID(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName = "SelectUser" Then
            'Me.UserIDTextBox.Text = DQFUserGridview.Rows(e.CommandArgument).Cells(1).Text
            'Me.CompanyIDTextBox.Text = DQFUserGridview.Rows(e.CommandArgument).Cells(7).Text
            'Me.LookupDQFUserID.Visible = False
        End If
    End Sub

    'Private Sub LookupCompanyButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LookupCompanyButton.Click
    '    Me.LookupDQFUserID.Visible = True
    'End Sub


    Private Sub SaveButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveButton.Click
        Dim u As MembershipUserCollection
        u = Membership.FindUsersByName(UserNameTextBox.Text)
        If u.Count = 1 Then
            Dim us As MembershipUser
            us = u(UserNameTextBox.Text)
            us.Email = EmailAddressTextBox.Text
            us.Comment = CommentTextBox.Text
            us.IsApproved = ApprovedCheckBox.Checked
            Membership.UpdateUser(us)
            Dim WSUsersToCompaniesTableAdapter As New UserDataTableAdapters.WSUsersToCompaniesTableAdapter
            Dim dt As DataTable = WSUsersToCompaniesTableAdapter.GetDataByWSUName(us.UserName)
            Dim dr As DataRow
            If dt.Rows.Count > 0 Then
                dr = dt.Rows(0)
                dr("DQFUserID") = Session("UserID")
                WSUsersToCompaniesTableAdapter.Update(dt)
            Else
                WSUsersToCompaniesTableAdapter.Insert(Guid.NewGuid, us.UserName, Session("UserID"))
            End If
        End If
        Me.UserDataPanel.Visible = False
        Me.UserGridPanel.Visible = True
        Me.LookupDQFUserID.Visible = False
    End Sub

    Private Sub CancelButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancelButton.Click
        Me.UserDataPanel.Visible = False
        Me.UserGridPanel.Visible = True
        Me.LookupDQFUserID.Visible = False
    End Sub

    Private Sub DeleteButon_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles DeleteButon.Click
        Try
            Membership.DeleteUser(UserNameTextBox.Text)
            Dim DeleteUserAdapter As New UserDataTableAdapters.WSUsersToCompaniesTableAdapter
            DeleteUserAdapter.DeleteUser(UserNameTextBox.Text)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ApplyASPFilterButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ApplyASPFilterButton.Click
        Dim LoginFilter As Object = Nothing
        Dim LastNameFilter As Object = Nothing
        Dim FirstNameFilter As Object = Nothing
        Dim CorpNameFilter As Object = Nothing
        Dim NoFilter As Boolean = True

        If ASPLoginFilterTextBox.Text.Length > 0 Then
            LoginFilter = Me.ASPLoginFilterTextBox.Text
            Me.UserNameField.Value = ASPLoginFilterTextBox.Text
            NoFilter = False

        End If
        If ASPLastNameFilterTextBox.Text.Length > 0 Then
            LastNameFilter = Me.ASPLastNameFilterTextBox.Text
            NoFilter = False
            Me.LastNameField.Value = Me.ASPLastNameFilterTextBox.Text
        End If
        If ASPFirstNameFilterTextBox.Text.Length > 0 Then
            FirstNameFilter = Me.ASPFirstNameFilterTextBox.Text
            NoFilter = False
            Me.FirstNameField.Value = Me.ASPFirstNameFilterTextBox.Text
        End If

        If NoFilter Then
            GridView1.DataSourceID = "ObjectDataSource2"
            GridView1.DataBind()
            'DQFUserGridview.DataBind()
        Else
            'GridView1.DataSourceID = "ObjectDataSource3"
            'GridView1.DataBind()
            Dim UserTableAdapter As New UserDataTableAdapters.MembershipUsersTableAdapter
            GridView1.DataSourceID = ""
            GridView1.DataSource = UserTableAdapter.GetDataByFilters(LoginFilter, FirstNameFilter, LastNameFilter)
            GridView1.DataBind()
        End If

        Session("DQFGridView_Datasource2") = DQFUserGridview.DataSource

    End Sub

    Private Sub FilterButton_Click1(ByVal sender As Object, ByVal e As System.EventArgs) Handles FilterButton.Click
        Dim UserIDFilter As Object = Nothing
        Dim LoginFilter As Object = Nothing
        Dim LastNameFilter As Object = Nothing
        Dim FirstNameFilter As Object = Nothing
        Dim CorpNameFilter As Object = Nothing
        Dim NoFilter As Boolean = True

        If UserIDFilterTextBox.Text.Length > 0 Then
            UserIDFilter = CInt(Me.UserIDFilterTextBox.Text)
            NoFilter = False
        End If
        If LoginFilterTextBox.Text.Length > 0 Then
            LoginFilter = Me.LoginFilterTextBox.Text
            NoFilter = False

        End If
        If LastNameFilterTextBox.Text.Length > 0 Then
            LastNameFilter = Me.LastNameFilterTextBox.Text
            NoFilter = False

        End If
        If FirstNameFilterTextBox.Text.Length > 0 Then
            FirstNameFilter = Me.FirstNameFilterTextBox.Text
            NoFilter = False

        End If
        If CorpFilterTextBox.Text.Length > 0 Then
            CorpNameFilter = CorpFilterTextBox.Text
            NoFilter = False

        End If


        If NoFilter Then
            DQFUserGridview.DataSourceID = "ObjectDataSource1"
            DQFUserGridview.DataBind()
            Dim UserTableAdapter As New UserDataTableAdapters.DQFUsersTableAdapter
            DQFUserGridview.DataSourceID = ""
            DQFUserGridview.DataSource = UserTableAdapter.GetDataByFilters(UserIDFilter, LoginFilter, LastNameFilter, FirstNameFilter, CorpNameFilter)
            DQFUserGridview.DataBind()
        End If

        Session("DQFGridView_Datasource") = DQFUserGridview.DataSource
    End Sub

    Private Sub ManageCompaniesButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ManageCompaniesButton.Click
        Server.Transfer("ManageCompanies.aspx")
    End Sub
End Class