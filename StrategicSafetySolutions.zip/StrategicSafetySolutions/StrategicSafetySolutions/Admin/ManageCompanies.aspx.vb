﻿Public Partial Class ManageCompanies
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.UserIDHiddenField.Value = Session("UserID")
    End Sub

    Protected Sub AddCompanyButton_Click(ByVal sender As Object, ByVal e As EventArgs) Handles AddCompanyButton.Click
        Me.CompanyPanel.Visible = False
        Me.AddCompanyPanel.Visible = True
    End Sub

    Private Sub CancelButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancelButton.Click
        GridView2.DataSourceID = "ObjectDataSource2"
        GridView2.DataBind()
        Me.CompanyPanel.Visible = True
        Me.AddCompanyPanel.Visible = False
    End Sub

    Public Sub DeleteCompany(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName = "DeleteCompany" Then
            Dim RowID As New Guid(GridView1.Rows(e.CommandArgument).Cells(3).Text)
            Dim WSUsersToCompaniesAdapter As New UserDataTableAdapters.WSUsersToCompaniesTableAdapter
            If RowID.ToString <> "" Then
                WSUsersToCompaniesAdapter.UnlinkCompany(RowID)
            End If
            GridView1.DataBind()
        End If
    End Sub

    Public Sub AddCompany(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName = "SelectCompany" Then
            Dim WSUsersToCompaniesAdapter As New UserDataTableAdapters.WSUsersToCompaniesTableAdapter
            WSUsersToCompaniesAdapter.LinkCompany(Guid.NewGuid, Session("UserName"), GridView2.Rows(e.CommandArgument).Cells(1).Text, Session("UserID"))
            GridView1.DataBind()
            Me.CompanyPanel.Visible = True
            Me.AddCompanyPanel.Visible = False
        End If
    End Sub

    Private Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        For Each r As GridViewRow In GridView1.Rows
            r.Cells(3).Visible = False
        Next
    End Sub

    Private Sub ApplyFilterButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ApplyFilterButton.Click
        Session("CompanyName") = Me.CompanyFilterTextBox.Text
        GridView2.DataSourceID = "ObjectDataSource3"
        GridView2.DataBind()
    End Sub

    Private Sub ShowAllButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ShowAllButton.Click
        GridView2.DataSourceID = "ObjectDataSource2"
        GridView2.DataBind()
    End Sub
End Class