﻿Public Partial Class InspectionDetail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            PopulateForm()
        End If
    End Sub

    Private Sub PopulateForm()
        Dim IAdapter As New TruckFleetTableAdapters.FleetInspectionTableAdapter
        Dim ITable As New TruckFleet.FleetInspectionDataTable

        If Session("InspectionID") IsNot Nothing Then

            IAdapter.FillByInspectionID(ITable, Session("InspectionID"))

            If ITable.Rows.Count > 0 Then
                Dim dr As DataRow = ITable.Rows(0)

                If dr("InspectionResult").ToString.ToUpper = "PASSED" Then
                    Me.ResultRadioButtonList.SelectedValue = "Passed"
                Else
                    Me.ResultRadioButtonList.SelectedValue = "Failed"
                End If

                InspectionDateTextBox.Text = dr("InspectionDate")
                InspectionCompanyTextBox.Text = dr("InspectorCompany")
                InspectorNameTextBox.Text = dr("InspectorName")
                InspectorNumberTextBox.Text = dr("InspectorNumber")
                InspectionFormNumberTextBox.Text = dr("InspectionFormNumber")
                InspectionFormExpirationDateTextBox.Text = dr("ExpirationDate")
                BITDateTextBox.Text = dr("InspectionDate1")
                ShopNotesTextBox.Text = dr("InspectionShopNotes")
            End If

        End If


    End Sub

    Private Sub BackButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BackButton.Click
        Server.Transfer("FleetDetail.aspx")
    End Sub

    Private Sub CancelButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancelButton.Click
        Server.Transfer("FleetDetail.aspx")
    End Sub

    Private Sub SaveButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveButton.Click
        Dim IAdapter As New TruckFleetTableAdapters.FleetInspectionTableAdapter
        Dim ITable As New TruckFleet.FleetInspectionDataTable
        Dim InspectionResult As Object = Nothing
        Dim InspectionDate As Object = Nothing
        Dim InspectionCompany As Object = Nothing
        Dim InspectorName As Object = Nothing
        Dim InspectorNumber As Object = Nothing
        Dim InspectionFormExpirationDate As Object = Nothing
        Dim InspectionFormNumber As Object = Nothing
        Dim BitDate As Object = Nothing
        Dim ShopNotes As Object = Nothing
        Dim ErrorMessage As String = String.Empty

        IAdapter.FillByInspectionID(ITable, Session("InspectionID"))

        If Me.ResultRadioButtonList.SelectedValue = "Passed" Then
            InspectionResult = "Passed"
        Else
            InspectionResult = "Failed"
        End If
        If IsDate(InspectionDateTextBox.Text) Then
            InspectionDate = CDate(InspectionDateTextBox.Text)
        Else
            If InspectionDateTextBox.Text.Length > 0 Then
                ErrorMessage = ErrorMessage & "InspectionDate is not a valid date"
            End If
        End If
        If InspectionCompanyTextBox.Text.Length > 0 Then
            InspectionCompany = InspectionCompanyTextBox.Text
        End If

        If InspectorNameTextBox.Text.Length > 0 Then
            InspectorName = InspectorNameTextBox.Text
        End If

        If InspectorNumberTextBox.Text.Length > 0 Then
            InspectorNumber = InspectorNumberTextBox.Text
        End If

        If InspectionFormNumberTextBox.Text.Length > 0 Then
            InspectionFormNumber = InspectionFormNumberTextBox.Text
        End If

        If IsDate(InspectionFormExpirationDateTextBox.Text) Then
            InspectionFormExpirationDate = CDate(InspectionFormExpirationDateTextBox.Text)
        ElseIf InspectionFormExpirationDateTextBox.Text.Length > 0 Then
            ErrorMessage = ErrorMessage & "Inspection Form Expiration Date is not a valid date"
        End If

        If IsDate(BITDateTextBox.Text) Then
            BitDate = CDate(BITDateTextBox.Text)
        ElseIf BITDateTextBox.Text.Length > 0 Then
            ErrorMessage = ErrorMessage & "BIT Date is not a valid date"
        End If

        If ShopNotesTextBox.Text.Length > 0 Then
            ShopNotes = ShopNotesTextBox.Text
        End If

        Try


            If ITable.Rows.Count > 0 Then
                IAdapter.Update(Session("TruckID"), "1", InspectionDate, InspectionCompany, InspectorName, InspectorNumber, InspectionFormNumber, InspectionResult, _
                                InspectionFormExpirationDate, ShopNotes, Today, User.Identity.Name, "1", BitDate, Session("InspectionID"))
            Else
                IAdapter.Insert(Session("TruckID"), "1", InspectionDate, InspectionCompany, InspectorName, InspectorNumber, _
                                InspectionFormNumber, InspectionResult, InspectionFormExpirationDate, ShopNotes, Today, User.Identity.Name, "1", _
                                BitDate, "0")
            End If

        Catch ex As Exception

        End Try

        Response.Redirect("FleetDetail.aspx")

    End Sub
End Class