﻿Public Partial Class LinkDriver1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.CorpID.Value = Session("CompanyID")
    End Sub

    Public Sub SelectDriver(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName = "SelectDriver" Then
            Dim DriverID As Object = Nothing
            Dim FirstName As Object = Nothing
            Dim LastName As Object = Nothing
            Dim SSN As Object = Nothing
            Dim DOB As Object = Nothing
            Dim DOBTextBox As TextBox = CType(GridView1.Rows(e.CommandArgument).FindControl("DOBTextBox"), TextBox)
            Dim DOBLabel As Label = CType(GridView1.Rows(e.CommandArgument).FindControl("Label1"), Label)
            Dim CDL As Object = Nothing

            If DOBTextBox IsNot Nothing Then
                If IsDate(DOBTextBox.Text) Then
                    DOB = CDate(DOBTextBox.Text)
                End If
            ElseIf DOBLabel IsNot Nothing Then
                If IsDate(DOBLabel.Text) Then
                    DOB = CDate(DOBLabel.Text)
                End If
            End If

            If GridView1.Rows(e.CommandArgument).Cells(1).Text.Length > 0 Then
                DriverID = GridView1.Rows(e.CommandArgument).Cells(1).Text
            End If
            If GridView1.Rows(e.CommandArgument).Cells(2).Text.Length > 0 Then
                FirstName = GridView1.Rows(e.CommandArgument).Cells(2).Text
            End If
            If GridView1.Rows(e.CommandArgument).Cells(3).Text.Length > 0 Then
                LastName = GridView1.Rows(e.CommandArgument).Cells(3).Text
            End If
            If GridView1.Rows(e.CommandArgument).Cells(4).Text.Length > 0 Then
                SSN = GridView1.Rows(e.CommandArgument).Cells(4).Text
            End If
            If GridView1.Rows(e.CommandArgument).Cells(5).Text.Length > 0 Then
                DOB = GridView1.Rows(e.CommandArgument).Cells(5).Text
            End If
            If GridView1.Rows(e.CommandArgument).Cells(6).Text.Length > 0 Then
                CDL = GridView1.Rows(e.CommandArgument).Cells(6).Text
            End If

            Dim DriverTA As New TruckFleetTableAdapters.FleetDriversTableAdapter
            Dim DriverTable As New TruckFleet.FleetDriversDataTable

            DriverTA.FillByUID(DriverTable, DriverID, Session("TruckID"))

            If DriverTable.Rows.Count = 0 Then
                DriverTA.Insert(DriverID, Session("TruckID"), FirstName, LastName, DOB, SSN, CDL, "1", "0", "0")
            End If

            Server.Transfer("FleetDetail.aspx")

        End If

    End Sub

    Private Sub BackLinkButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BackLinkButton.Click
        Server.Transfer("FleetDetaikl.aspx")
    End Sub
End Class