﻿Public Partial Class FleetDetail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            PopulateDropDowns()
            If Not Session("IsNewFleet") Then
                Dim regex As String = "(^|\s)(00[1-9]|0[1-9]0|0[1-9][1-9]|[1-6]\d{2}|7[0-6]\d|77[0-2])(-?|[\. ])([1-9]0|0[1-9]|[1-9][1-9])\3(\d{3}[1-9]|[1-9]\d{3}|\d[1-9]\d{2}|\d{2}[1-9]\d)($|\s|[;:,!\.\?])"
                Me.RegExValidator.ValidationExpression = regex
                PopulateForm()
            Else
                Me.AddInspectionButton.Enabled = False
                Me.AddInspectionButton.ToolTip = "Fleet must be saved before you can add an inspection.  Click Save to continue"
                Me.LinkNewDriverButton.Enabled = False
                Me.LinkNewDriverButton.ToolTip = "Fleet must be saved before you can add drivers.  Click Save to continue"
                Dim TruckIDAdapter As New TruckFleetTableAdapters.FleetDetailTableAdapter
                Session("TruckID") = TruckIDAdapter.NextTruckID
            End If
        End If
    End Sub

    Private Sub PopulateDropDowns()
        Dim StatePickListAdapter As New TruckFleetTableAdapters.StatePickListTableAdapter

        Me.RegStateDropDownList.DataSource = StatePickListAdapter.GetData
        Me.RegStateDropDownList.DataBind()

    End Sub

    Private Sub PopulateForm()
        Dim FleetDetailTableAdapter As New TruckFleetTableAdapters.FleetDetailTableAdapter
        Dim FleetDetailTable As New TruckFleet.FleetDetailDataTable

        Dim TruckID As Integer = CInt(Session("TruckID"))

        FleetDetailTableAdapter.FillByTruckID(FleetDetailTable, TruckID)

        Try
            If FleetDetailTable.Rows.Count > 0 Then

                Dim dr As DataRow

                dr = FleetDetailTable.Rows(0)

                Me.VinTextBox.Text = dr("Vin").ToString
                Me.UnitNumberTextBox.Text = dr("UnitNumber").ToString
                If IsDate(dr("DF_TFI_REG_EXPDATE")) Then
                    Me.RegExpirationDateTextBox.Text = String.Format("{0:d}", CDate(dr("DF_TFI_REG_EXPDATE")))
                End If
                If IsDate(dr("DF_TFI_EVAL_DATE")) Then
                    Me.LastEvalDateTextBox.Text = String.Format("{0:d}", CDate(dr("DF_TFI_EVAL_DATE")))
                End If
                Me.VehicleValueTextBox.Text = dr("VehicleValue").ToString
                Me.PlateNumberTextBox.Text = dr("PlateNumber").ToString
                Me.MakeTextBox.Text = dr("Make").ToString
                Me.ModelTextBox.Text = dr("Model").ToString
                Me.ColorTextBox.Text = dr("Color").ToString
                Me.TruckYearTextBox.Text = dr("TruckYear").ToString
                Me.UnladenWeightTextBox.Text = dr("UnladenWeight").ToString
                Me.GrossWeightTextBox.Text = dr("GrossWeight").ToString
                Me.AxlesTextBox.Text = dr("Axles").ToString
                Me.InsuranceNameTextBox.Text = dr("InsuranceCompanyName").ToString
                Me.InsurancePolicyNumberTextBox.Text = dr("InsurancePolicyNumber").ToString
                Me.InsuranceLimitTextBox.Text = dr("InsuranceLimit").ToString
                If IsDate(dr("InsuranceExpirationDate")) Then
                    Me.InsuranceExpirationTextBox.Text = String.Format("{0:d}", CDate(dr("InsuranceExpirationDate")))
                End If
                If dr("TruckOwner") IsNot Nothing Then
                    Select Case dr("TruckOwner").ToString
                        Case "1"
                            Me.TruckOwnerRadioButtonList.SelectedValue = "1"
                        Case "2"
                            Me.TruckOwnerRadioButtonList.SelectedValue = "2"
                        Case "3"
                            Me.TruckOwnerRadioButtonList.SelectedValue = "3"
                    End Select
                End If

                VTypeDropDownList.SelectedValue = dr("TruckType").ToString

                Me.RegStateDropDownList.SelectedValue = dr("RegistrationState").ToString

                Dim VendorTableAdapter As New TruckFleetTableAdapters.FleetVendorTableAdapter
                Dim VendorTable As New TruckFleet.FleetVendorDataTable

                VendorTableAdapter.FillByTruckID(VendorTable, TruckID)

                If VendorTable.Rows.Count > 0 Then

                    Dim dr2 As DataRow
                    dr2 = VendorTable.Rows(0)

                    Session("VendorID") = dr2("DF_TVI_ID").ToString
                    Me.VendorCodeTextBox.Text = dr2("DF_TVI_VENDORCODE").ToString
                    Me.VendorInfoOOAddressTextBox.Text = dr2("DF_TVI_COMPANYADDRESS").ToString
                    Me.VendorCityTextBox.Text = dr2("DF_TVI_CITY").ToString
                    Me.VendorZipTextBox.Text = dr2("DF_TVI_ZIP").ToString
                    Me.VendorInfoOOPhoneTextBox.Text = dr2("DF_TVI_PHONE").ToString
                    Me.VendorInfoOOTextBox.Text = dr2("DF_TVI_COMPANYNAME").ToString
                    Me.FederID1TextBox.Text = dr2("DF_TVI_FEDERALID").ToString
                    Me.VendorSSNTextBox.Text = dr2("DF_TVI_SSN").ToString

                    VendorInfoOORadioButtonList.SelectedValue = dr2("DF_TVI_TYPE").ToString

                End If

                BindGridViews(TruckID)

            Else
                Me.FleetErrorMessage.Text = "No truck found"
                Me.FleetErrorMessage.Visible = True
                Me.FleetErrorMessage.ForeColor = Drawing.Color.Red
            End If

        Catch ex As Exception
            Me.FleetErrorMessage.Text = ex.ToString
            Me.FleetErrorMessage.Visible = True
            Me.FleetErrorMessage.ForeColor = Drawing.Color.Red
        End Try

    End Sub

    Private Sub BindGridViews(ByVal truckID As Integer)
        FillInspectionGrid(truckID)
        BindDriverGridView(truckID)
    End Sub


    '**************************************************************************************
    '*Inspection Gridview Methods
    '**************************************************************************************

    Private Sub FillInspectionGrid(ByVal truckID As Integer)
        Dim InspectionTableAdapter As New TruckFleetTableAdapters.FleetInspectionTableAdapter


        Dim dt As New DataTable
        dt = InspectionTableAdapter.GetDataByTruckID(truckID)

        If dt.Rows.Count > 0 Then
            InspectionInfoGridView.DataSource = dt
            InspectionInfoGridView.DataBind()
            Session("ITable") = InspectionInfoGridView.DataSource
        Else
            Dim emptyDT As New DataTable
            Dim col1 As DataColumn = New DataColumn("InspectionDate")
            Dim col2 As DataColumn = New DataColumn("InspectorCompany")
            Dim col3 As DataColumn = New DataColumn("InspectorName")
            Dim col4 As DataColumn = New DataColumn("InspectorNumber")
            Dim col5 As DataColumn = New DataColumn("InspectionFormNumber")
            Dim col6 As DataColumn = New DataColumn("ExpirationDate")
            Dim col7 As DataColumn = New DataColumn("InspectionDate1")
            Dim col8 As DataColumn = New DataColumn("InspectionShopNotes")
            Dim col9 As DataColumn = New DataColumn("InspectionResult")
            Dim col10 As DataColumn = New DataColumn("DF_TBI_ID")


            emptyDT.Columns.Add(col1)
            emptyDT.Columns.Add(col2)
            emptyDT.Columns.Add(col3)
            emptyDT.Columns.Add(col4)
            emptyDT.Columns.Add(col5)
            emptyDT.Columns.Add(col6)
            emptyDT.Columns.Add(col7)
            emptyDT.Columns.Add(col8)
            emptyDT.Columns.Add(col9)
            emptyDT.Columns.Add(col10)

            Dim row As DataRow = emptyDT.NewRow
            row.Item("DF_TBI_ID") = DateTime.Today
            row.Item("InspectionDate") = DateTime.Today
            row.Item("InspectorCompany") = ""
            row.Item("InspectorName") = ""
            row.Item("InspectorNumber") = ""
            row.Item("InspectionFormNumber") = ""
            row.Item("InspectionDate1") = ""
            row.Item("ExpirationDate") = ""
            row.Item("InspectionShopNotes") = ""
            row.Item("InspectionResult") = ""
            emptyDT.Rows.Add(row)

            InspectionInfoGridView.DataSource = emptyDT
            InspectionInfoGridView.DataBind()

            Dim TotalColumns As Integer = InspectionInfoGridView.Rows(0).Cells.Count
            InspectionInfoGridView.Rows(0).Cells.Clear()
            InspectionInfoGridView.Rows(0).Cells.Add(New TableCell())
            InspectionInfoGridView.Rows(0).Cells(0).ColumnSpan = TotalColumns
            InspectionInfoGridView.Rows(0).Cells(0).Text = "No Record Found"
        End If

        InspectionInfoGridView.ShowFooter = True

    End Sub

    Public Sub EditInspection(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName = "Edit" Then
            Dim InspectionID As HiddenField = CType(Me.InspectionInfoGridView.Rows(e.CommandArgument).FindControl("InspectionID"), HiddenField)
            If InspectionID IsNot Nothing Then
                Session("InspectionID") = InspectionID.Value
                Server.Transfer("InspectionDetail.aspx")
            Else
                Dim IAdapter As New TruckFleetTableAdapters.FleetInspectionTableAdapter
                'Session("InspectionID") = IAdapter.NextInspectionID
                Server.Transfer("InspectionDetail.aspx")
            End If
        ElseIf e.CommandName = "Delete" Then
            Dim InspectionID As HiddenField = CType(Me.InspectionInfoGridView.Rows(e.CommandArgument).FindControl("InspectionID"), HiddenField)
            If InspectionID IsNot Nothing Then
                Dim ta As New TruckFleetTableAdapters.FleetInspectionTableAdapter

                ta.Delete(InspectionID.Value)

                BindGridViews(Session("TruckID"))
            End If

        End If

    End Sub

    '***************************************************************************************
    '*Driver Gridview Mehods
    '***************************************************************************************
    Private Sub BindDriverGridView(ByVal truckID As Integer)
        Dim DriverTableAdapter As New TruckFleetTableAdapters.FleetDriversTableAdapter
        Dim DriverTable As New TruckFleet.FleetDriversDataTable

        DriverTableAdapter.FillByTruckID(DriverTable, truckID)

        DriverGridView.DataSource = DriverTable

        DriverGridView.DataBind()
    End Sub

    Protected Sub DriverGridView_RowDeleting(ByVal sender As Object, ByVal e As GridViewDeleteEventArgs) Handles DriverGridView.RowDeleting
        Dim DriverIDHiddenField As HiddenField = CType(DriverGridView.Rows(e.RowIndex).FindControl("DriverLinkID"), HiddenField)

        If DriverIDHiddenField IsNot Nothing Then
            Dim DriverLinkAdapter As New TruckFleetTableAdapters.FleetDriversTableAdapter

            DriverLinkAdapter.Delete(DriverIDHiddenField.Value)

            BindGridViews(Session("TruckID"))

        End If


    End Sub

    Private Sub CancelButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancelButton.Click
        Session("IsNewFleet") = False
        Response.Redirect("Default.aspx")
    End Sub

    Private Sub SaveButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveButton.Click
        Me.AddInspectionButton.Enabled = True
        Me.AddInspectionButton.ToolTip = ""
        Me.LinkNewDriverButton.Enabled = True
        Me.LinkNewDriverButton.ToolTip = ""
        SaveData()
    End Sub

    Private Sub LinkNewDriverButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkNewDriverButton.Click
        Response.Redirect("LinkDriver.aspx")
    End Sub

    Private Sub SaveData()

        Dim FleetDetailTableAdapter As New TruckFleetTableAdapters.FleetDetailTableAdapter
        Dim FleetDetailTable As New TruckFleet.FleetDetailDataTable
        Dim IsInsert As Boolean = False
        Dim IsValid As Boolean = True
        Dim ErrorMessage As String = String.Empty

        Dim TruckID As Integer = CInt(Session("TruckID"))

        FleetDetailTableAdapter.FillByTruckID(FleetDetailTable, TruckID)

        Dim dr As DataRow

        Try
            If FleetDetailTable.Rows.Count > 0 Then

                dr = FleetDetailTable.Rows(0)
                IsInsert = False

            Else
                IsInsert = True
            End If

            Dim Vin As Object = Nothing
            Dim UnitNumber As Object = Nothing
            Dim RegExpDate As Object = Nothing
            Dim VehicleValue As Object = Nothing
            Dim PlateNumber As Object = Nothing
            Dim Make As Object = Nothing
            Dim Model As Object = Nothing
            Dim Color As Object = Nothing
            Dim TruckYear As Object = Nothing
            Dim UnladenWeight As Object = Nothing
            Dim GrossWeight As Object = Nothing
            Dim Axles As Object = Nothing
            Dim LicNo As Object = Nothing
            Dim InsCompName As Object = Nothing
            Dim InsPolicyNum As Object = Nothing
            Dim InsLimit As Object = Nothing
            Dim InsExpDate As Object = Nothing
            Dim TruckOwner As Object = Nothing
            Dim State As Object = Nothing
            Dim LastEvaluationDate As Object = Nothing

            If VinTextBox.Text.Length > 0 Then
                Vin = VinTextBox.Text
            Else
                ErrorMessage += "VIN Is a Required Field"
                IsValid = False
            End If
            If UnitNumberTextBox.Text.Length > 0 Then
                UnitNumber = UnitNumberTextBox.Text
            End If
            If IsDate(RegExpirationDateTextBox.Text) Then
                RegExpDate = CDate(RegExpirationDateTextBox.Text)
            ElseIf RegExpirationDateTextBox.Text.Length > 0 Then
                ErrorMessage = ErrorMessage & "Registration Expiration Date must be a date"
                IsValid = False
            End If
            If IsDate(Me.LastEvalDateTextBox.Text) Then
                LastEvaluationDate = CDate(Me.LastEvalDateTextBox.Text)
            ElseIf Me.LastEvalDateTextBox.Text.Length > 0 Then
                ErrorMessage = ErrorMessage & "Last Evaluation Date must be a date"
                IsValid = False
            End If
            If VehicleValueTextBox.Text.Length > 0 Then
                VehicleValue = VehicleValueTextBox.Text
            End If
            If PlateNumberTextBox.Text.Length > 0 Then
                PlateNumber = PlateNumberTextBox.Text
            End If
            If MakeTextBox.Text.Length > 0 Then
                Make = MakeTextBox.Text
            End If
            If ModelTextBox.Text.Length > 0 Then
                Model = ModelTextBox.Text
            End If
            If ColorTextBox.Text.Length > 0 Then
                Color = ColorTextBox.Text
            End If
            If TruckYearTextBox.Text.Length > 0 Then
                TruckYear = TruckYearTextBox.Text
            End If
            If UnladenWeightTextBox.Text.Length > 0 Then
                UnladenWeight = UnladenWeightTextBox.Text
            End If
            If GrossWeightTextBox.Text.Length > 0 Then
                GrossWeight = GrossWeightTextBox.Text
            End If
            If AxlesTextBox.Text.Length > 0 Then
                Axles = AxlesTextBox.Text
            End If

            If InsuranceNameTextBox.Text.Length > 0 Then
                InsCompName = InsuranceNameTextBox.Text
            End If
            If InsurancePolicyNumberTextBox.Text.Length > 0 Then
                InsPolicyNum = InsurancePolicyNumberTextBox.Text
            End If
            If InsuranceLimitTextBox.Text.Length > 0 Then
                InsLimit = InsuranceLimitTextBox.Text
            End If
            If IsDate(InsuranceExpirationTextBox.Text) Then
                InsExpDate = CDate(InsuranceExpirationTextBox.Text)
            ElseIf InsuranceExpirationTextBox.Text.Length > 0 Then
                ErrorMessage = ErrorMessage & "Insurance Expiration Date must be a Date"
                IsValid = False
            End If
            Select Case TruckOwnerRadioButtonList.SelectedValue
                Case "1"
                    TruckOwner = "1"
                Case "2"
                    TruckOwner = "2"
                Case "3"
                    TruckOwner = "3"
            End Select
            State = RegStateDropDownList.SelectedValue

            If IsValid Then
                If IsInsert Then

                    FleetDetailTableAdapter.Insert(Vin, Session("CompanyID"), PlateNumber, UnitNumber, VTypeDropDownList.SelectedValue, Model, TruckYear, _
                                                Make, Color, UnladenWeight, GrossWeight, Axles, LicNo, State, VehicleValue, LastEvaluationDate, Today(), InsCompName, InsPolicyNum, _
                                                InsExpDate, InsLimit, TruckOwner, RegExpDate)
                Else
                    FleetDetailTableAdapter.Update(Vin, CInt(Session("CompanyID")), "3", PlateNumber, UnitNumber, VTypeDropDownList.SelectedValue, Model, TruckYear, Make, Color, UnladenWeight, GrossWeight, Axles, LicNo, State, VehicleValue, LastEvaluationDate, Today(), InsCompName, InsPolicyNum, InsExpDate, InsLimit, TruckOwner, RegExpDate, TruckID)

                End If
            End If


            Dim VendorTableAdapter As New TruckFleetTableAdapters.FleetVendorTableAdapter
            Dim VendorTable As New TruckFleet.FleetVendorDataTable

            VendorTableAdapter.FillByTruckID(VendorTable, TruckID)

            If VendorTable.Rows.Count > 0 Then
                Session("VendorID") = VendorTable.Rows(0)("DF_TVI_ID")
                IsInsert = False
            Else
                IsInsert = True
            End If

            Dim VendorCode As Object = Nothing
            Dim VendorAddress As Object = Nothing
            Dim VCity As Object = Nothing
            Dim VZip As Object = Nothing
            Dim VPhone As Object = Nothing
            Dim VCompName As Object = Nothing
            Dim VFedID As Object = Nothing
            Dim VSSN As Object = Nothing
            Dim VType As Object = Nothing
            If VendorCodeTextBox.Text.Length > 0 Then
                VendorCode = VendorCodeTextBox.Text
            End If
            If VendorInfoOOAddressTextBox.Text.Length > 0 Then
                VendorAddress = VendorInfoOOAddressTextBox.Text
            End If
            If VendorCityTextBox.Text.Length > 0 Then
                VCity = VendorCityTextBox.Text
            End If
            If VendorZipTextBox.Text.Length > 0 Then
                VZip = VendorZipTextBox.Text
            End If
            If VendorInfoOOPhoneTextBox.Text.Length > 0 Then
                VPhone = VendorInfoOOPhoneTextBox.Text
            End If
            If VendorInfoOOTextBox.Text.Length > 0 Then
                VCompName = VendorInfoOOTextBox.Text
            End If
            If FederID1TextBox.Text.Length > 0 Then
                VFedID = FederID1TextBox.Text
            End If
            If VendorSSNTextBox.Text.Length > 0 Then
                VSSN = VendorSSNTextBox.Text
            End If
            Dim NullValue As Object = Nothing
            If VendorInfoOORadioButtonList.SelectedIndex > -1 Then
                VType = CInt(VendorInfoOORadioButtonList.SelectedValue)
            End If

            If IsInsert Then
                VendorTableAdapter.Insert(VendorTableAdapter.NextVendorID, TruckID.ToString, VType, VSSN, VFedID, 0, NullValue, Today, 3, VendorCode, VCompName, NullValue, _
                                          NullValue, VendorAddress, VCity, VZip, VPhone, NullValue, NullValue, NullValue, 0)
            Else
                VendorTableAdapter.Update(TruckID, VType, VSSN, VFedID, 3, VendorCode, VendorAddress, VCity, VZip, VCompName, VPhone, Session("VendorID"))
            End If

            If Not IsValid Then
                FleetErrorMessage.Text = ErrorMessage
                FleetErrorMessage.Visible = True
                Me.FleetErrorMessage.ForeColor = Drawing.Color.Red
            Else
                BindGridViews(TruckID)
                Me.FleetErrorMessage.Text = "Vehicle Successfully Saved"
                Me.FleetErrorMessage.ForeColor = Drawing.Color.Green
            End If

            Session("IsNewFleet") = False


        Catch ex As Exception
            Me.FleetErrorMessage.Text = ex.ToString
            Me.FleetErrorMessage.Visible = True
            Me.FleetErrorMessage.ForeColor = Drawing.Color.Red
        End Try




    End Sub


    Private Sub AddInspectionButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles AddInspectionButton.Click
        Server.Transfer("InspectionDetail.aspx")
    End Sub

    Private Sub InspectionInfoGridView_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles InspectionInfoGridView.RowDataBound

        Dim dv As DataTable = InspectionInfoGridView.DataSource

        If e.Row.RowIndex > -1 Then
            Dim Result As String = dv.Rows(e.Row.RowIndex)("InspectionResult").ToString
            Dim ResultRadioList As RadioButtonList = CType(e.Row.FindControl("ReadOnlyResultRadioButtonList"), RadioButtonList)

            If ResultRadioList IsNot Nothing Then
                If Result.ToUpper = "FAILED" Then
                    ResultRadioList.SelectedValue = "Failed"
                Else
                    ResultRadioList.SelectedValue = "Passed"
                End If
            End If

        End If

    End Sub

    Private Sub InspectionInfoGridView_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles InspectionInfoGridView.RowDeleting
        

    End Sub

    Private Sub BackLinkButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BackLinkButton.Click
        Response.Redirect("Default.aspx")
    End Sub

    Private Sub CompleteButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CompleteButton.Click
        Dim UpdateStatusAdapter As New TruckFleetTableAdapters.FleetDetailTableAdapter
        UpdateStatusAdapter.SetStatus("1", Session("TruckID"))
        Response.Redirect("Default.aspx")
    End Sub

    Private Sub DeleteButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles DeleteButton.Click
        Try
            Dim DeleteTruckAdapter As New TruckFleetTableAdapters.DeleteTruckTableAdapter
            DeleteTruckAdapter.DeleteTruck(CInt(Session("TruckID")))
            Response.Redirect("Default.aspx")
        Catch ex As Exception

        End Try
    End Sub
End Class