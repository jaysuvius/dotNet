﻿Public Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            PopulateForm()
        End If
    End Sub

    Private Sub PopulateForm()
        Dim WSUsersToCompanies As New UserDataTableAdapters.WSUsersToCompaniesTableAdapter
        Dim wst As New UserData.WSUsersToCompaniesDataTable
        WSUsersToCompanies.FillByWSUName(wst, User.Identity.Name)
        If wst.Rows.Count > 0 Then
            If wst.Rows(0)("DQFUserID").ToString <> "" Then
                Me.UserID.Value = wst.Rows(0)("DQFUserID")
            End If
            Me.CompanyID.Value = Session("CompanyID")
        End If
        Dim FleetDataTA As New TruckFleetTableAdapters.FleetListTableAdapter
        Dim FleetDataTb As New TruckFleet.FleetListDataTable
        FleetDataTA.Fill(FleetDataTb, CompanyID.Value)
        GridView1.DataSourceID = ""
        GridView1.DataSource = FleetDataTb

        Session("GridView1_Datasource") = GridView1.DataSource

        GridView1.DataBind()
    End Sub

    Public Sub GetTruck(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)

        If e.CommandName = "SelectTruck" Then
            Session("TruckID") = Me.GridView1.Rows(e.CommandArgument).Cells(0).Text
            Session("CompanyID") = Me.CompanyID.Value
            Response.Redirect("FleetDetail.aspx")
        ElseIf e.CommandName = "Delete" Then
            'Dim rtnval As Integer
            'rtnval = MsgBox("Are you sure you want to delete this vehicle?", MsgBoxStyle.OkCancel, "Delete?")
            'If rtnval = MsgBoxResult.Ok Then
            Try
                Dim TruckID As Object = Me.GridView1.Rows(e.CommandArgument).Cells(0).Text
                Dim DeleteTruckAdapter As New TruckFleetTableAdapters.DeleteTruckTableAdapter
                DeleteTruckAdapter.DeleteTruck(CInt(TruckID))
                PopulateForm()
            Catch ex As Exception

            End Try

            'End If

        End If
    End Sub

    Private Sub AddNewButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles AddNewButton.Click
        Session("IsNewFleet") = True
        Response.Redirect("FleetDetail.aspx")
    End Sub

    Private Sub ApplyFilterLinkButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ApplyFilterLinkButton.Click
        Dim Unit As Object = Nothing
        Dim Type As Object = Nothing
        Dim Vin As Object = Nothing
        Dim Axis As Object = Nothing
        Dim LicNo As Object = Nothing
        Dim Status As Object = Nothing

        If UnitNumberFilterTextBox.Text.Length > 0 Then
            Unit = UnitNumberFilterTextBox.Text
        End If
        If TypeFilterTextBox.Text.Length > 0 Then
            Type = TypeFilterTextBox.Text
        End If
        If VinFilterTextBox.Text.Length > 0 Then
            Vin = VinFilterTextBox.Text
        End If
        If AxisFilterTextBox.Text.Length > 0 Then
            Axis = AxisFilterTextBox.Text
        End If
        If LicenseNumberFilterTextBox.Text.Length > 0 Then
            LicNo = LicenseNumberFilterTextBox.Text
        End If
        If StatusFilterTextBox.Text.Length > 0 Then
            Status = StatusFilterTextBox.Text
        End If
        Dim BlankValue As Object = Nothing


        Dim FleetDataTA As New TruckFleetTableAdapters.FleetListTableAdapter
        Dim FleetDataTb As New TruckFleet.FleetListDataTable
        FleetDataTA.FillByFilters(FleetDataTb, CompanyID.Value, Unit, Type, Vin, BlankValue, Axis, LicNo)
        GridView1.DataSourceID = ""
        GridView1.DataSource = FleetDataTb

        Session("GridView1_Datasource") = GridView1.DataSource

        GridView1.DataBind()

    End Sub

    Private Sub ShowAllButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ShowAllButton.Click
        PopulateForm()
    End Sub

    Private Sub GridView1_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridView1.PageIndexChanging
        GridView1.PageIndex = e.NewPageIndex
        GridView1.DataSource = Session("GridView1_Datasource")
        GridView1.DataBind()
    End Sub

    Private Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        Dim DeleteButton As LinkButton = CType(e.Row.FindControl("DeleteButton"), LinkButton)
        If DeleteButton IsNot Nothing Then
            DeleteButton.OnClientClick = "return confirm('Are you sure you want to delete your account?');"
        End If
    End Sub

    Private Sub GridView1_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles GridView1.RowDeleting

    End Sub

    Private Sub GridView1_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles GridView1.Sorting
        Dim dt As DataTable = Session("GridView1_Datasource")

        If dt IsNot Nothing Then
            Dim dv As New DataView(dt)
            dv.Sort = e.SortExpression & " " & ConvertSortDirectionToSQL(e.SortDirection)
            GridView1.DataSource = dv
            GridView1.DataBind()
        End If
    End Sub

    Private Function ConvertSortDirectionToSQL(ByVal sd As SortDirection) As String
        Dim NewSortDirection As String = String.Empty
        Select Case sd
            Case SortDirection.Ascending
                NewSortDirection = "ASC"
                Exit Select
            Case SortDirection.Descending
                NewSortDirection = "DESC"
                Exit Select
        End Select
        Return NewSortDirection
    End Function


End Class