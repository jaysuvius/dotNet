﻿Partial Public Class Login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim HostName As String = System.Net.Dns.GetHostName()
        Dim ClientIP As String = System.Net.Dns.GetHostAddresses(HostName).GetValue(0).ToString()
        Me.IPAddressLabel.Text = ClientIP
        If User.Identity.IsAuthenticated Then
            Response.Redirect("Logout.aspx")
        End If
        checkJavaScript()
        checkCookies()
        redirectUser()
    End Sub

    Protected Sub Login1_Authenticate(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.AuthenticateEventArgs) Handles Login1.Authenticate
        ' Log the user in and redirect them to this same page, which will redirect them to the appropriate screen
        If Membership.ValidateUser(Login1.UserName, Login1.Password) Then
            FormsAuthentication.SetAuthCookie(Login1.UserName, False)
            If isValidCompany() Or Roles.IsUserInRole(Login1.UserName, "SSSAdmin") Then
                Session("UserName") = Login1.UserName
                SetMasterPageWelcome()
                redirectUser()
            Else
                'No company associated with user, throw Exception and redirect to error page
                Session("ErrorText") = "The Company ID you have entered is invalid.  <Br> <Br> Please Contact your Strategic Sagfety Solutions Administrator"
                FormsAuthentication.SignOut()
                Response.Redirect("ErrorPage.aspx")
            End If
        Else
            Response.Redirect("Login.aspx")
        End If
    End Sub

    Protected Sub SetMasterPageWelcome()
        Dim UserFullName As String = String.Empty
        Dim CompanyName As String = String.Empty

        Dim UsernameAdapter As New UserDataTableAdapters.GetUserFullNameTableAdapter
        Dim UsernameTable As New UserData.GetUserFullNameDataTable
        Dim CompanyNameAdapter As New UserDataTableAdapters.GetCompanyNameTableAdapter
        Dim CompanyNameTable As New UserData.GetCompanyNameDataTable

        UsernameAdapter.Fill(UsernameTable, Session("UserName"))
        If UsernameTable.Rows.Count > 0 Then
            UserFullName = UsernameTable.Rows(0)("DF_UR_FISRTNAME") & " " & UsernameTable.Rows(0)("DF_UR_LASTNAME")
        Else
            UserFullName = "Could Not Retrieve User Name"
        End If

        CompanyNameAdapter.Fill(CompanyNameTable, Session("CompanyID"))
        If CompanyNameTable.Rows.Count > 0 Then
            CompanyName = CompanyNameTable.Rows(0)("DF_CR_CORP_NAME")
        Else
            CompanyName = "Could Not Retrieve Company Name"
        End If

        Session("UserFullName") = UserFullName
        Session("CompanyName") = CompanyName

    End Sub

    Protected Function isValidCompany() As Boolean
        Dim bValid As Boolean = False
        Dim CompanyAdapter As New UserDataTableAdapters.GetCompanyIDTableAdapter
        Dim CompanyTable As New UserData.GetCompanyIDDataTable

        Dim UserNameTextBox As TextBox = CType(Login1.FindControl("UserName"), TextBox)
        Dim UName As String = String.Empty
        Dim CompanyNameTextBox As TextBox = CType(Login1.FindControl("CompanyTextBox"), TextBox)
        Dim CompName As String = String.Empty
        If UserNameTextBox IsNot Nothing Then
            UName = UserNameTextBox.Text
        End If
        If CompanyNameTextBox IsNot Nothing Then
            CompName = CompanyNameTextBox.Text
        End If

        CompanyAdapter.Fill(CompanyTable, UName)

        If CompanyTable.Rows.Count > 0 Then
            For Each r As DataRow In CompanyTable.Rows
                If CompName.ToUpper = r("DF_CR_CORPID").ToString.ToUpper Then
                    Session("CompanyID") = r("DF_CR_ID")
                    bValid = True
                End If
            Next
            Return bValid
        Else
            Return bValid
        End If

    End Function

    Private Sub redirectUser()
        Dim currentUser As System.Web.Security.MembershipUser
        currentUser = Membership.GetUser(Login1.UserName)
        If Not (currentUser Is Nothing) Then
            If Request.QueryString("newLogin") = "True" Then
                Response.Redirect("Logout.aspx")
            ElseIf Roles.IsUserInRole(currentUser.UserName, "SSSAdmin") Then
                Session("AccessLevel") = "Admin"
                Response.Redirect("~/Admin/")
            ElseIf Roles.IsUserInRole(currentUser.UserName, "Fleet") Then
                Session("AccessLevel") = "Fleet"
                Response.Redirect("~/Fleet/Default.aspx")
            ElseIf Roles.IsUserInRole(currentUser.UserName, "User") Then
                Session("AccessLevel") = "User"
                Response.Redirect("~/Membership/UserProfile.aspx")
            End If
        End If
    End Sub

    Private Sub checkCookies()
        If Not Page.IsPostBack Then
            'Check whether cookies are enabled
            If Request.QueryString("Trying") = "" Then
                ' this is the first time this page has been called
                ' set a cookie and redirect to this same page
                Response.SetCookie(New System.Web.HttpCookie("TryingCookie", "ON"))
                Response.Redirect(Request.ServerVariables("URL") & "?Trying=ON")
            Else
                ' we got here because of the redirection
                If (Request.Cookies("TryingCookie") Is Nothing) OrElse (Request.Cookies("TryingCookie").Value() = "") Then
                    ' cookies aren't supported - display an error message and exit
                    Label1.Text = "Cookies must be enabled for this website to work properly.<br/>Please check your browser settings.<br/>"
                    Label1.ForeColor = Drawing.Color.Red
                    Label1.Visible = True
                Else
                    Label1.Visible = False
                End If
                ' clear the trying cookie (optional)
                Response.SetCookie(New System.Web.HttpCookie("TryingCookie", ""))
            End If

            ' Cookies are enabled, so set the session timeout to 10 minutes
            If Session.IsNewSession Then
                Session.Timeout = 10
            End If
        End If
    End Sub

    Private Sub checkJavaScript()
        If Not Page.IsPostBack Then
            'Check whether Javascript is enabled
            If Not (Request.Browser.EcmaScriptVersion().Major >= 1) Then
                ' javascript isnt supported - display an error message and exit
                Label1.Text = "JavaScript and cookies must be enabled for this website to work properly.<br/>Please check your browser settings.<br/>"
                Label1.ForeColor = Drawing.Color.Red
                Label1.Visible = True
            Else
                Label1.Visible = False
            End If
        End If
    End Sub

End Class