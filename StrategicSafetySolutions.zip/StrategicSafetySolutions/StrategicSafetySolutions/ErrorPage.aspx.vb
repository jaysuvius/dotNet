﻿Public Partial Class ErrorPage
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("ErrorText") IsNot Nothing Then
            Me.ErrorLabel.Text = Session("ErrorText")
        End If
    End Sub

    Private Sub BackButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BackButton.Click
        Response.Redirect("Default.aspx")
    End Sub
End Class