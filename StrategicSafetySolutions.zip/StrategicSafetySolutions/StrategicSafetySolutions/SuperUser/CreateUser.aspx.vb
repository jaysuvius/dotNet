﻿Public Partial Class CreateUser
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        CorpID.Value = Session("CompanyID")
    End Sub

    Protected Sub CreateUserWizard1_CreatedUser(ByVal sender As Object, ByVal e As EventArgs) Handles CreateUserWizard1.CreatedUser
        Dim UserComp As New UserDataTableAdapters.WSUsersToCompaniesTableAdapter
        UserComp.SuperUserInsert(Guid.NewGuid, CreateUserWizard1.UserName, CorpID.Value)
        CreateUserWizard1.LoginCreatedUser = False
    End Sub

    Protected Sub ContinueButton_Click(ByVal sender As Object, ByVal e As EventArgs)
        Response.Redirect("Default.aspx")
    End Sub
End Class