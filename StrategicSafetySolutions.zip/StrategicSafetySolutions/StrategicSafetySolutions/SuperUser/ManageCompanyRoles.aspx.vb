﻿Partial Public Class ManageCompanyRoles
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            If Roles.IsUserInRole("SuperUser") Then
                CorpID.Value = Session("CompanyID")
                loadUsersAndRoles()
            Else
                Response.Redirect("Default.aspx")
            End If
        End If
    End Sub

    Private Sub loadUsersAndRoles()
        Dim CompanyUsersAdapter As New UserDataTableAdapters.CompanyUsersTableAdapter
        Dim UserTable As New UserData.CompanyUsersDataTable

        CompanyUsersAdapter.Fill(UserTable, CorpID.Value)
        If UserTable.Rows.Count > 0 Then
            For Each dr As DataRow In UserTable.Rows
                ListBox1.Items.Add(dr("WSUserName"))
            Next
        End If
        For Each role As String In Roles.GetAllRoles()
            If role <> "Administrator" And role <> "SSSAdmin" And role <> "SuperUser" And role <> "User" And role <> "Accident" Then
                ListBox2.Items.Add(role)
            End If
        Next
        ListBox1.SelectedIndex = 0
        ListBox2.SelectedIndex = 0
    End Sub

    Protected Function GetUserCompany(ByVal UserName As String) As String
        Dim CheckCompanyAdapter As New UserDataTableAdapters.GetCompanyIDTableAdapter
        Dim CompTable As New UserData.GetCompanyIDDataTable

        CheckCompanyAdapter.Fill(CompTable, UserName)

        If CompTable.Rows.Count > 0 Then
            Dim dr As DataRow = CompTable.Rows(0)
            Dim CompID As String = dr("DF_CR_ID")

            Return CompID
        Else
            Return String.Empty
        End If
    End Function

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim username As String
        username = ListBox1.SelectedItem.Text
        If Not Roles.IsUserInRole(username, ListBox2.SelectedItem.Text) Then
            Roles.AddUserToRole(username, ListBox2.Items(ListBox2.SelectedIndex).Text)
            Label1.Text = "User " & ListBox1.Items(ListBox1.SelectedIndex).Text & " added to role " & ListBox2.Items(ListBox2.SelectedIndex).Text
        Else
            Label1.Text = "User " & ListBox1.Items(ListBox1.SelectedIndex).Text & " already in role " & ListBox2.Items(ListBox2.SelectedIndex).Text
        End If
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim username As String
        username = ListBox1.SelectedItem.Text
        If Roles.IsUserInRole(username, ListBox2.SelectedItem.Text) Then
            Roles.RemoveUserFromRole(username, ListBox2.Items(ListBox2.SelectedIndex).Text)
            Label1.Text = "User " & ListBox1.Items(ListBox1.SelectedIndex).Text & " removed from role " & ListBox2.Items(ListBox2.SelectedIndex).Text
        Else
            Label1.Text = "User " & ListBox1.Items(ListBox1.SelectedIndex).Text & " not yet in role " & ListBox2.Items(ListBox2.SelectedIndex).Text & ", cannot remove"
        End If
    End Sub
End Class