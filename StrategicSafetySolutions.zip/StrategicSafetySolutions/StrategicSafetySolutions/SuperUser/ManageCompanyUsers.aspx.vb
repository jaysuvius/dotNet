﻿Partial Public Class ManageCompanyUsers
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Me.CorpID.Value = Session("CompanyID")
            Me.LookupDQFUserID.Visible = False
            GridView1.DataBind()
        End If
    End Sub

    Public Sub GetUser(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        Try
            If e.CommandName = "GetUser" Then
                Me.UserDataPanel.Visible = True
                Me.UserGridPanel.Visible = False
                Dim u As MembershipUserCollection
                u = Membership.FindUsersByName(GridView1.Rows(e.CommandArgument).Cells(1).Text)
                If u.Count = 1 Then
                    Dim us As MembershipUser
                    us = u(GridView1.Rows(e.CommandArgument).Cells(1).Text)
                    UserNameTextBox.Text = us.UserName
                    Session("UserName") = us.UserName
                    EmailAddressTextBox.Text = us.Email
                    CommentTextBox.Text = us.Comment
                    ApprovedCheckBox.Checked = us.IsApproved
                    Dim WSUsersToCompaniesTableAdapter As New UserDataTableAdapters.WSUsersToCompaniesTableAdapter
                    Dim dt As DataTable = WSUsersToCompaniesTableAdapter.GetDataByWSUName(us.UserName)
                    Dim dr As DataRow
                    If dt.Rows.Count > 0 Then
                        dr = dt.Rows(0)
                        '        CompanyIDTextBox.Text = dr("DQFCompanyID")
                        Session("UserID") = dr("DQFUserID")
                    End If
                End If
            End If

        Catch ex As Exception
            Session("ErrorText") = "An error has occurred: " & ex.Message
            Response.Redirect("ErrorPage.aspx")
        End Try

    End Sub

    Private Function ConvertSortDirectionToSQL(ByVal sd As SortDirection) As String
        Dim NewSortDirection As String = String.Empty
        Select Case sd
            Case SortDirection.Ascending
                NewSortDirection = "ASC"
                Exit Select
            Case SortDirection.Descending
                NewSortDirection = "DESC"
                Exit Select
        End Select
        Return NewSortDirection
    End Function

    Private Sub SaveButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveButton.Click
        Try
            Dim u As MembershipUserCollection
            u = Membership.FindUsersByName(UserNameTextBox.Text)
            If u.Count = 1 Then
                Dim us As MembershipUser
                us = u(UserNameTextBox.Text)
                us.Email = EmailAddressTextBox.Text
                us.Comment = CommentTextBox.Text
                us.IsApproved = ApprovedCheckBox.Checked
                Membership.UpdateUser(us)
                Dim WSUsersToCompaniesTableAdapter As New UserDataTableAdapters.WSUsersToCompaniesTableAdapter
                Dim dt As DataTable = WSUsersToCompaniesTableAdapter.GetDataByWSUName(us.UserName)
                Dim dr As DataRow
                If dt.Rows.Count > 0 Then
                    dr = dt.Rows(0)
                    dr("DQFUserID") = Session("UserID")
                    WSUsersToCompaniesTableAdapter.Update(dt)
                Else
                    WSUsersToCompaniesTableAdapter.Insert(Guid.NewGuid, us.UserName, Session("UserID"))
                End If
            End If
            Me.UserDataPanel.Visible = False
            Me.UserGridPanel.Visible = True
            Me.LookupDQFUserID.Visible = False

        Catch ex As Exception
            Session("ErrorText") = "An error has occurred: " & ex.Message
            Response.Redirect("ErrorPage.aspx")
        End Try

    End Sub

    Private Sub CancelButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancelButton.Click
        Me.UserDataPanel.Visible = False
        Me.UserGridPanel.Visible = True
        Me.LookupDQFUserID.Visible = False
        Me.GridView1.DataBind()
    End Sub

    Private Sub DeleteButon_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles DeleteButon.Click
        Try
            Membership.DeleteUser(UserNameTextBox.Text)
            Dim DeleteUserAdapter As New UserDataTableAdapters.WSUsersToCompaniesTableAdapter
            DeleteUserAdapter.DeleteUser(UserNameTextBox.Text)
        Catch ex As Exception
            Session("ErrorText") = "An error has occurred:  " & ex.Message
            Response.Redirect("ErrorPage.aspx")
        End Try
        Response.Redirect("ManageCompanyUsers.aspx")
    End Sub

    Private Sub ApplyASPFilterButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ApplyASPFilterButton.Click
        Dim LoginFilter As Object = Nothing
        Dim LastNameFilter As Object = Nothing
        Dim FirstNameFilter As Object = Nothing
        Dim CorpNameFilter As Object = Nothing
        Dim NoFilter As Boolean = True

        If ASPLoginFilterTextBox.Text.Length > 0 Then
            LoginFilter = Me.ASPLoginFilterTextBox.Text
            Me.UserNameField.Value = ASPLoginFilterTextBox.Text
            NoFilter = False

        End If
        If ASPLastNameFilterTextBox.Text.Length > 0 Then
            LastNameFilter = Me.ASPLastNameFilterTextBox.Text
            NoFilter = False
            Me.LastNameField.Value = Me.ASPLastNameFilterTextBox.Text
        End If
        If ASPFirstNameFilterTextBox.Text.Length > 0 Then
            FirstNameFilter = Me.ASPFirstNameFilterTextBox.Text
            NoFilter = False
            Me.FirstNameField.Value = Me.ASPFirstNameFilterTextBox.Text
        End If

        If NoFilter Then
            GridView1.DataSourceID = "ObjectDataSource2"
            GridView1.DataBind()
            'DQFUserGridview.DataBind()
        Else
            'GridView1.DataSourceID = "ObjectDataSource3"
            'GridView1.DataBind()
            Dim UserTableAdapter As New UserDataTableAdapters.MembershipUsersTableAdapter
            GridView1.DataSourceID = ""
            GridView1.DataSource = UserTableAdapter.GetDataByFilters(LoginFilter, FirstNameFilter, LastNameFilter)
            GridView1.DataBind()
        End If

        'Session("DQFGridView_Datasource2") = DQFUserGridview.DataSource

    End Sub

    
End Class