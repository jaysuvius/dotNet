﻿Partial Class Logout
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim currentUser As System.Web.Security.MembershipUser
        'Redirect the user to the appropriate page if they are logged in
        currentUser = Membership.GetUser(HttpContext.Current.User.Identity.Name)
        If (currentUser Is Nothing) Then
            Response.Redirect("Login.aspx")
        End If
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Session("UserFullName") = Nothing
        Session("CompanyName") = Nothing
        Session("AccessLevel") = Nothing
        FormsAuthentication.SignOut()
        Response.Redirect("Login.aspx")
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("Default.aspx")
    End Sub
End Class