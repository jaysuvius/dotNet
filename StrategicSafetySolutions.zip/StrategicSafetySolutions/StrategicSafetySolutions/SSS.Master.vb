﻿Imports System.Web.ClientServices.Providers
Imports System.Net

Partial Public Class SSS
    Inherits System.Web.UI.MasterPage

    Public Property WelcomeLabel() As String
        Get
            Return lblWelcome.Text
        End Get
        Set(ByVal value As String)
            If lblWelcome.Text <> value Then
                lblWelcome.Text = value
            End If
        End Set
    End Property

    Public Property TopNavLabelText() As String
        Get
            Return TopNavLabel.Text
        End Get
        Set(ByVal value As String)
            If TopNavLabel.Text <> value Then
                TopNavLabel.Text = value
            End If
        End Set
    End Property


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.ID = "SSSMaster"
        If Session("UserFullName") IsNot Nothing Then
            UserNameHiddenField.Value = Session("UserFullName")
            CompanyNameHiddenField.Value = Session("CompanyName")
            If UserNameHiddenField.Value <> "" Then
                WelcomeLabel = "Welcome " & Me.UserNameHiddenField.Value & "(" & CompanyNameHiddenField.Value & ")"
            Else
                UserNameHiddenField.Value = ""
                CompanyNameHiddenField.Value = ""
                WelcomeLabel = ""
            End If
        End If

        If Session("AccessLevel") IsNot Nothing Then
            TopNavLabelText = "Access Level >> " & Session("AccessLevel")
        End If
    End Sub


End Class
