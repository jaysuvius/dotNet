using System;
using System.Configuration;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Collections.Specialized;

namespace CTPA.Common
{
    public class Config
    {

        #region properties
        /// <summary>
        /// The connection to the CTPA database
        /// </summary>
        public static string ConnectionString
        {
            get
            {
                string result;
                try
                {
                    
                    result = ConfigurationManager.ConnectionStrings["CTPAConnectionString"].ConnectionString;
                }
                catch (Exception ex)
                {
                    throw (new Exception("Could not get the connection string", ex));
                }
                return result;
            }
        }
        
        /// <summary>
        /// The public name of the web-base application
        /// </summary>
        public static string ProgramName
        {
            get
            {
                return "AADT Online";
            }
        }

        /// <summary>
        /// The name of the TPA
        /// </summary>
        public static string CompanyName
        {
            get
            {
                return "AADT";
            }
        }
        /// <summary>
        /// The generic message to show when a submission was saved in the database
        /// </summary>
        public static string SaveSuccess
        {
            get
            {
                return "Your change request has been submitted for approval.  You will be notified once the change has been reviewed.";
            }
        }


        /// <summary>
        /// Thhe generic error to show when a record could not be saved in the database
        /// </summary>
        public static string SaveError
        {
            get
            {
                return "There was an error saving changes to database. Please try again later.";
            }
        }


        /// <summary>
        /// Returns a list of PoolID with their Pool Names
        /// </summary>
        public static System.Collections.Specialized.NameValueCollection poolIDs
        {
            get
            {

                string[] poolNames = { "1-GENERAL CD POOL", "2-GENERAL OWNER OPERATOR POOL", "3-GENERAL DRUG FREE POOL", "4-GENERAL PUC POOL", "5-GENERAL PUC OO", "9-CD POOL - 9970", "10-DF POOL - 9970", "11-DF POOL - 2710", "12-DF Pool PUC", "13-CD POOL - 1035", "14-DF POOL - 1294", "15-CD POOL 878", "16-DF POOL 8125", "17-DF POOL - 2662", "18-DF POOL - TOW POOL CD", "19-DF POOL - TOW POOL O-O", "20-DF Pool - 2254", "21-TEXAS TDLR CE", "22-TEXAS TDLR O-O", "23-DF 50" };
                int[] poolIDs = { 1, 2, 3, 4, 5, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, };
                int arrayCounter = 0;
                NameValueCollection testingPools = new NameValueCollection();
                foreach(int poolID in poolIDs)
                {
                    testingPools.Add(poolID.ToString(), poolNames[arrayCounter]);
                    arrayCounter ++;
                }
                return testingPools;
            }
        }

        /// <summary>
        /// Returns a list of Pool Names with their Pool IDs
        /// </summary>
        public static System.Collections.Specialized.NameValueCollection poolNames
        {
            get
            {
                string[] poolNames = { "1-GENERAL CD POOL", "2-GENERAL OWNER OPERATOR POOL", "3-GENERAL DRUG FREE POOL", "4-GENERAL PUC POOL", "5-GENERAL PUC OO", "9-CD POOL - 9970", "10-DF POOL - 9970", "11-DF POOL - 2710", "12-DF Pool PUC", "13-CD POOL - 1035", "14-DF POOL - 1294", "15-CD POOL 878", "16-DF POOL 8125", "17-DF POOL - 2662", "18-DF POOL - TOW POOL CD", "19-DF POOL - TOW POOL O-O", "20-DF Pool - 2254", "21-TEXAS TDLR CE", "22-TEXAS TDLR O-O", "23-DF 50" };
                int[] poolIDs = { 1, 2, 3, 4, 5, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, };
                int arrayCounter = 0;
                NameValueCollection testingPools = new NameValueCollection();
                foreach (string poolName in poolNames)
                {
                    testingPools.Add(poolName, poolIDs[arrayCounter].ToString());
                    arrayCounter++;
                }
                return testingPools;
            }
        }

        /// <summary>
        /// Returns a list of OOS Status IDs with their OOS Reason Names
        /// </summary>
        public static System.Collections.Specialized.NameValueCollection OOSStatusIDs
        {
            get
            {
                string[] OOSReasonNames = { "ABSENCE / EMERGENCY LEAVE", "MEDICAL LEAVE", "VACATION" };
                int[]OOSIDs = { 4, 5, 7 };
                int arrayCounter = 0;
                NameValueCollection OOSStates = new NameValueCollection();
                foreach (int OOSID in OOSIDs)
                {
                    OOSStates.Add(OOSID.ToString(), OOSReasonNames[arrayCounter]);
                    arrayCounter++;
                }
                return OOSStates;
            }
        }



        /// <summary>
        /// Returns a list of OOS Reason Names with their OOS Status IDs
        /// </summary>
        public static System.Collections.Specialized.NameValueCollection OOSReasonNames
        {
            get
            {
                string[] OOSReasonNames = { "ABSENCE / EMERGENCY LEAVE", "MEDICAL LEAVE", "VACATION" };
                int[] OOSIDs = { 4, 5, 7 };
                int arrayCounter = 0;
                NameValueCollection OOSStates = new NameValueCollection();
                foreach (int OOSID in OOSIDs)
                {
                    OOSStates.Add(OOSReasonNames[arrayCounter], OOSID.ToString());
                    arrayCounter++;
                }
                return OOSStates;
            }
        }


        public static string HomeURL
        {
            get
            {
                return "https://tpa.aadrugtesting.com/CTPA/";
            }
        }


        
        /// <summary>
        /// Gets the membership user object of the currently logged in user
        /// </summary>
        /// <returns></returns>
        public static System.Web.Security.MembershipUser getWSUser
        {
            get
            {
                return System.Web.Security.Membership.GetUser();
            }
        }


        public static DateTime InitialDateTime
        {
            get
            {
                return DateTime.Parse("2/1/1950 00:00:00");
            }
        }

      

        #endregion

        #region functions

        /// <summary>
        /// Checks that the necessary roles for the application are created and repairs them if necessary
        /// </summary>
        public static void checkRoles()
        {
            //
            //It is likely that an exception generated when checking the roles here is due to issues with database connectivity/accessibility
            //Check the connection string in \CTPA\web.config
            //
            if (!System.Web.Security.Roles.RoleExists("CDATA"))
            {
                // This role is for CTPA Employees (account reps)
                System.Web.Security.Roles.CreateRole("CDATA");
            }
            if (!System.Web.Security.Roles.RoleExists("Superadmin"))
            {
                // This role is for CTPA Employees (administrators) - combine with CDATA role
                System.Web.Security.Roles.CreateRole("Superadmin");
            }
            if (!System.Web.Security.Roles.RoleExists("Unverified"))
            {
                // This role is for users who have not yet been matched to a company
                System.Web.Security.Roles.CreateRole("Unverified");
            }
            if (!System.Web.Security.Roles.RoleExists("Verified"))
            {
                // This role is for users who have been matched to a company
                System.Web.Security.Roles.CreateRole("Verified");
            }
            if (!System.Web.Security.Roles.RoleExists("Company"))
            {
                // This role is for CTPA Employees (administrators) - combine with CDATA role
                System.Web.Security.Roles.CreateRole("Company");
            }
            if (!System.Web.Security.Roles.RoleExists("Employee"))
            {
                // This role is for users who edit driver records
                System.Web.Security.Roles.CreateRole("Employee");
            }
            if (!System.Web.Security.Roles.RoleExists("Results"))
            {
                // This role is for users who access result records
                System.Web.Security.Roles.CreateRole("Results");
            }
            if (!System.Web.Security.Roles.RoleExists("WSAdmin"))
            {
                // This role is for users who manage their company's other web site users
                System.Web.Security.Roles.CreateRole("WSAdmin");
            }
            
            // Make sure the administrator account is set up correctly with roles CDATA and Superadmin
            // and NOT Verified or Unverified
            if (System.Web.Security.Membership.GetUser("Administrator") != null)
            {
                if (!System.Web.Security.Roles.IsUserInRole("Administrator", "CDATA"))
                {
                    //Add
                    System.Web.Security.Roles.AddUserToRole("Administrator", "CDATA");
                }
                if (!System.Web.Security.Roles.IsUserInRole("Administrator", "Superadmin"))
                {
                    //Add
                    System.Web.Security.Roles.AddUserToRole("Administrator", "Superadmin");
                }
                if (System.Web.Security.Roles.IsUserInRole("Administrator", "Verified"))
                {
                    //Remove
                    System.Web.Security.Roles.RemoveUserFromRole("Administrator", "Verified");
                }
                if (System.Web.Security.Roles.IsUserInRole("Administrator", "Unverified"))
                {
                    //Remove
                    System.Web.Security.Roles.RemoveUserFromRole("Administrator", "Unverified");
                }
            }
        }
        #endregion
    }
 }
