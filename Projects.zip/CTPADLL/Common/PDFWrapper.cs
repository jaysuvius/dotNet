using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Net;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

using System.Web.Services.Protocols;
using Rse2005 = CTPADLL.ReportExecution005;

namespace CTPA.Common
{

    public class PDFWrapper
    {
        private string RptMemo = "";

        public void RenderPdf(string compid, string strReportName, string strFullFilePath)
        {

            // Prepare Render arguments
            string strCompID = null;
            System.Guid FileGuid;
            string strFileName = null;
            string historyID = null;
            string deviceInfo = null;
            string format = "PDF";
            Byte[] results;
            string encoding = String.Empty;
            string mimeType = String.Empty;
            string extension = String.Empty;
            Rse2005.Warning[] warnings = null;
            string[] streamIDs = null;
            string strResponsePram = null;
            string strResponsePath = ConfigurationSettings.AppSettings["AppDocumentPath"];
            System.Text.StringBuilder sb = new System.Text.StringBuilder();


            Rse2005.ReportExecutionService rsExec = new Rse2005.ReportExecutionService();
            rsExec.Credentials = System.Net.CredentialCache.DefaultCredentials;

            Rse2005.ExecutionInfo ei = rsExec.LoadReport(strReportName, historyID);
            Rse2005.ParameterValue[] rptParameters = new Rse2005.ParameterValue[1];

            rptParameters[0] = new Rse2005.ParameterValue();
            rptParameters[0].Name = "COMP_ID";
            rptParameters[0].Value = compid;


            //render the PDF
            rsExec.SetExecutionParameters(rptParameters, "en-us");
            results = rsExec.Render(format, deviceInfo, out extension, out encoding, out mimeType, out warnings, out streamIDs);
            sb.Append(compid.ToString());
            sb.Append("_");
            FileGuid = Guid.NewGuid();
            strCompID = compid.ToString();
            strFileName = strCompID;
            strFileName += "_";
            strFileName += FileGuid.ToString();
            strResponsePram += "attachment; filename= ";
            strResponsePram += strFileName;
            strResponsePram += ".pdf";
            strResponsePath += strFileName;
            strResponsePath += ".pdf";
            FileStream stream = File.Create(strFullFilePath, results.Length);
            stream.Write(results, 0, results.Length);
            stream.Close();
        }
        public void RenderPdfNotice(string CompID, string UserID, int Notice, string Description, string Reason, string strBatchID, string strReport, string strReportName, bool Passport)
        {

            // Prepare Render arguments
            System.Guid FileGuid;
            string strFullFilePath = ConfigurationSettings.AppSettings["NoticePath"];
            string strFileName = null;
            string historyID = null;
            string deviceInfo = null;
            string format = "PDF";
            Byte[] results;
            string encoding = String.Empty;
            string mimeType = String.Empty;
            string extension = String.Empty;
            Rse2005.Warning[] warnings = null;
            string[] streamIDs = null;
            string strResponsePram = null;
            string strResponsePath =  ConfigurationSettings.AppSettings["NoticePath"];
            System.Text.StringBuilder sb = new System.Text.StringBuilder();


            Rse2005.ReportExecutionService rsExec = new Rse2005.ReportExecutionService();
            rsExec.Credentials = System.Net.CredentialCache.DefaultCredentials;

            Rse2005.ExecutionInfo ei = rsExec.LoadReport(strReport, historyID);
            Rse2005.ParameterValue[] rptParameters = new Rse2005.ParameterValue[1];

            rptParameters[0] = new Rse2005.ParameterValue();
            rptParameters[0].Name = "BATCHID";
            rptParameters[0].Value = strBatchID;


            //render the PDF
            rsExec.SetExecutionParameters(rptParameters, "en-us");
            results = rsExec.Render(format, deviceInfo, out extension, out encoding, out mimeType, out warnings, out streamIDs);
            sb.Append(strBatchID.ToString());
            sb.Append("_");
            FileGuid = Guid.NewGuid();
            strBatchID = strBatchID.ToString();
            strFileName = strBatchID;
            strFileName += "_";
            strFileName += strReportName;
            strFileName += "_";
            strFileName += FileGuid.ToString();
            strFileName += ".pdf";
            strFullFilePath += strFileName;
            strResponsePram += "attachment; filename= ";
            strResponsePram += strFileName;
            strResponsePram += ".pdf";
            strResponsePath += strFileName;
            strResponsePath += ".pdf";
            FileStream stream = File.Create(strFullFilePath, results.Length);
            stream.Write(results, 0, results.Length);
            stream.Close();
            string created = strFullFilePath;
            FileInfo finfo = new FileInfo(created);
            long FileInBytes = finfo.Length;
            long FileInKB = finfo.Length / 1024;
            if (((FileInKB > 90) && (!Passport)) || ((FileInKB > 300) && (Passport)))
            {
                CTPA.Entities.ReportTracker rt = new CTPA.Entities.ReportTracker();
                rt.BATCHID = strBatchID;
                rt.COMP_ID = CompID;
                rt.USER_ID = UserID;
                rt.NOTICE = Notice;
                rt.DATE_PRINTED = DateTime.Now;
                rt.FILE_PATH = strFullFilePath;
                rt.FILENAME = strFileName;
                rt.REASON_PRINT = Reason;
                rt.REPORT_DESCRIPTION = Description;
                rt.V_PATH = "/CTPA/Notices/";
                rt.Save();
            }
            else
            { File.Delete(created); }
        }

    }

}