using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using Microsoft.ApplicationBlocks.Data;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;


namespace CTPA.Common
{
    /// <summary>
    /// Masks a Dataview to represent the data as if the WS Update Table was applied. 
    /// </summary>
    public class ModeratedDVUpdater
    {
       /// <summary>
        /// Masks a Dataview to represent the data as if the WS Update Table was applied. 
       /// </summary>
       /// <param name="dv">DataView to Mask</param>
       /// <param name="DataType">Type of data to mask(Driver,Company)</param>
        public static void UpdateDataview(System.Data.DataView dv, string DataType)
        {
            UpdateDataTable(dv.Table,DataType);
        }

        public static DataTable UpdateDataTable(DataTable Table, string DataType)
        {
            Table.Columns.Add(new DataColumn("Updated", Type.GetType("System.Boolean")));
            foreach (System.Data.DataRow Row in Table.Rows)
            {
           
               if (DataType == "Employee")
               {
                   Row["Updated"] = false;
                   if (CTPA.Entities.Driver.checkPendingChange(Convert.ToInt32(Row["AutoID"])) != 0)
                   {
                        Entities.WSUpdate wsu = new CTPA.Entities.WSUpdate(Row["AutoID"].ToString(), "Employee");
                        NameValueCollection nvc;
                        if (wsu.ChangeDesc != "" && wsu.ChangeDesc != null)
                        {
                            nvc = UpdateDescParser.Parse(wsu.ChangeDesc);
                            foreach (string key in nvc.Keys)
                            {
                                if (nvc[key] == "")
                                {
                                    Row[key] = System.DBNull.Value;
                                }
                                else
                                {
                                    Row[key] = nvc[key];
                                }
                            }
                            Row["Updated"] = true;
                        }
                    }
                }
                else if (DataType == "Company")
                {
                }
                else
                {
                    throw (new Exception("Attempted to update a moderated datarow of unknown type"));
                }
            }        
            return Table;
        }
    }
}
