using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace CTPA.Common

{
    /// <summary>
    /// Class used to manage the relationships that link the .Net Membership Class to TPA data.  (Companies)
    /// This is class is necessary because the standard .Net Profile provider does not allow an index
    /// on the web site user's company ID.
    /// </summary>
    public class MembershipTracking
    {
        /// <summary>
        /// Links a Membership user name to a company ID
        /// </summary>
        /// <param name="memberUserName">Membership username</param>
        /// <param name="companyID">TPA Company ID</param>
        public static void AddWSUserToCompany(string memberUserName, double companyID)
        {
            Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(CTPA.Common.Config.ConnectionString, CommandType.Text, "INSERT INTO dbo.WSUserstoCompanies(username, COMP_ID) VALUES ('" + memberUserName + "', " + companyID.ToString() + ");");
        }
        /// <summary>
        /// Updates a Membership Name's related company ID.  Name is the PK
        /// </summary>
        /// <param name="memberUserName">Membership username</param>
        /// <param name="newCompanyID">TPA CompanyID</param>
        public static void ChangeWSUserCompany(string memberUserName, float newCompanyID)
        {
            Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(CTPA.Common.Config.ConnectionString, CommandType.Text, "UPDATE dbo.WSUserstoCompanies SET COMP_ID = " + newCompanyID.ToString() + " WHERE username = '" + memberUserName + "';");
        }

        /// <summary>
        /// Returns a DS with Users that are related to the Company ID specified. 
        /// </summary>
        /// <param name="companyID">TPA Company ID</param>
        /// <returns></returns>
        public static DataSet GetWSUsersInCompany(float companyID)
        {
            return Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteDataset(CTPA.Common.Config.ConnectionString, CommandType.Text, "SELECT username FROM dbo.WSUserstoCompanies WHERE COMP_ID = " + companyID.ToString() + ";");
        }

        /// <summary>
        /// Returns the TPA company ID that a user belongs to. 
        /// </summary>
        /// <param name="memberUserName">Membership username</param>
        /// <returns></returns>
        public static double GetWSUserCompany(string memberUserName)
        {
            return Convert.ToDouble(Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, "SELECT COMP_ID FROM dbo.WSUserstoCompanies WHERE username= '" + memberUserName + "';"));
        }
    /// <summary>
    /// Delete a username from the WSUserstoCompaies Table.   ie.  Remove the user realationship to any company
    /// </summary>
    /// <param name="memberUserName">Membership username</param>
        public static void DelWSUser(string memberUserName)
        {
            Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(CTPA.Common.Config.ConnectionString, CommandType.Text, "DELETE FROM dbo.WSUserstoCompanies WHERE username = '" + memberUserName + "';");
        }
    }
}
