using System;
using System.Collections.Generic;
using System.Text;

namespace CTPA.Common
{
    public class Emailer
    {
        private Emailer()
        {
        }

        /// <summary>
        /// Send notification Email to the user attached to the record. 
        /// </summary>
        /// <param name="wsu">wsu record that was approved/denied</param>
        /// <param name="Status">String Contains "Approved" Or "Deinied"</param>
        /// <remarks></remarks>

        public static bool ApprovalStatusNotifyByEmail(CTPA.Entities.WSUpdate wsu, string Status, string emailaddress, string reviewer)
        {

            // Split the desc into first part up to '=" 
            string fp = wsu.ChangeDesc.Split('=')[0] + "<br>";
            string[] sp = wsu.ChangeDesc.Split('=')[1].Split(';');
            string bd;



            if (wsu.getFriendlyDesc().Contains("Website driver add") || wsu.getFriendlyDesc().Contains("Website driver OOS")
                || wsu.getFriendlyDesc().Contains("Website driver deactivation") || wsu.getFriendlyDesc().Contains("Website driver reactivation"))
            {
                bd = wsu.getFriendlyDesc();
            }
            else
            {
                if (Status != "Denied")
                {
                    bd = fp + "<br>";
                    foreach (string update in sp)
                    {
                        bd += "<b>" + update + "</b><br>";
                    }
                }
            }
            bd = "These changes have been reviewed and have been <u> " + Status + "</u>.<br>Thank you for using the AADT update portal.";

            try
            {
                SendEmail( wsu.ChangeType.Trim() + " Change - ID #" + wsu.ChangeID, wsu.ChangeType.Trim() + "s@aadtonline.com", emailaddress, true, bd);
                return true;
            }
            catch (Exception exception)
            {
                return false;
            }

        }

        public static bool VerifiedStatusNotifyByEmail(System.Web.Security.MembershipUser userAcct, bool Approved, string reviewer)
        {
            string bd, subj;

            if (Approved)
            {
                bd = "Your request for a new user account has been approved." + "<br>" + "You may now log into the " + Config.ProgramName + " web site <a href=\"" + Config.HomeURL + "\">here</a>.";
                subj = "Request for web site membership approved";
            }
            else
            {
                bd = "Your request for a new user account has been denied.  Please contact " + Common.Config.CompanyName + " for assistance.";
                subj = "Request for web site membership denied";
            }
            try
            {
                SendEmail(subj, "TPA@AADrugTesting.com", userAcct.Email, true, bd);
                return true;
            }
            catch (Exception exception)
            {
                return false;
            }

        }

        public static bool PendingStatusNotifyByEmail(System.Web.Security.MembershipUser userAcct, bool Pending, string reviewer)
        {
            string bd, subj;

            if (Pending)
            {
                bd = "Your AADT Request has been submitted and is pending." + "<br>" + "You may now log into the " + Config.ProgramName + " web site <a href=\"" + Config.HomeURL + "\">here</a>.";
                subj = "Request for web site membership Pending";
            }
            else
            {
                bd = "Your Pending Request has been denied.  Please contact " + Common.Config.CompanyName + " for assistance.";
                subj = "Pending Request Denied";
            }
            try
            {
                SendEmail(subj, "TPA@AADrugTesting.com", userAcct.Email, true, bd);
                return true;
            }
            catch (Exception exception)
            {
                return false;
            }

        }

        public static bool RenewalApprovalNotifyByEmail(System.Web.Security.MembershipUser userAcct, bool Approved)
        {
            string bd, subj;

            if (Approved)
            {
                bd = "Your AADT Renewal Has Been Approved!.";
                subj = "AADT Renewal Approved";
            }
            else
            {
                bd = "Your Pending Renewal has been Denied.  Please contact AADT for assistance.";
                subj = "Pending Renewal Denied";
            }
            try
            {
                SendEmail(subj, "TPA@AADrugTesting.com", userAcct.Email, true, bd);
                return true;
            }
            catch (Exception exception)
            {
                return false;
            }

        }
        public static bool ErLogEmail(bool Error)
        {
            string bd, subj;

            if (Error)
            {
                bd = "An error has occurred in TPA online.  Please check the errorlog table for details.";
                subj = "Error in TPA Online";
            }
            else
            {
                bd = "An error has occurred in TPA online.  Please check the errorlog table for details.";
                subj = "Error in TPA Online";
            }
            try
            {
                SendEmail(subj, "TPA@AADrugTesting.com", "mattp@resourcecomputer.com", true, bd);
                return true;
            }
            catch (Exception exception)
            {
                return false;
            }

        }

        public static bool BrokerNotify(bool Notify, string eaddress)
        {
            string bd, subj;

            if (Notify)
            {
                bd = "One or more of your broker agreements has had recent activity. <br> <br> Please log on to https://tpa.aadrugtesting.com/ctpa to view your activity.";
                subj = "Broker Agreement Activity";
            }
            else
            {
                bd = "";
                subj = "";
            }
            try
            {
                SendEmail(subj, "TPA@AADrugTesting.com", eaddress, true, bd);
                return true;
            }
            catch (Exception exception)
            {
                return false;
            }
        }
        private static void SendEmail(string Subject, string From, string MailTo, bool HTML, string Body)
        {
            // Should put a check in here to verify that the email addresses are valid!!
            System.Net.Mail.MailMessage m = new System.Net.Mail.MailMessage();
            m.Subject = Subject.Trim();
            m.From = new System.Net.Mail.MailAddress(From.Trim());
            m.To.Add(new System.Net.Mail.MailAddress(MailTo.Trim()));
            m.IsBodyHtml = HTML;
            m.Body = Body;
            System.Net.Mail.SmtpClient cl = new System.Net.Mail.SmtpClient("192.168.0.8",25);
            cl.Send(m);
            m.Dispose();
            m = null;
        }

    }
}
