using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;

namespace CTPA.Common
{
    public class UpdateDescParser
    {
        public static NameValueCollection Parse(string UpdateDesc)
        {
            string fieldname;
            string valuename;
            char[] equals = new char[1];
            equals[0] = '=';
            char[] semicolon = new char[1];
            semicolon[0] = ';';
            char[] space = new char[1];
            space[0] = ' ';
            NameValueCollection nvc = new NameValueCollection();
            UpdateDesc = UpdateDesc.Split(equals)[1];
            string[] temp = UpdateDesc.Split(semicolon);
            foreach (string item in UpdateDesc.Split(semicolon))
            {
                if (item != "")
                {
                    valuename = string.Empty;
                    fieldname = item.Split(space)[0];
                    foreach (string word in item.Split(space))
                    {
                        valuename = word;
                    }
                    nvc.Add(fieldname, valuename);
                }
            }
            return nvc;
        }
    }
}
