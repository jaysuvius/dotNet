using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace CTPA.Common
{
    public class Validator
    {
        #region Properties
        public static string InvalidFieldMarker
        {
            get
            {
                return "Please Correct";
            }
        }
        #endregion

        #region Methods
        private Validator()
        {
        }

        public static string ValidateAddress(string inputField)
        {
            // Here is where we need to check for a match - use a regex possibly.
            Regex Address = new Regex("^\\d?\\d?\\d?\\d?\\d?\\d?(\\d\\s)?\\s*(\\w\\w*.?)(\\s\\s*\\w\\w*.?)?(\\s\\s*\\w\\w*.?)?(\\s\\s*\\w\\w*.?)?(\\s\\s*\\w\\w*.?)?(\\s\\s*\\w\\w*.?)?(\\s\\s*\\d)?\\d?\\d?\\d?$");
            if (Address.Matches(inputField.Trim()).Count <=0 )
            {
                return string.Empty;
            }
            else
            {
                return capitalizeAllWords(inputField);
            }
        }

        public static void ValidateAddress(ref System.Web.UI.WebControls.TextBox inputBox)
        {
            if (ValidateAddress(inputBox.Text) == string.Empty && inputBox.Text.Trim() != string.Empty &&!inputBox.Text.Contains(InvalidFieldMarker))
            {
                inputBox.Text = InvalidFieldMarker + "(" + inputBox.Text + ")";
            }
            else
            {
                inputBox.Text = ValidateAddress(inputBox.Text);
            }
        }

        public static string ValidateDate(string inputField)
        {
            DateTime dt;
            try
            {
                dt = DateTime.Parse(inputField);
            }
            catch (Exception e)
            {
                return "";
            }
            return dt.ToShortDateString();
        }

        public static void ValidateDate(ref System.Web.UI.WebControls.TextBox inputBox)
        {

            if (ValidateDate(inputBox.Text) == string.Empty && inputBox.Text.Trim() != string.Empty && !inputBox.Text.Contains(InvalidFieldMarker))
            {
                inputBox.Text = InvalidFieldMarker + "(" + inputBox.Text + ")";
            }
            else
            {
                inputBox.Text = ValidateDate(inputBox.Text);
            }
        }

        public static string ValidateState(string inputField)
        {
            // Here is where we need to check for a match - use a regex possibly.
            Regex State = new Regex("^[a-zA-Z]{2}$");
            if (State.Matches(inputField.Trim()).Count <= 0)
            {
                return string.Empty;
            }
            else
            {
                return inputField.ToUpper();
            }
        }

        public static void ValidateState(ref System.Web.UI.WebControls.TextBox inputBox)
        {
            if (ValidateState(inputBox.Text) == string.Empty && inputBox.Text.Trim() != string.Empty && !inputBox.Text.Contains(InvalidFieldMarker))
            {
                inputBox.Text = InvalidFieldMarker + "(" + inputBox.Text + ")";
            }
            else
            {
                inputBox.Text = ValidateState(inputBox.Text);
            }
        }
        
        public static string ValidateZIP(string inputField)
        {
            // Here is where we need to check for a match - use a regex possibly.
            Regex zip = new Regex("^\\d{5}(\\s*-?\\s*\\d{4})?$");
            if (zip.Matches(inputField.Trim()).Count <= 0)
            {
                return string.Empty;
            }
            else
            {
                return formatZIP(inputField);
            }
        }

        public static void ValidateZIP(ref System.Web.UI.WebControls.TextBox inputBox)
        {
            if (ValidateZIP(inputBox.Text) == string.Empty && inputBox.Text.Trim() != string.Empty && !inputBox.Text.Contains(InvalidFieldMarker))
            {
                inputBox.Text = InvalidFieldMarker + "(" + inputBox.Text + ")";
            }
            else
            {
                inputBox.Text = ValidateZIP(inputBox.Text);
            }
        }
        
        public static string ValidateSSN(string inputField)
        {
            string SSNRegex = "^\\s*\\d{3}\\s*-?\\s*\\d{2}\\s*-?\\s*\\d{4}\\s*$";
            Regex SSN = new Regex(SSNRegex);
            if (SSN.Matches(inputField.Trim()).Count <= 0)
            {
                return string.Empty;
            }
            else
            {
                return formatSSN(inputField);
            }
        }

        public static void ValidateSSN(ref System.Web.UI.WebControls.TextBox inputBox)
        {
            if (ValidateSSN(inputBox.Text) == string.Empty && inputBox.Text.Trim() != string.Empty && !inputBox.Text.Contains(InvalidFieldMarker))
            {
                inputBox.Text = InvalidFieldMarker + "(" + inputBox.Text + ")";
            }
            else
            {
                inputBox.Text = ValidateSSN(inputBox.Text);
            }
        }
                
        public static string ValidateName(string inputField, int maxNameWords)
        {
            string regexString = "^\\w\\w*";
            for (int i = 2; i <= maxNameWords; i++)
            {
                regexString = regexString + "(\\s\\s*\\w\\w*)?";
            }
            regexString = regexString + "$";
            Regex Name = new Regex(regexString);
            if (Name.Matches(inputField.Trim()).Count <= 0)
            {
                return string.Empty;
            }
            else
            {
                return capitalizeFirstWord(inputField);
            }
        }
        
        public static void ValidateName(ref System.Web.UI.WebControls.TextBox inputBox, int maxNameWords)
        {
            if (ValidateName(inputBox.Text, maxNameWords) == string.Empty && inputBox.Text.Trim() != string.Empty && !inputBox.Text.Contains(InvalidFieldMarker))
            {
                inputBox.Text = InvalidFieldMarker + "(" + inputBox.Text + ")";
            }
            else
            {
                inputBox.Text = ValidateName(inputBox.Text, maxNameWords);
            }
        }

        public static string ValidateTitleName(string inputField)
        {
            string regexString="^\\w\\w*(\\s*\\w\\w*)*.?$";
            Regex titleName = new Regex(regexString);
            if (titleName.Matches(inputField.Trim()).Count <= 0)
            {
                return string.Empty;
            }
            else
            {
                return capitalizeFirstWord(inputField);
            }
        }

        public static void ValidateTitleName(ref System.Web.UI.WebControls.TextBox inputBox)
        {
            if (ValidateTitleName(inputBox.Text) == string.Empty && inputBox.Text.Trim() != string.Empty && !inputBox.Text.Contains(InvalidFieldMarker))
            {
                inputBox.Text = InvalidFieldMarker + "(" + inputBox.Text + ")";
            }
            else
            {
                inputBox.Text = ValidateTitleName(inputBox.Text);
            }
        }
        
        public static string ValidatePhone(string inputField)
        {
            string PhoneRegex = "^\\s*1?\\s*-?\\s*(\\d{3}|\\(\\s*\\d{3}\\s*\\))\\s*-?\\s*\\d{3}\\s*-?\\s*\\d{4}$";
            Regex Phone = new Regex(PhoneRegex);
            if (Phone.Matches(inputField.Trim()).Count <= 0)
            {
                return string.Empty;
            }
            else
            {
                return formatPhoneNumber(inputField);
            }
        }
                
        public static void ValidatePhone(ref System.Web.UI.WebControls.TextBox inputBox)
        {
            if (ValidatePhone(inputBox.Text) == string.Empty && inputBox.Text.Trim() != string.Empty && !inputBox.Text.Contains(InvalidFieldMarker))
            {
                inputBox.Text = InvalidFieldMarker + "(" + inputBox.Text + ")";
            }
            else
            {
                inputBox.Text = ValidatePhone(inputBox.Text);
            }
        }

        public static string ValidateCity(string inputField)
        {
            string CityRegex = "^\\s*\\w\\w*(\\s*\\w\\w*)(\\s*\\w\\w*)(\\s*\\w\\w*)(\\s*\\w\\w*)\\s*$";
            Regex City = new Regex(CityRegex);
            if (City.Matches(inputField.Trim()).Count <= 0)
            {
                return string.Empty;
            }
            else
            {
                return capitalizeAllWords(inputField);
            }
        }

        public static void ValidateCity(ref System.Web.UI.WebControls.TextBox inputBox)
        {
            if (ValidateCity(inputBox.Text) == string.Empty && inputBox.Text.Trim() != string.Empty && !inputBox.Text.Contains(InvalidFieldMarker))
            {
                inputBox.Text = InvalidFieldMarker + "(" + inputBox.Text + ")";
            }
            else
            {
                inputBox.Text = ValidateCity(inputBox.Text);
            }
        }

        public static string ValidateDL(string inputField)
        {
            string DLRegex = "^\\w\\w\\w\\w?\\w?\\w?\\w?\\w?\\w?\\w?\\w?\\w?\\w?\\w?\\w?\\w?\\w?\\w?\\w?\\w?$";
            Regex DL = new Regex(DLRegex);
            if (DL.Matches(inputField.Trim()).Count <= 0)
            {
                return string.Empty;
            }
            else
            {
                return inputField.Trim().ToUpper();
            }
        }

        public static void ValidateDL(ref System.Web.UI.WebControls.TextBox inputBox)
        {
            if (ValidateDL(inputBox.Text) == string.Empty && inputBox.Text.Trim() != string.Empty && !inputBox.Text.Contains(InvalidFieldMarker))
            {
                inputBox.Text = InvalidFieldMarker + "(" + inputBox.Text + ")";
            }
            else
            {
                inputBox.Text = ValidateDL(inputBox.Text);
            }
        }
           
        public static string capitalizeAllWords(string inputField)
        {
            char[] spaces = {' '};
            string[] words = inputField.Split(spaces,StringSplitOptions.RemoveEmptyEntries);
            StringBuilder sb = new StringBuilder();
            foreach (string word in words)
            {
               sb.Append(capitalizeFirstWord(word) + " ");
            }
            sb.Remove(sb.Length - 1,1);
            return sb.ToString();
        }

        public static string capitalizeFirstWord(string inputField)
        {
            string word = inputField.Trim();
            if (word.Length > 1)
            {
                return word.ToUpper().ToCharArray()[0] + word.Substring(1);
            }
            else
            {
                return word.ToUpper();
            }
        }

        private static string formatPhoneNumber(string inputField)
        {
            Regex one = new Regex("\\d");
            if (one.Matches(inputField)[0].Value == "1")
            {
                // If the first digit is a one, remove it
                inputField = inputField.Substring(inputField.IndexOf('1') + 1);
            }
            if (one.Matches(inputField).Count != 10)
            {
                // If there are not still 10 digits, return an empty string
                return "";
            }
            //Otherwise return the formatted phone number
            Regex three = new Regex("\\d{3}");
            Regex four = new Regex("\\d{4}");
            string areaCode, prefix, lastfour, remaining;
            areaCode = three.Matches(inputField)[0].Value;
            remaining = inputField.Substring(inputField.IndexOf(areaCode) + 3, inputField.Length - (inputField.IndexOf(areaCode) + 3));
            prefix = three.Matches(remaining)[0].Value;
            remaining = remaining.Substring(remaining.IndexOf(prefix) + 3, remaining.Length - (remaining.IndexOf(prefix) + 3));
            lastfour = four.Matches(remaining)[0].Value;
            return areaCode + "-" + prefix + "-" + lastfour;
        }

        private static string formatSSN(string inputField)
        {
            Regex one = new Regex("\\d");
            if (one.Matches(inputField).Count != 9)
            {
                // If there are not 9 digits, return an empty string
                return "";
            }
            //Otherwise return the formatted ssn
            Regex two = new Regex("\\d{2}");
            Regex three = new Regex("\\d{3}");
            Regex four = new Regex("\\d{4}");
            string firstthree, middletwo, lastfour, remaining;
            firstthree = three.Matches(inputField)[0].Value;
            remaining = inputField.Substring(inputField.IndexOf(firstthree) + 3, inputField.Length - (inputField.IndexOf(firstthree) + 3));
            middletwo = two.Matches(remaining)[0].Value;
            remaining = remaining.Substring(remaining.IndexOf(middletwo) + 2, remaining.Length - (remaining.IndexOf(middletwo) + 2));
            lastfour = four.Matches(remaining)[0].Value;
            return firstthree + "-" + middletwo + "-" + lastfour;
        }

        private static string formatZIP(string inputField)
        {
            Regex one = new Regex("\\d");
            if (one.Matches(inputField).Count != 5 && one.Matches(inputField).Count != 9)
            {
                // If there are not 5 or 9 digits, return an empty string
                return "";
            }
            
            //Otherwise return the formatted ssn
            Regex five = new Regex("\\d{5}");
            Regex four = new Regex("\\d{4}");
            string firstfive, lastfour, remaining;
            firstfive = five.Matches(inputField)[0].Value;
            remaining = inputField.Substring(inputField.IndexOf(firstfive) + 5, inputField.Length - (inputField.IndexOf(firstfive) + 5));
            if (one.Matches(inputField).Count == 5)
            {
                // Five digits specified
                lastfour = "0000";
            }
            else
            {
                // Nine digits specified
                lastfour = four.Matches(remaining)[0].Value;
            }
            return firstfive + "-" + lastfour;
        }
        #endregion
    }
}
