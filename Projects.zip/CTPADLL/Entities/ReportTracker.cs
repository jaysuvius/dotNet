using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace CTPA.Entities
{
    public class ReportTracker {
#region Declarations
        private string _FILENAME;
        private string _COMP_ID;
		private string _USER_ID;
		private string _REPORT_DESCRIPTION;
		private string _REASON_PRINT;
		private string _FILE_PATH;
		private DateTime _DATE_PRINTED = CTPA.Common.Config.InitialDateTime;
		private string _PARENT;
        private string _CHILD;
        private string _V_PATH;
        private string _BATCHID;
        private int _NOTICE;

#endregion

#region Properties
        public string FILENAME { get { return _FILENAME; } set { _FILENAME = value; } }
        public string COMP_ID { get { return _COMP_ID; } set { _COMP_ID = value; try { LoadReportTracker(); } catch (Exception ex) { } } }
        public string USER_ID { get { return _USER_ID; } set { _USER_ID = value; } }
        public string REPORT_DESCRIPTION { get { return _REPORT_DESCRIPTION; } set { _REPORT_DESCRIPTION = value; } }
        public string REASON_PRINT { get { return _REASON_PRINT; } set { _REASON_PRINT = value; } }
        public string FILE_PATH { get { return _FILE_PATH; } set { _FILE_PATH = value; } }
        public DateTime DATE_PRINTED { get { return _DATE_PRINTED; } set { _DATE_PRINTED = value; } }
        public string PARENT { get { return _PARENT; } set { _PARENT = value; } }
        public string CHILD { get { return _CHILD; } set { _CHILD = value; } }
        public string V_PATH { get { return _V_PATH; } set { _V_PATH = value; } }
        public string BATCHID { get { return _BATCHID; } set { _BATCHID = value; } }
        public int NOTICE { get { return _NOTICE; } set { _NOTICE = value; } }


#endregion
        	// constructor
		public ReportTracker () {
		}

		public ReportTracker(string LoadID)
		{
			_FILENAME = LoadID;
			LoadReportTracker();
		}
        public void Save()
        {
            try
            {
                SqlDataReader reader = GetReportTracker();

                if (reader.HasRows)
                {
                    Update();

                }
                else
                {
                    Insert();

                }

            }
            catch (Exception ex)
            {
                //Changeme

                throw (new Exception("Insert Error!", ex));

                //Insert();
            }
        }
        
        private void Insert()
        {
            SqlParameter[] prams = new SqlParameter[1];
            prams[0] = new SqlParameter("@FILENAME", SqlDbType.NVarChar);
            prams[0].Value = _FILENAME;
            SqlHelper.ExecuteNonQuery(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.REPORT_TRACKER_Insert", prams);
            Update();
        }

        public void Update()
        {
            SqlParameter[] prams = new SqlParameter[12];
            prams[0] = new SqlParameter("@FILENAME", SqlDbType.NVarChar);
            prams[0].Value = FILENAME;
            prams[1] = new SqlParameter("@COMP_ID", SqlDbType.BigInt);
            prams[1].Value = COMP_ID;
            prams[2] = new SqlParameter("@USER_ID", SqlDbType.NVarChar);
            prams[2].Value = USER_ID;
            prams[3] = new SqlParameter("@REPORT_DESCRIPTION", SqlDbType.NVarChar);
            prams[3].Value = REPORT_DESCRIPTION;
            prams[4] = new SqlParameter("@REASON_PRINT", SqlDbType.NVarChar);
            prams[4].Value = REASON_PRINT;
            prams[5] = new SqlParameter("@FILE_PATH", SqlDbType.NVarChar);
            prams[5].Value = FILE_PATH;
            prams[6] = new SqlParameter("@DATE_PRINTED", SqlDbType.DateTime);
            if (_DATE_PRINTED != CTPA.Common.Config.InitialDateTime)
            {
                prams[6].Value = _DATE_PRINTED;
            }
            else
            {
                prams[6].Value = System.DBNull.Value;
            }
            prams[7] = new SqlParameter("@PARENT", SqlDbType.NVarChar);
            prams[7].Value = _PARENT;
            prams[8] = new SqlParameter("@CHILD", SqlDbType.NVarChar);
            prams[8].Value = _CHILD;
            prams[9] = new SqlParameter("@V_PATH", SqlDbType.NVarChar);
            prams[9].Value = _V_PATH;
            prams[10] = new SqlParameter("@BATCHID", SqlDbType.BigInt);
            prams[10].Value = _BATCHID;
            prams[11] = new SqlParameter("@NOTICE", SqlDbType.Int);
            prams[11].Value = _NOTICE;
            SqlHelper.ExecuteNonQuery(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.REPORT_TRACKER_Update", prams);

        }



		// LoadReportTracker
		private void LoadReportTracker()
		{
			SqlDataReader reader = GetReportTracker();
			try
			{
				if (reader.HasRows)
				{
					if (reader.Read())
					{
                        if (reader["FILENAME"] != System.DBNull.Value)
                        {
                            _FILENAME = reader["FILENAME"].ToString();
                        }
                        if (reader["COMP_ID"] != System.DBNull.Value)
                        {
                            _COMP_ID = reader["COMP_ID"].ToString();
                        }
                        if (reader["USER_ID"] != System.DBNull.Value)
                        {
                            _USER_ID = reader["USER_ID"].ToString();
                        }
                        if (reader["REPORT_DESCRIPTION"] != System.DBNull.Value)
                        {
                            _REPORT_DESCRIPTION = reader["REPORT_DESCRIPTION"].ToString();
                        }
                        if (reader["REASON_PRINT"] != System.DBNull.Value)
                        {
                            _REASON_PRINT = reader["REASON_PRINT"].ToString();
                        }
                        if (reader["DATE_PRINTED"] != System.DBNull.Value)
                        {
                            _DATE_PRINTED = Convert.ToDateTime(reader["DATE_PRINTED"]);
                        }                        
                        if (reader["FILE_PATH"] != System.DBNull.Value)
                        {
                            _FILE_PATH = reader["FILE_PATH"].ToString();
                        }
                        if (reader["PARENT"] != System.DBNull.Value)
                        {
                            _PARENT = reader["PARENT"].ToString();
                        }
                        if (reader["CHILD"] != System.DBNull.Value)
                        {
                            _CHILD = reader["CHILD"].ToString();
                        }
                        if (reader["V_PATH"] != System.DBNull.Value)
                        {
                            _CHILD = reader["V_PATH"].ToString();
                        }
                        if (reader["BATCHID"] != System.DBNull.Value)
                        {
                            _CHILD = reader["BATCHID"].ToString();
                        }
                        if (reader["NOTICE"] != System.DBNull.Value)
                        {
                            _CHILD = reader["NOTICE"].ToString();
                        }
                    }
				}
			}
			catch (Exception ex)
			{
				throw(new Exception("Unable to load ReportTracker from database", ex));
			}
		}

		private SqlDataReader GetReportTracker()
		{
			SqlParameter[] prams = new SqlParameter[1];
			prams[0] = new SqlParameter("@FILENAME", SqlDbType.NVarChar);
			prams[0].Value = _FILENAME;
			return (SqlHelper.ExecuteReader(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.REPORT_TRACKER_Select", prams));
			
		}
	}
}