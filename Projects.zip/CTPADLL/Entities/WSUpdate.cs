using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Text;
using Microsoft.ApplicationBlocks.Data;


namespace CTPA.Entities
{
    /// <summary>
    /// Provided a structure to create and process the database approval system.   
    /// Represents one Record in the changes table and its associated update command. 
    /// Used to store user submitted changes until a TPA user approves them. 
    /// </summary>
    public class WSUpdate
    {
#region Declarations
		private string _username;
        private string _ChangeRecordKey;
		private string _ChangeType;
		private bool _Pending;
		private string _ChangeDesc;
		private string _UpdateCmd;
		private DateTime _TimeRequested;
		private DateTime _TimeCommitted;
		private string _TimeStamp;
		private bool _Approved;
		private int _ChangeID;
        private string _ApprovedBy;

#endregion

		// constructor
        /// <summary>
        /// Create a Null WSUpdate Class.  NOT USED
        /// </summary>
		public WSUpdate ()
        {
            this._username = Common.Config.getWSUser.UserName;
		}
        /// <summary>
        /// Create a WSUpdate Class loaded with a record using the Unique PK ChangeID
        /// </summary>
        /// <param name="LoadID">WS_Updates.ChangeID</param>
		public WSUpdate(int LoadID)
		{
			_ChangeID = LoadID;
			LoadWSUpdate();
		}
        /// <summary>
        /// Create a WSUpdate Class for an exisitng change that is pending.
        /// </summary>
        /// <param name="RecordKey">WS_Updates.ChangeRecordKey</param>
        /// <param name="DataType">WS_Updates.ChangeType(Driver,Company)</param>
        public WSUpdate(string RecordKey, string DataType)
        {
            _ChangeRecordKey = RecordKey;
            _ChangeType = DataType;
            LoadWSUpdate();
        }

#region Properties

        /// <summary>
        ///Gets or sets WS_Updates.Username
        /// </summary>
		public string username {get {return _username;} set {_username = value;}}
        /// <summary>
        /// Gets or sets WS_Updates.ChangeRecordkey
        /// </summary>
		public string ChangeRecordKey {get {return _ChangeRecordKey;} set {_ChangeRecordKey = value;}}
        /// <summary>
        /// Gets or sets WS_Updates.ChangeType
        /// </summary>
		public string ChangeType {get {return _ChangeType;} set {_ChangeType = value;}}
        /// <summary>
        /// Gets or sets WS_Updates.Pending
        /// </summary>
		public bool Pending {get {return _Pending;} set {_Pending = value;}}
        /// <summary>
        /// Gets or sets WS_Updates.ChangeDesc
        /// </summary>
		public string ChangeDesc {get {return _ChangeDesc;} set {_ChangeDesc = value;}}
        /// <summary>
        /// Gets or sets WS_Updates.UpdateCmd
        /// </summary>
		public string UpdateCmd {get {return _UpdateCmd;} set {_UpdateCmd = value;}}
        /// <summary>
        /// TimeRequested
        /// </summary>
		public DateTime TimeRequested {get {return _TimeRequested;} set {_TimeRequested = value;}}
        /// <summary>
        /// Gets or sets WS_Updates.TimeCommited
        /// </summary>
		public DateTime TimeCommitted {get {return _TimeCommitted;} set {_TimeCommitted = value;}}
        /// <summary>
        /// Gets or sets WS_Updates.TimeStamp
        /// </summary>
		public string TimeStamp {get {return _TimeStamp;} set {_TimeStamp = value;}}
        /// <summary>
        /// Gets or sets WS_Updates.Approved
        /// </summary>
		public bool Approved {get {return _Approved;} set {_Approved = value;}}
        /// <summary>
        /// Gets or sets WS_Updates.ChangeID *PK  - Should not Change  
        /// </summary>
		public int ChangeID {get {return _ChangeID;} set {_ChangeID = value;}}
        /// <summary>
        /// Gets or set WS_Update.ApprovedBy  
        /// </summary>
        public string ApprovedBy { get { return _ApprovedBy; } set { _ApprovedBy = value; } }
#endregion

		
        /// <summary>
        /// Calls a SP to insert the current WSupdate record into the WSUpdate Table
        /// </summary>
		public void Insert()
		{
            SqlParameter[] prams = new SqlParameter[6];
            prams[0] = new SqlParameter("@username", SqlDbType.NChar);
            prams[0].Value = _username;
            prams[1] = new SqlParameter("@ChangeRecordKey", SqlDbType.NChar);
            prams[1].Value = _ChangeRecordKey;
            prams[2] = new SqlParameter("@ChangeType", SqlDbType.NChar);
            prams[2].Value = _ChangeType;
            prams[3] = new SqlParameter("@ChangeDesc", SqlDbType.NText);
            prams[3].Value = _ChangeDesc;
            prams[4] = new SqlParameter("@UpdateCmd", SqlDbType.NText);
            prams[4].Value = _UpdateCmd;
            prams[5] = new SqlParameter("@TimeRequested", SqlDbType.DateTime);
            prams[5].Value = _TimeRequested;
            SqlHelper.ExecuteNonQuery(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.WS_UPDATES_Insert", prams);            
		}

        /// <summary>
        /// Calls a SP to update the current WS_update Record. 
        /// </summary>
        public void Update()
        {
            SqlParameter[] prams = new SqlParameter[11];
            prams[0] = new SqlParameter("@username", SqlDbType.NChar);
            prams[0].Value = _username;
            prams[1] = new SqlParameter("@ChangeRecordKey", SqlDbType.NChar);
            prams[1].Value = _ChangeRecordKey;
            prams[2] = new SqlParameter("@ChangeType", SqlDbType.NChar);
            prams[2].Value = _ChangeType;
            prams[3] = new SqlParameter("Pending", SqlDbType.Bit);
            prams[3].Value = _Pending;
            prams[4] = new SqlParameter("@ChangeDesc", SqlDbType.NText);
            prams[4].Value = _ChangeDesc;
            prams[5] = new SqlParameter("@UpdateCmd", SqlDbType.NText);
            prams[5].Value = _UpdateCmd;
            prams[6] = new SqlParameter("@TimeRequested", SqlDbType.DateTime);
            prams[6].Value = _TimeRequested;
            prams[7] = new SqlParameter("@TimeCommitted", SqlDbType.DateTime);
            prams[7].Value = _TimeCommitted;
            prams[8] = new SqlParameter("@Approved", SqlDbType.Bit);
            prams[8].Value = _Approved;
            prams[9] = new SqlParameter("@ChangeID", SqlDbType.Int);
            prams[9].Value = _ChangeID;
            prams[10] = new SqlParameter("@ApprovedBy", SqlDbType.NChar);
            prams[10].Value = _ApprovedBy;

            SqlHelper.ExecuteNonQuery(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.WS_UPDATES_Update", prams);
            
        }

        /// <summary>
    /// Calls a Stored Procedure to Delete the WS_Update Table record that is loaded. 
    /// </summary>
         public void Delete()
        {
            SqlParameter[] prams = new SqlParameter[1];
            prams[0] = new SqlParameter("@ChangeID", SqlDbType.Int);
            prams[0].Value = _ChangeID;
            SqlHelper.ExecuteNonQuery(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.WS_UPDATES_Delete", prams);
        }

		/// <summary>
		/// Loads the record into the current object
		/// </summary>
 		private void LoadWSUpdate()
		{
			SqlDataReader reader = GetWSUpdate();
			//try
			//{
				if (reader.HasRows)
				{
					if (reader.Read())
					{
                        _ChangeID = Convert.ToInt32(reader["ChangeID"]);
						_username = reader["username"].ToString();
						_ChangeRecordKey = reader["ChangeRecordKey"].ToString();
						_ChangeType = reader["ChangeType"].ToString();
						_Pending = Convert.ToBoolean(reader["Pending"]);
						_ChangeDesc = reader["ChangeDesc"].ToString();
						_UpdateCmd = reader["UpdateCmd"].ToString();
                        _TimeRequested = (reader["TimeRequested"] == DBNull.Value ? DateTime.MinValue : (DateTime)reader["TimeRequested"]);
                        _TimeCommitted = (reader["TimeCommitted"] == DBNull.Value || (DateTime)reader["TimeCommitted"] == DateTime.Parse("1/1/1900 12:00:00 AM") ? DateTime.Parse("1/1/1900 12:00:00 AM") : (DateTime)reader["TimeCommitted"]);
						_Approved = Convert.ToBoolean(reader["Approved"]);
						_ChangeID = (int) reader["ChangeID"];
                        _ApprovedBy = reader["ApprovedBy"].ToString() ; 
					}
				}
		//	}
		//	catch (Exception ex)
		//	{
		//		throw(new Exception("Unable to load WSUpdate from database", ex));
		//	}
		}

        /// <summary>
        /// Accesses the database record
        /// </summary>
        /// <returns>An SQLDataReader with the record containing the current ws_update</returns>
		private SqlDataReader GetWSUpdate()
		{
            if (_ChangeID != 0)
            {
                SqlParameter[] prams = new SqlParameter[1];
                prams[0] = new SqlParameter("@ChangeID", SqlDbType.Int);
                prams[0].Value = _ChangeID;
                return (SqlHelper.ExecuteReader(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.WS_UPDATES_Select_By_ChangeID", prams));
            }
            else if (_ChangeRecordKey != null && _ChangeType != null)
            {
                SqlParameter[] prams = new SqlParameter[2];
                prams[0] = new SqlParameter("@ChangeRecordKey", SqlDbType.NChar);
                prams[0].Value = _ChangeRecordKey;
                prams[1] = new SqlParameter("@ChangeType", SqlDbType.NChar);
                prams[1].Value = _ChangeType;
                return (SqlHelper.ExecuteReader(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.WS_UPDATES_Select_By_ChangeRecord_And_Type", prams));
            }
            else
            {
                return null;
            }
			
		}

        public string getFriendlyDesc()
        {
            if (!_ChangeDesc.Equals(string.Empty))
            {
                if (_ChangeDesc.Contains("Website employee"))
                {
                    string[] FullUpdate = { ", Full Update:" };
                    return _ChangeDesc.Split( FullUpdate, System.StringSplitOptions.RemoveEmptyEntries )[0];
                }
                else return _ChangeDesc;
            }
            else
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Returns a zero if no updates to the specified driver or company are waiting for approval
        /// </summary>
        /// <param name="CRKey">The driver ID or company ID to check</param>
        /// <param name="RecordType">"Employee" or "Company"</param>
        /// <returns></returns>
        public static int isPending(string CRKey, string RecordType)
        {
            SqlParameter[] prams = new SqlParameter[2];
            prams[0] = new SqlParameter("@ChangeRecordKey", SqlDbType.NChar);
            prams[0].Value = CRKey;
            prams[1] = new SqlParameter("@ChangeType", SqlDbType.NChar);
            prams[1].Value = RecordType;
            try
            {
                // Call the stored procedure that counts the number of pending web site updates with this record key and of this type                
                return(Convert.ToInt32(SqlHelper.ExecuteScalar(Common.Config.ConnectionString, CommandType.StoredProcedure, "WS_UPDATES_Find_Pending", prams)));
            }
            catch 
            {
                return 0;
            }
        }
	}
}