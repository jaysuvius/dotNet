using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace CTPA.Entities
{
    public class DER
    {
        #region Declarations
        private int _DERAUTOID;
        private int _DERCOMP_ID;
        private bool _PRIMARYDER;
        private string _DERFIRSTNAME;
        private string _DERLASTNAME;
        private string _DERMIDNAME;
        private string _DERTITLENAME;
        #endregion

        #region Properties
        public int DERAUTOID { get { return _DERAUTOID; } set { _DERAUTOID = value; } }
        public int DERCOMP_ID { get { return _DERCOMP_ID; } set { _DERCOMP_ID = value; } }
        public bool PRIMARYDER { get { return _PRIMARYDER; } set { _PRIMARYDER = value; } }
        public string DERFIRSTNAME { get { return _DERFIRSTNAME; } set { _DERFIRSTNAME = value; } }
        public string DERLASTNAME { get { return _DERLASTNAME; } set { _DERLASTNAME = value; } }
        public string DERMIDNAME { get { return _DERMIDNAME; } set { _DERMIDNAME = value; } }
        public string DERTITLENAME { get { return _DERTITLENAME; } set { _DERTITLENAME = value; } }
        #endregion

        // constructor

        public DER(int LoadID)
        {
            _DERAUTOID = LoadID;
            LoadDER();
        }
        public void Save()
        {
            try
            {
                SqlDataReader reader = GetDER();

                if (reader.HasRows)
                {
                    Update();

                }
                else
                {
                    Insert();

                }

            }
            catch (Exception ex)
            {
                //Changeme

                throw (new Exception("Insert Error!", ex));

                //Insert();
            }
        }

        private void Insert()
        {
            //SqlParameter[] prams = new SqlParameter[1];
            //prams[0] = new SqlParameter("@DERAUTOID", SqlDbType.NVarChar);
            //prams[0].Value = _DERAUTOID;
            SqlHelper.ExecuteNonQuery(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.DER_TBL_Insert");
            Update();
        }

        public void Update()
        {
            SqlParameter[] prams = new SqlParameter[6];
            prams[0] = new SqlParameter("@DERAUTOID", SqlDbType.NVarChar);
            prams[0].Value = DERAUTOID;
            prams[0] = new SqlParameter("@DERCOMP_ID", SqlDbType.NVarChar);
            prams[0].Value = DERCOMP_ID;
            prams[1] = new SqlParameter("@PRYMARYDER", SqlDbType.Bit);
            prams[1].Value = PRIMARYDER;
            prams[2] = new SqlParameter("@DERFIRSTNAME", SqlDbType.NVarChar);
            prams[2].Value = DERFIRSTNAME;
            prams[3] = new SqlParameter("@DERLASTNAME", SqlDbType.NVarChar);
            prams[3].Value = DERLASTNAME;
            prams[4] = new SqlParameter("@DERMIDNAME", SqlDbType.NVarChar);
            prams[4].Value = DERMIDNAME;
            prams[5] = new SqlParameter("@DERTITLENAME", SqlDbType.NVarChar);
            prams[5].Value = DERTITLENAME;
            SqlHelper.ExecuteNonQuery(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.DER_TABLE_Update", prams);

        }


		// LoadDER_TBL
		private void LoadDER()
		{
			SqlDataReader reader = GetDER();
			try
			{
				if (reader.HasRows)
				{
					if (reader.Read())
					{
                        if (reader["DERAUTOID"] != System.DBNull.Value)
                        {
                            _DERAUTOID = Convert.ToInt32(reader["DERAUTOID"]);
                        }
                        if (reader["DERCOMP_ID"] != System.DBNull.Value)
                        {
                            _DERCOMP_ID = Convert.ToInt32(reader["DERAUTOID"]);
                        }
                        if (reader["PRIMARYDER"] != System.DBNull.Value)
                        {
                            _PRIMARYDER = Convert.ToBoolean(reader["PRIMARYDER"]);
                        }
                        if (reader["DERFIRSTNAME"] != System.DBNull.Value)
                        {
                            _DERFIRSTNAME = reader["DERFIRSTNAME"].ToString().Trim();
                        }
                        if (reader["DERLASTNAME"] != System.DBNull.Value)
                        {
                            _DERLASTNAME = reader["DERLASTNAME"].ToString().Trim();
                        }
                        if (reader["DERMIDNAME"] != System.DBNull.Value)
                        {
                            _DERMIDNAME = reader["DERMIDNAME"].ToString().Trim();
                        }
                        if (reader["DERTITLENAME"] != System.DBNull.Value)
                        {
                            _DERTITLENAME = reader["DERTITLENAME"].ToString().Trim();
                        }

                    }
				}
			}
			catch (Exception ex)
			{
                throw (new Exception("Could not load DER from database.  Contact your administrator", ex));
			}
		}


        private SqlDataReader GetDER()
        {
            SqlParameter[] prams = new SqlParameter[1];
            prams[0] = new SqlParameter("@DERAUTOID", SqlDbType.Int);
            prams[0].Value = _DERAUTOID;
            return (SqlHelper.ExecuteReader(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.DER_TBL_Select", prams));

        }
    }
}