using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using Microsoft.ApplicationBlocks.Data;


namespace CTPA.Entities
{
	public class Log {
#region Declarations
		private int _AUTOID;
		private int _COMP_ID;
		private string _USERNAME;
		private int _USERID;
		private int _ACTIVITYID;
		private string _ACTIVITY_DATE;
		private int _SLOTS_ADJ;
		private string _REF_INVOICE_ID;
		private string _ACTIVITY_LOG;
		private float _RECURRING_BALANCE;
		private int _SESSIONID;
		private int _LOG_TYPE;
        private bool _new;

        public enum LogTypes
        {
            Billing = 1,
            Company = 2
        }

#endregion

		// constructor
		public Log() {
            _new = true;
		}



#region Properties
		public int AUTOID {get {return _AUTOID;} set {_AUTOID = value;}}
		public int COMP_ID {get {return _COMP_ID;} set {_COMP_ID = value;}}
		public string USERNAME {get {return _USERNAME;} set {_USERNAME = value;}}
		public int USERID {get {return _USERID;} set {_USERID = value;}}
		public int ACTIVITYID {get {return _ACTIVITYID;} set {_ACTIVITYID = value;}}
		public string ACTIVITY_DATE {get {return _ACTIVITY_DATE;} set {_ACTIVITY_DATE = value;}}
		public int SLOTS_ADJ {get {return _SLOTS_ADJ;} set {_SLOTS_ADJ = value;}}
		public string REF_INVOICE_ID {get {return _REF_INVOICE_ID;} set {_REF_INVOICE_ID = value;}}
		public string ACTIVITY_LOG {get {return _ACTIVITY_LOG;} set {_ACTIVITY_LOG = value;}}
		public float RECURRING_BALANCE {get {return _RECURRING_BALANCE;} set {_RECURRING_BALANCE = value;}}
		public int SESSIONID {get {return _SESSIONID;} set {_SESSIONID = value;}}
		public int LOG_TYPE {get {return _LOG_TYPE;} set {_LOG_TYPE = value;}}
#endregion

        /// <summary>
        /// This is where the insert takes place
        /// </summary>
        /// <returns>The AutoID of the new record</returns>
	    public int Insert()
        {
            if (_new)
            {
                _new = false;
                SqlParameter[] prams = new SqlParameter[6];
                prams[0] = new SqlParameter("@COMP_ID", SqlDbType.Int);
                prams[0].Value = _COMP_ID;
                prams[1] = new SqlParameter("@USERNAME", SqlDbType.NVarChar);
                prams[1].Value = _USERNAME;
                prams[2] = new SqlParameter("@USERID", SqlDbType.Int);
                prams[2].Value = _USERID;
                prams[3] = new SqlParameter("@SLOTS_ADJ", SqlDbType.Int);
                prams[3].Value = _SLOTS_ADJ;
                prams[4] = new SqlParameter("@ACTIVITY_LOG", SqlDbType.NVarChar);
                prams[4].Value = _ACTIVITY_LOG;
                prams[5] = new SqlParameter("@LOG_TYPE", SqlDbType.Int);
                prams[5].Value = _LOG_TYPE;
                return (Convert.ToInt32(SqlHelper.ExecuteDataset(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.BILLING_TBL_Insert", prams).Tables[0].Rows[0]["AUTOID"]));                   
            }
            else
            {
                return 0;
            }
        }

        

		// LoadBILLING_TBL
		private void LoadBILLING_TBL()
		{
			SqlDataReader reader = GetBILLING_TBL();
			try
			{
				if (reader.HasRows)
				{
					if (reader.Read())
					{
						_AUTOID = (int) reader["AUTOID"];
						_COMP_ID = (int) reader["COMP_ID"];
						_USERNAME = reader["USERNAME"].ToString();
						_USERID = (int) reader["USERID"];
						_ACTIVITYID = (int) reader["ACTIVITYID"];
						_ACTIVITY_DATE = reader["ACTIVITY_DATE"].ToString();
						_SLOTS_ADJ = (int) reader["SLOTS_ADJ"];
						_REF_INVOICE_ID = reader["REF_INVOICE_ID"].ToString();
						_ACTIVITY_LOG = reader["ACTIVITY_LOG"].ToString();
						_RECURRING_BALANCE = Convert.ToSingle(reader["RECURRING_BALANCE"]);
						_SESSIONID = (int) reader["SESSIONID"];
						_LOG_TYPE = (int) reader["LOG_TYPE"];
					}
				}
			}
			catch (Exception ex)
			{
				throw(new Exception("Unable to load BILLING_TBL from database", ex));
			}
		}

		private SqlDataReader GetBILLING_TBL()
		{
			SqlParameter[] prams = new SqlParameter[1];
			prams[0] = new SqlParameter("@AUTOID", SqlDbType.Int);
			prams[0].Value = _AUTOID;
			return (SqlHelper.ExecuteReader(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.BILLING_TBL_Select", prams));
			
		}
	}
}