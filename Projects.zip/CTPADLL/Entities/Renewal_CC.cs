using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace CTPA.Entities
{

	public class Renewal_CC
    {
#region Declarations
        private Int32 _COMP_ID;
        private string _CC_Number;
        private string _CC_Exp;
        private string _CC_CCV;
        private string _CC_NAME;
        private string _CC_ADDRESS;
        private string _CC_CITY;
        private string _CC_STATE;
        private string _CC_ZIP;
#endregion


#region Properties
        public Int32 COMP_ID { get { return _COMP_ID; } set { _COMP_ID = value; try { LoadRenewal_CC(); } catch (Exception ex) { } } }
        public string CC_Number { get { return _CC_Number; } set { _CC_Number = value; } }
        public string CC_Exp { get { return _CC_Exp; } set { _CC_Exp = value; } }
        public string CC_CCV { get { return _CC_CCV; } set { _CC_CCV = value; } }
        public string CC_NAME { get { return _CC_NAME; } set { _CC_NAME = value; } }
        public string CC_ADDRESS { get { return _CC_ADDRESS; } set { _CC_ADDRESS = value; } }
        public string CC_CITY { get { return _CC_CITY; } set { _CC_CITY = value; } }
        public string CC_STATE { get { return _CC_STATE; } set { _CC_STATE = value; } }
        public string CC_ZIP { get { return _CC_ZIP; } set { _CC_ZIP = value; } }
#endregion


        // constructor
        public Renewal_CC()
        {
        }

        public Renewal_CC(Int32 LoadID)
        {
            COMP_ID = LoadID;
        }

        public void Save()
        {
            try
            {
                Update();
            }
            catch (Exception ex)
            {
                Insert();
            }
        }


        /// <summary>
        /// Calls a SP to insert the current Renewal_CC record into the Renewal_CC Table
        /// </summary>
        private void Insert()
        {
            SqlParameter[] prams = new SqlParameter[1];
            prams[0] = new SqlParameter("@COMP_ID", SqlDbType.BigInt);
            prams[0].Value = _COMP_ID;
            SqlHelper.ExecuteNonQuery(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.RENEWALS_CC_Insert", prams);
            Update();
        }



		//Update
		private void Update()
        {
            SqlParameter[] prams = new SqlParameter[9];
            prams[0] = new SqlParameter("@COMP_ID", SqlDbType.BigInt);
            prams[0].Value = COMP_ID;
            prams[1] = new SqlParameter("@CC_Number", SqlDbType.NChar);
            prams[1].Value = _CC_Number;
            prams[2] = new SqlParameter("@CC_Exp", SqlDbType.NChar);
            prams[2].Value =_CC_Exp;
            prams[3] = new SqlParameter("@CC_CCV", SqlDbType.NChar);
            prams[3].Value = _CC_CCV;
            prams[4] = new SqlParameter("@CC_NAME", SqlDbType.NChar);
            prams[4].Value = _CC_NAME;
            prams[5] = new SqlParameter("@CC_ADDRESS ", SqlDbType.NChar);
            prams[5].Value = _CC_ADDRESS;
            prams[6] = new SqlParameter("@CC_CITY", SqlDbType.NChar);
            prams[6].Value = _CC_CITY;
            prams[7] = new SqlParameter("@CC_STATE", SqlDbType.NChar);
            prams[7].Value = _CC_STATE;
            prams[8] = new SqlParameter("@CC_ZIP", SqlDbType.NChar);
            prams[8].Value = _CC_ZIP;            
            SqlHelper.ExecuteNonQuery(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.RENEWALS_CC_Update", prams);
		}

        // LoadRenewal
		private void LoadRenewal_CC()
		{
			SqlDataReader reader = GetRenewal_CC();
			try
			{
				if (reader.HasRows)
				{
					if (reader.Read())
					{
                        if (reader["CC_Number"] != System.DBNull.Value)
                        {
                            _CC_Number = reader["CC_Number"].ToString();
                        }
                        if (reader["CC_Exp"] != System.DBNull.Value)
                        {
                            _CC_Exp = reader["CC_Exp"].ToString();
                        }
                        if (reader["CC_CCV"] != System.DBNull.Value)
                        {
                            _CC_CCV = reader["CC_CCV"].ToString();
                        }
                        if (reader["CC_NAME"] != System.DBNull.Value)
                        {
                            _CC_NAME = reader["CC_NAME"].ToString();
                        }
                        if (reader["CC_ADDRESS"] != System.DBNull.Value)
                        {
                            _CC_ADDRESS = reader["CC_ADDRESS"].ToString();
                        }
                        if (reader["CC_CITY"] != System.DBNull.Value)
                        {
                            _CC_CITY = reader["CC_CITY"].ToString();
                        }
                        if (reader["CC_STATE"] != System.DBNull.Value)
                        {
                            _CC_STATE = reader["CC_STATE"].ToString();
                        }
                        if (reader["CC_ZIP"] != System.DBNull.Value)
                        {
                            _CC_ZIP = reader["CC_ZIP"].ToString();
                        }		
					}
				}
			}
			catch (Exception ex)
			{
				throw(new Exception("Unable to load Renewal CC Info from database", ex));
			}
		}

        private SqlDataReader GetRenewal_CC()
		{
			SqlParameter[] prams = new SqlParameter[1];
			prams[0] = new SqlParameter("@COMP_ID", SqlDbType.BigInt);
			prams[0].Value = _COMP_ID;
			return (SqlHelper.ExecuteReader(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.RENEWALS_CC_Select", prams));
			
		}
	}
}
