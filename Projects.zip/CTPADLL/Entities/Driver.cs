using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace CTPA.Entities
{
    /// <summary>
    /// Class to encapsulate the Driver record infomation. 
    /// </summary>
	public class Driver {
#region Declarations
		private StringBuilder sbUpdateDesc = new StringBuilder();
		private StringBuilder sbUpdateCommandText = new StringBuilder();
        private bool newDriver = false;
		private int _AUTOID = 0;
        private int _AUTOID_orig = 0;
        private double _COMP_ID = 0;
		private double _COMP_ID_orig = 0;
		private int _RNDGRPID = 0;
		private int _RNDGRPID_orig = 0;
		private string _NAME = string.Empty;
		private string _NAME_orig = string.Empty;
		private string _FIRSTNAME = string.Empty;
		private string _FIRSTNAME_orig = string.Empty;
		private string _MIDDLENAME = string.Empty;
		private string _MIDDLENAME_orig = string.Empty;
		private string _LASTNAME = string.Empty;
		private string _LASTNAME_orig = string.Empty;
		private string _TITLENAME = string.Empty;
		private string _TITLENAME_orig = string.Empty;
		private string _ADDRESS1 = string.Empty;
		private string _ADDRESS1_orig = string.Empty;
		private string _ADDRESS2 = string.Empty;
		private string _ADDRESS2_orig = string.Empty;
		private string _CITY = string.Empty;
		private string _CITY_orig = string.Empty;
		private string _STATE = string.Empty;
		private string _STATE_orig = string.Empty;
		private string _ZIP = string.Empty;
		private string _ZIP_orig = string.Empty;
		private string _HOMEPHONE = string.Empty;
		private string _HOMEPHONE_orig = string.Empty;
		private string _WORKPHONE = string.Empty;
		private string _WORKPHONE_orig = string.Empty;
		private string _EMERPHONE = string.Empty;
		private string _EMERPHONE_orig = string.Empty;
		private string _CDL_NUM = string.Empty;
		private string _CDL_NUM_orig = string.Empty;
		private string _SS_NUM = string.Empty;
		private string _SS_NUM_orig = string.Empty;
		private string _BIRTH_DATE = string.Empty;
		private string _BIRTH_DATE_orig = string.Empty;
		private string _STATUSFLAG = string.Empty;
		private string _STATUSFLAG_orig = string.Empty;
		private string _CARD = string.Empty;
		private string _CARD_orig = string.Empty;
		private string _HIREDT = string.Empty;
		private string _HIREDT_orig = string.Empty;
		private string _ACTIVE = string.Empty;
		private string _ACTIVE_orig = string.Empty;
		private string _INACTIVE = string.Empty;
		private string _INACTIVE_orig = string.Empty;
		private string _CELLPHONE = string.Empty;
		private string _CELLPHONE_orig = string.Empty;
		private string _PAGERPHONE = string.Empty;
		private string _PAGERPHONE_orig = string.Empty;
		private int _OOSID = 0;
		private int _OOSID_orig = 0;
		private string _OOSDATE = string.Empty;
		private string _OOSDATE_orig = string.Empty;
		private string _OOSEXPDATE = string.Empty;
		private string _OOSEXPDATE_orig = string.Empty;
		private int _OOSEXPACTION = 0;
		private int _OOSEXPACTION_orig = 0;
        private bool _TAG_IDCARD = false;
        private bool _TAG_IDCARD_orig = false;
		private int _RNDWARNINGS = 0;
		private int _RNDWARNINGS_orig = 0;
		private int _RNDWARNINGREC = 0;
		private int _RNDWARNINGREC_orig = 0;
		private int _OOSRNDAUTOID = 0;
		private int _OOSRNDAUTOID_orig = 0;
		private float _RNDWAVIER = 0;
		private float _RNDWAVIER_orig = 0;
		private float _RNDWAVIERBATCH = 0;
		private float _RNDWAVIERBATCH_orig = 0;
		private int _RENEWALYEAR = 0;
		private int _RENEWALYEAR_orig = 0;
        private bool _statEA = false;
        private bool _statEA_orig = false;
		private int _POOLID = 0;
		private int _POOLID_orig = 0;
		private string _IDTAGstr = string.Empty;
		private string _IDTAGstr_orig = string.Empty;
		private string _sessiontag = string.Empty;
		private string _sessiontag_orig = string.Empty;
		private string _comments = string.Empty;
		private string _comments_orig = string.Empty;
		private string _newreserve = string.Empty;
		private string _newreserve_orig = string.Empty;
        private bool _LOGMUSTREAD = false;
        private bool _LOGMUSTREAD_orig = false;
		private double _RNDSeed = 0;
		private double _RNDSeed_orig = 0;
		private double _RNDSeed2 = 0;
		private double _RNDSeed2_orig = 0;
        private string _PreEmpTstComplete = string.Empty;
        private string _PreEmpTstComplete_orig = string.Empty;
        private string _SpanMan = string.Empty;
        private string _SpanMan_orig = string.Empty;
        private string _ReHire = string.Empty;
        private string _ReHire_orig = string.Empty;
        private string _PreEmpTstDate = string.Empty;
        private string _PreEmpTstDate_orig = string.Empty;
        private string _SpecimenID = string.Empty;
        private string _SpecimenID_orig = string.Empty;
#endregion

#region Properties
		public string updateDesc
        { 
            get
            {
                Update();
                if (newDriver)
                {
                    // This is a request to add a new driver, report accordingly
                    System.Collections.Specialized.NameValueCollection pools = Common.Config.poolIDs;
                    return "Website employee add by " + CTPA.Common.Config.getWSUser.UserName + "  - New record: " + _FIRSTNAME + " " + _LASTNAME + ", Full Update: " +  sbUpdateDesc.ToString();
                }
                else if ((_INACTIVE != _INACTIVE_orig) && (_INACTIVE == null))
                {
                    // Driver has been de-activated
                    System.Collections.Specialized.NameValueCollection pools = Common.Config.poolIDs;
                    return "Website employee active status change by " + CTPA.Common.Config.getWSUser.UserName + "  - Record: " + _FIRSTNAME + " " + _LASTNAME + ", Full Update: " + sbUpdateDesc.ToString();
                }
                else if (_INACTIVE_orig != _INACTIVE && _INACTIVE != null)
                {
                    // Driver has been re-activated
                    System.Collections.Specialized.NameValueCollection pools = Common.Config.poolIDs;
                    return "Website employee active status change by " + CTPA.Common.Config.getWSUser.UserName + "  - Record: " + _FIRSTNAME + " " + _LASTNAME + ", Full Update: " + sbUpdateDesc.ToString();
                }
                else if (sbUpdateDesc.ToString().Contains("OOSID"))
                {
                    // This is a request to remove the driver from service, report accordingly
                    System.Collections.Specialized.NameValueCollection OOSIDS = Common.Config.OOSStatusIDs;
                    return "Website employee OOS request by " + CTPA.Common.Config.getWSUser.UserName + "  - Record: " + _FIRSTNAME + " " + _LASTNAME + ", Full Update: " + sbUpdateDesc.ToString();
                }
                else
                {
                    return sbUpdateDesc.ToString();
                }
            }
        }
        public string updateCommand { get { Update(); return sbUpdateCommandText.ToString(); } }
		public int AUTOID {get {return _AUTOID;} set {_AUTOID = value;}}
		public double COMP_ID {get {return _COMP_ID;} set {_COMP_ID = value;}}
		public int RNDGRPID {get {return _RNDGRPID;} set {_RNDGRPID = value;}}
		public string NAME {get {return _NAME;} set {_NAME = value;}}
        public string FIRSTNAME { get { return _FIRSTNAME; } set { _FIRSTNAME = value; if ( _FIRSTNAME != _FIRSTNAME_orig ) { _NAME = (_FIRSTNAME != "" ? _FIRSTNAME : "") + (_MIDDLENAME != "" ? " " + _MIDDLENAME : "") + (_LASTNAME != "" ? " " + _LASTNAME : "") + (_TITLENAME != "" ? ", " + _TITLENAME : ""); } } }
        public string MIDDLENAME { get { return _MIDDLENAME; } set { _MIDDLENAME = value; if ( _MIDDLENAME != _MIDDLENAME_orig ) { _NAME = (_FIRSTNAME != "" ? _FIRSTNAME : "") + (_MIDDLENAME != "" ? " " + _MIDDLENAME : "") + (_LASTNAME != "" ? " " + _LASTNAME : "") + (_TITLENAME != "" ? ", " + _TITLENAME : ""); } } }
        public string LASTNAME { get { return _LASTNAME; } set { _LASTNAME = value; if ( _LASTNAME != _LASTNAME_orig ) { _NAME = (_FIRSTNAME != "" ? _FIRSTNAME : "") + (_MIDDLENAME != "" ? " " + _MIDDLENAME : "") + (_LASTNAME != "" ? " " + _LASTNAME : "") + (_TITLENAME != "" ? ", " + _TITLENAME : ""); } } }
        public string TITLENAME { get { return _TITLENAME; } set { _TITLENAME = value; if (_TITLENAME != _TITLENAME_orig ) { _NAME = (_FIRSTNAME != "" ? _FIRSTNAME : "") + (_MIDDLENAME != "" ? " " + _MIDDLENAME : "") + (_LASTNAME != "" ? " " + _LASTNAME : "") + (_TITLENAME != "" ? ", " + _TITLENAME : ""); } } }
		public string ADDRESS1 {get {return _ADDRESS1;} set {_ADDRESS1 = value;}}
		public string ADDRESS2 {get {return _ADDRESS2;} set {_ADDRESS2 = value;}}
		public string CITY {get {return _CITY;} set {_CITY = value;}}
		public string STATE {get {return _STATE;} set {_STATE = value;}}
		public string ZIP {get {return _ZIP;} set {_ZIP = value;}}
		public string HOMEPHONE {get {return _HOMEPHONE;} set {_HOMEPHONE = value;}}
		public string WORKPHONE {get {return _WORKPHONE;} set {_WORKPHONE = value;}}
		public string EMERPHONE {get {return _EMERPHONE;} set {_EMERPHONE = value;}}
		public string CDL_NUM {get {return _CDL_NUM;} set {_CDL_NUM = value;}}
		public string SS_NUM {get {return "XXX-XX-" + _SS_NUM.Substring(_SS_NUM.Length-4);} set {_SS_NUM = value;}}
		public string BIRTH_DATE {get {return _BIRTH_DATE;} set {_BIRTH_DATE = value;}}
		public string STATUSFLAG {get {return _STATUSFLAG;} set {_STATUSFLAG = value;}}
		public string CARD {get {return _CARD;} set {_CARD = value;}}
		public string HIREDT {get {return _HIREDT;} set {_HIREDT = value;}}
		public string ACTIVE {get {return _ACTIVE;} set {_ACTIVE = value;}}
		public string INACTIVE {get {return _INACTIVE;} set {_INACTIVE = value;}}
		public string CELLPHONE {get {return _CELLPHONE;} set {_CELLPHONE = value;}}
		public string PAGERPHONE {get {return _PAGERPHONE;} set {_PAGERPHONE = value;}}
		public int OOSID {get {return _OOSID;} set {_OOSID = value;}}
		public string OOSDATE {get {return _OOSDATE;} set {_OOSDATE = value;}}
		public string OOSEXPDATE {get {return _OOSEXPDATE;} set {_OOSEXPDATE = value;}}
		public int OOSEXPACTION {get {return _OOSEXPACTION;} set {_OOSEXPACTION = value;}}
		public bool TAG_IDCARD {get {return _TAG_IDCARD;} set {_TAG_IDCARD = value;}}
		public int RNDWARNINGS {get {return _RNDWARNINGS;} set {_RNDWARNINGS = value;}}
		public int RNDWARNINGREC {get {return _RNDWARNINGREC;} set {_RNDWARNINGREC = value;}}
		public int OOSRNDAUTOID {get {return _OOSRNDAUTOID;} set {_OOSRNDAUTOID = value;}}
		public float RNDWAVIER {get {return _RNDWAVIER;} set {_RNDWAVIER = value;}}
		public float RNDWAVIERBATCH {get {return _RNDWAVIERBATCH;} set {_RNDWAVIERBATCH = value;}}
		public int RENEWALYEAR {get {return _RENEWALYEAR;} set {_RENEWALYEAR = value;}}
		public bool statEA {get {return _statEA;} set {_statEA = value;}}
		public int POOLID {get {return _POOLID;} set {_POOLID = value;}}
		public string IDTAGstr {get {return _IDTAGstr;} set {_IDTAGstr = value;}}
		public string sessiontag {get {return _sessiontag;} set {_sessiontag = value;}}
		public string comments {get {return _comments;} set {_comments = value;}}
		public string newreserve {get {return _newreserve;} set {_newreserve = value;}}
		public bool LOGMUSTREAD {get {return _LOGMUSTREAD;} set {_LOGMUSTREAD = value;}}
		public double RNDSeed {get {return _RNDSeed;} set {_RNDSeed = value;}}
		public double RNDSeed2 {get {return _RNDSeed2;} set {_RNDSeed2 = value;}}
		public string PreEmpTstComplete {get {return _PreEmpTstComplete;} set {_PreEmpTstComplete = value;}}
        public bool isChanged { get { Update(); return updateDesc != ""; } }
        public int hasPendingChange{get{return checkPendingChange(_AUTOID);}}
        public string SpanMan { get { return _SpanMan; } set { _SpanMan = value; } }
        public string ReHire { get { return _ReHire; } set { _ReHire = value; } }
        public string PreEmpTstDate { get { return _PreEmpTstDate; } set { _PreEmpTstDate = value; } }
        public string SpecimenID { get { return _SpecimenID; } set { _SpecimenID = value; } }
        public Entities.Company company { get { if (_COMP_ID != 0) { return new Company((int)_COMP_ID); } else { return null; } } }
#endregion

#region Member Functions
        /// <summary>
        /// Creates a blank driver record
        /// </summary>
        /// <param name="DriverCompanyID">The Company ID to attach the user to</param>
        /// <param name="newDriver">Must be set to true to create new driver record</param>
        public Driver(int DriverCompanyID, bool createRecord)
        {
            newDriver = createRecord;
            if (createRecord)
            {
                SqlParameter[] prams = new SqlParameter[1];
                prams[0] = new SqlParameter("@COMPID", SqlDbType.Int);
                prams[0].Value = Convert.ToInt32(DriverCompanyID);
                _AUTOID = _AUTOID_orig = Convert.ToInt32(SqlHelper.ExecuteScalar(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.DRIVERUP_primary_NewDriver"));
                LoadDriver();
            }
            else
            {
                throw new Exception("Employee initialized as new with no record");
            }
        }
        /// <summary>
        /// Create Driver Entitiy from Driver ID
        /// </summary>
        /// <param name="LoadID"></param>
        public Driver(int LoadID)
        {
            newDriver = false;
            _AUTOID = _AUTOID_orig = LoadID;
            LoadDriver();
        }

		/// <summary>
		/// Build the updateDesc and updateCmd strings based on the current object
		/// </summary>
		private void Update()
		{
            //Truncate the fields to their max lengths
            if (_SS_NUM.Length > 11)
            {
                _SS_NUM = _SS_NUM.Remove(11);
            }
            if (_STATE.Length > 2)
            {            
                _STATE = _STATE.Remove(2) ;
            }
            if (_ZIP.Length > 10)           
            {
                _ZIP = _ZIP.Remove(10);
            }
            sbUpdateDesc.Remove(0, sbUpdateDesc.Length);
            sbUpdateCommandText.Remove(0, sbUpdateCommandText.Length);
			if(_AUTOID != _AUTOID_orig)
			{
				sbUpdateDesc.Append("AUTOID changed from " + _AUTOID_orig + " to " + _AUTOID + ";");
				sbUpdateCommandText.Append("AUTOID = " + convertToSQL( _AUTOID ) + ", ");
			}
			if(_COMP_ID != _COMP_ID_orig)
			{
				sbUpdateDesc.Append("COMP_ID changed from " + _COMP_ID_orig + " to " + _COMP_ID + ";");
				sbUpdateCommandText.Append("COMP_ID = " + convertToSQL( _COMP_ID ) + ", ");
			}
			if(_RNDGRPID != _RNDGRPID_orig)
			{
				sbUpdateDesc.Append("RNDGRPID changed from " + _RNDGRPID_orig + " to " + _RNDGRPID + ";");
				sbUpdateCommandText.Append("RNDGRPID = " + convertToSQL( _RNDGRPID ) + ", ");
			}
			if(_NAME != _NAME_orig)
			{
                sbUpdateDesc.Append("NAME changed from " + _NAME_orig + " to " + _NAME + ";");
				sbUpdateCommandText.Append("NAME = " + convertToSQL( _NAME ) + ", ");
			}
			if(_FIRSTNAME != _FIRSTNAME_orig)
			{
				sbUpdateDesc.Append("FIRSTNAME changed from " + _FIRSTNAME_orig + " to " + _FIRSTNAME + ";");
				sbUpdateCommandText.Append("FIRSTNAME = " + convertToSQL( _FIRSTNAME ) + ", ");
			}
			if(_MIDDLENAME != _MIDDLENAME_orig)
			{
				sbUpdateDesc.Append("MIDDLENAME changed from " + _MIDDLENAME_orig + " to " + _MIDDLENAME + ";");
				sbUpdateCommandText.Append("MIDDLENAME = " + convertToSQL( _MIDDLENAME ) + ", ");
			}
			if(_LASTNAME != _LASTNAME_orig)
			{
				sbUpdateDesc.Append("LASTNAME changed from " + _LASTNAME_orig + " to " + _LASTNAME + ";");
				sbUpdateCommandText.Append("LASTNAME = " + convertToSQL( _LASTNAME ) + ", ");
			}
			if(_TITLENAME != _TITLENAME_orig)
			{
				sbUpdateDesc.Append("TITLENAME changed from " + _TITLENAME_orig + " to " + _TITLENAME + ";");
				sbUpdateCommandText.Append("TITLENAME = " + convertToSQL( _TITLENAME ) + ", ");
			}
			if(_ADDRESS1 != _ADDRESS1_orig)
			{
				sbUpdateDesc.Append("ADDRESS1 changed from " + _ADDRESS1_orig + " to " + _ADDRESS1 + ";");
				sbUpdateCommandText.Append("ADDRESS1 = " + convertToSQL( _ADDRESS1 ) + ", ");
			}
			if(_ADDRESS2 != _ADDRESS2_orig)
			{
				sbUpdateDesc.Append("ADDRESS2 changed from " + _ADDRESS2_orig + " to " + _ADDRESS2 + ";");
				sbUpdateCommandText.Append("ADDRESS2 = " + convertToSQL( _ADDRESS2 ) + ", ");
			}
			if(_CITY != _CITY_orig)
			{
				sbUpdateDesc.Append("CITY changed from " + _CITY_orig + " to " + _CITY + ";");
				sbUpdateCommandText.Append("CITY = " + convertToSQL( _CITY ) + ", ");
			}
			if(_STATE != _STATE_orig)
			{
				sbUpdateDesc.Append("STATE changed from " + _STATE_orig + " to " + _STATE + ";");
				sbUpdateCommandText.Append("STATE = " + convertToSQL( _STATE ) + ", ");
			}
			if(_ZIP != _ZIP_orig)
			{
				sbUpdateDesc.Append("ZIP changed from " + _ZIP_orig + " to " + _ZIP + ";");
				sbUpdateCommandText.Append("ZIP = " + convertToSQL( _ZIP ) + ", ");
			}
			if(_HOMEPHONE != _HOMEPHONE_orig)
			{
				sbUpdateDesc.Append("HOMEPHONE changed from " + _HOMEPHONE_orig + " to " + _HOMEPHONE + ";");
				sbUpdateCommandText.Append("HOMEPHONE = " + convertToSQL( _HOMEPHONE ) + ", ");
			}
			if(_WORKPHONE != _WORKPHONE_orig)
			{
				sbUpdateDesc.Append("WORKPHONE changed from " + _WORKPHONE_orig + " to " + _WORKPHONE + ";");
				sbUpdateCommandText.Append("WORKPHONE = " + convertToSQL( _WORKPHONE ) + ", ");
			}
			if(_EMERPHONE != _EMERPHONE_orig)
			{
				sbUpdateDesc.Append("EMERPHONE changed from " + _EMERPHONE_orig + " to " + _EMERPHONE + ";");
				sbUpdateCommandText.Append("EMERPHONE = " + convertToSQL( _EMERPHONE ) + ", ");
			}
			if(_CDL_NUM != _CDL_NUM_orig)
			{
				sbUpdateDesc.Append("CDL_NUM changed from " + _CDL_NUM_orig + " to " + _CDL_NUM + ";");
				sbUpdateCommandText.Append("CDL_NUM = " + convertToSQL( _CDL_NUM ) + ", ");
			}
			if(_SS_NUM != _SS_NUM_orig)
			{
				sbUpdateDesc.Append("SS_NUM changed from " + _SS_NUM_orig + " to " + _SS_NUM + ";");
				sbUpdateCommandText.Append("SS_NUM = " + convertToSQL( _SS_NUM ) + ", ");
			}
			if(_BIRTH_DATE != _BIRTH_DATE_orig)
			{
				sbUpdateDesc.Append("BIRTH_DATE changed from " + _BIRTH_DATE_orig + " to " + _BIRTH_DATE + ";");
				sbUpdateCommandText.Append("BIRTH_DATE = " + convertToSQL( _BIRTH_DATE ) + ", ");
			}
			if(_STATUSFLAG != _STATUSFLAG_orig)
			{
				sbUpdateDesc.Append("STATUSFLAG changed from " + _STATUSFLAG_orig + " to " + _STATUSFLAG + ";");
				sbUpdateCommandText.Append("STATUSFLAG = " + convertToSQL( _STATUSFLAG ) + ", ");
			}
			if(_CARD != _CARD_orig)
			{
				sbUpdateDesc.Append("CARD changed from " + _CARD_orig + " to " + _CARD + ";");
				sbUpdateCommandText.Append("CARD = " + convertToSQL( _CARD ) + ", ");
			}
			if(_HIREDT != _HIREDT_orig)
			{
				sbUpdateDesc.Append("HIREDT changed from " + _HIREDT_orig + " to " + _HIREDT + ";");
				sbUpdateCommandText.Append("HIREDT = " + convertToSQL( _HIREDT ) + ", ");
			}
			if(_ACTIVE != _ACTIVE_orig)
			{
				sbUpdateDesc.Append("ACTIVE changed from " + _ACTIVE_orig + " to " + _ACTIVE + ";");
				sbUpdateCommandText.Append("ACTIVE = " + convertToSQL( _ACTIVE ) + ", ");
			}
			if(_INACTIVE != _INACTIVE_orig)
			{
				sbUpdateDesc.Append("INACTIVE changed from " + _INACTIVE_orig + " to " + _INACTIVE + ";");
				sbUpdateCommandText.Append("INACTIVE = " + convertToSQL( _INACTIVE ) + ", ");
			}
			if(_CELLPHONE != _CELLPHONE_orig)
			{
				sbUpdateDesc.Append("CELLPHONE changed from " + _CELLPHONE_orig + " to " + _CELLPHONE + ";");
				sbUpdateCommandText.Append("CELLPHONE = " + convertToSQL( _CELLPHONE ) + ", ");
			}
			if(_PAGERPHONE != _PAGERPHONE_orig)
			{
				sbUpdateDesc.Append("PAGERPHONE changed from " + _PAGERPHONE_orig + " to " + _PAGERPHONE + ";");
				sbUpdateCommandText.Append("PAGERPHONE = " + convertToSQL( _PAGERPHONE ) + ", ");
			}
			if(_OOSID != _OOSID_orig)
			{
				sbUpdateDesc.Append("OOSID changed from " + _OOSID_orig + " to " + _OOSID + ";");
				sbUpdateCommandText.Append("OOSID = " + convertToSQL( _OOSID ) + ", ");
			}
			if(_OOSDATE != _OOSDATE_orig)
			{
				sbUpdateDesc.Append("OOSDATE changed from " + _OOSDATE_orig + " to " + _OOSDATE + ";");
				sbUpdateCommandText.Append("OOSDATE = " + convertToSQL( _OOSDATE ) + ", ");
			}
			if(_OOSEXPDATE != _OOSEXPDATE_orig)
			{
				sbUpdateDesc.Append("OOSEXPDATE changed from " + _OOSEXPDATE_orig + " to " + _OOSEXPDATE + ";");
				sbUpdateCommandText.Append("OOSEXPDATE = " + convertToSQL( _OOSEXPDATE ) + ", ");
			}
			if(_OOSEXPACTION != _OOSEXPACTION_orig)
			{
				sbUpdateDesc.Append("OOSEXPACTION changed from " + _OOSEXPACTION_orig + " to " + _OOSEXPACTION + ";");
				sbUpdateCommandText.Append("OOSEXPACTION = " + convertToSQL( _OOSEXPACTION ) + ", ");
			}
			if(_TAG_IDCARD != _TAG_IDCARD_orig)
			{
				sbUpdateDesc.Append("TAG_IDCARD changed from " + _TAG_IDCARD_orig + " to " + _TAG_IDCARD + ";");
				sbUpdateCommandText.Append("TAG_IDCARD = " + convertToSQL( _TAG_IDCARD ) + ", ");
			}
			if(_RNDWARNINGS != _RNDWARNINGS_orig)
			{
				sbUpdateDesc.Append("RNDWARNINGS changed from " + _RNDWARNINGS_orig + " to " + _RNDWARNINGS + ";");
				sbUpdateCommandText.Append("RNDWARNINGS = " + convertToSQL( _RNDWARNINGS ) + ", ");
			}
			if(_RNDWARNINGREC != _RNDWARNINGREC_orig)
			{
				sbUpdateDesc.Append("RNDWARNINGREC changed from " + _RNDWARNINGREC_orig + " to " + _RNDWARNINGREC + ";");
				sbUpdateCommandText.Append("RNDWARNINGREC = " + convertToSQL( _RNDWARNINGREC ) + ", ");
			}
			if(_OOSRNDAUTOID != _OOSRNDAUTOID_orig)
			{
				sbUpdateDesc.Append("OOSRNDAUTOID changed from " + _OOSRNDAUTOID_orig + " to " + _OOSRNDAUTOID + ";");
				sbUpdateCommandText.Append("OOSRNDAUTOID = " + convertToSQL( _OOSRNDAUTOID ) + ", ");
			}
			if(_RNDWAVIER != _RNDWAVIER_orig)
			{
				sbUpdateDesc.Append("RNDWAVIER changed from " + _RNDWAVIER_orig + " to " + _RNDWAVIER + ";");
				sbUpdateCommandText.Append("RNDWAVIER = " + convertToSQL( _RNDWAVIER ) + ", ");
			}
			if(_RNDWAVIERBATCH != _RNDWAVIERBATCH_orig)
			{
				sbUpdateDesc.Append("RNDWAVIERBATCH changed from " + _RNDWAVIERBATCH_orig + " to " + _RNDWAVIERBATCH + ";");
				sbUpdateCommandText.Append("RNDWAVIERBATCH = " + convertToSQL( _RNDWAVIERBATCH ) + ", ");
			}
			if(_RENEWALYEAR != _RENEWALYEAR_orig)
			{
				sbUpdateDesc.Append("RENEWALYEAR changed from " + _RENEWALYEAR_orig + " to " + _RENEWALYEAR + ";");
				sbUpdateCommandText.Append("RENEWALYEAR = " + convertToSQL( _RENEWALYEAR ) + ", ");
			}
			if(_statEA != _statEA_orig)
			{
				sbUpdateDesc.Append("statEA changed from " + _statEA_orig + " to " + _statEA + ";");
				sbUpdateCommandText.Append("statEA = " + convertToSQL( _statEA ) + ", ");
			}
			if(_POOLID != _POOLID_orig)
			{
				sbUpdateDesc.Append("POOLID changed from " + _POOLID_orig + " to " + _POOLID + ";");
				sbUpdateCommandText.Append("POOLID = " + convertToSQL( _POOLID ) + ", ");
			}
			if(_IDTAGstr != _IDTAGstr_orig)
			{
				sbUpdateDesc.Append("IDTAGstr changed from " + _IDTAGstr_orig + " to " + _IDTAGstr + ";");
				sbUpdateCommandText.Append("IDTAGstr = " + convertToSQL( _IDTAGstr ) + ", ");
			}
			if(_sessiontag != _sessiontag_orig)
			{
				sbUpdateDesc.Append("sessiontag changed from " + _sessiontag_orig + " to " + _sessiontag + ";");
				sbUpdateCommandText.Append("sessiontag = " + convertToSQL( _sessiontag ) + ", ");
			}
			if(_comments != _comments_orig)
			{
				sbUpdateDesc.Append("comments changed from " + _comments_orig + " to " + _comments + ";");
				sbUpdateCommandText.Append("comments = " + convertToSQL( _comments ) + ", ");
			}
			if(_newreserve != _newreserve_orig)
			{
				sbUpdateDesc.Append("newreserve changed from " + _newreserve_orig + " to " + _newreserve + ";");
				sbUpdateCommandText.Append("newreserve = " + convertToSQL( _newreserve ) + ", ");
			}
			if(_LOGMUSTREAD != _LOGMUSTREAD_orig)
			{
				sbUpdateDesc.Append("LOGMUSTREAD changed from " + _LOGMUSTREAD_orig + " to " + _LOGMUSTREAD + ";");
				sbUpdateCommandText.Append("LOGMUSTREAD = " + convertToSQL( _LOGMUSTREAD ) + ", ");
			}
			if(_RNDSeed != _RNDSeed_orig)
			{
				sbUpdateDesc.Append("RNDSeed changed from " + _RNDSeed_orig + " to " + _RNDSeed + ";");
				sbUpdateCommandText.Append("RNDSeed = " + convertToSQL( _RNDSeed ) + ", ");
			}
			if(_RNDSeed2 != _RNDSeed2_orig)
			{
				sbUpdateDesc.Append("RNDSeed2 changed from " + _RNDSeed2_orig + " to " + _RNDSeed2 + ";");
				sbUpdateCommandText.Append("RNDSeed2 = " + convertToSQL( _RNDSeed2 ) + ", ");
			}
			if(_PreEmpTstComplete != _PreEmpTstComplete_orig)
			{
				sbUpdateDesc.Append("PreEmpTstComplete changed from " + _PreEmpTstComplete_orig + " to " + _PreEmpTstComplete + ";");
				sbUpdateCommandText.Append("PreEmpTstComplete = " + convertToSQL( _PreEmpTstComplete ) + ", ");
			}
            if (_SpanMan != _SpanMan_orig)
            {
                sbUpdateDesc.Append("SpanMan changed from " + _SpanMan_orig + " to " + _SpanMan + ";");
                sbUpdateCommandText.Append("SpanMan = " + convertToSQL(_SpanMan) + ", ");
            }
            if (_ReHire != _ReHire_orig)
            {
                sbUpdateDesc.Append("ReHire changed from " + _ReHire_orig + " to " + _ReHire + ";");
                sbUpdateCommandText.Append("ReHire = " + convertToSQL(_ReHire) + ", ");
            }
            if (_PreEmpTstDate != _PreEmpTstDate_orig)
            {
                sbUpdateDesc.Append("PreEmpTstDate changed from " + _PreEmpTstDate_orig + " to " + _PreEmpTstDate + ";");
                sbUpdateCommandText.Append("PreEmpTstDate = " + convertToSQL(_PreEmpTstDate) + ", ");
            }
            if (_SpecimenID != _SpecimenID_orig)
            {
                sbUpdateDesc.Append("SpecimenID changed from " + _SpecimenID_orig + " to " + _SpecimenID + ";");
                sbUpdateCommandText.Append("SpecimenID = " + convertToSQL(_SpecimenID) + ", ");
            }           
            if(sbUpdateDesc.ToString() != "")
			{
				sbUpdateDesc.Insert(0,"WebSite Update by " + CTPA.Common.Config.getWSUser.UserName + " to Employee " + _AUTOID.ToString() + "("+ NAME + ") at " + DateTime.Now.ToString() + " =");
                sbUpdateCommandText.Insert(0,"UPDATE Driverup_primary set ");
                sbUpdateCommandText.Remove(sbUpdateCommandText.Length - 2, 1);
                sbUpdateCommandText.Append(" WHERE AUTOID = " + _AUTOID_orig + ";");
			}
		}

        /// <summary>
        /// Convert an object to an SQL formatted string
        /// </summary>
        /// <param name="Field">The object to convert</param>
        /// <returns>The string use in SQL</returns>
        private string convertToSQL(object Field)
        {
            string returnVal;
            if (Field == null)
            {
                returnVal = "NULL";
            }
            else
            {
                char[] dot = new char[1];
                dot[0] = '.';
                switch (Field.GetType().ToString().Split(dot)[1])
                {
                    case "Integer":
                    case "Float":
                    case "Double":
                    case "Int32":
                    case "Long":
                    case "Short":
                    case "Boolean":
                        returnVal = "'" + Field.ToString() + "'";
                        break;
                    case "Int16":
                        returnVal = Field.ToString();
                        break;
                    case "String":
                    case "Datetime":
                        returnVal = "'" + Field.ToString() + "'";
                        break;
                    default:
                        returnVal = "REPORT ERROR: Unhandeled field type in DRIVER.CS" + Field.GetType().ToString();
                        break;
                }
            }
            return returnVal;
        }


        /// <summary>
        /// Load the driver object from the database
        /// </summary>
        private void LoadDriver()
		{
			DataRow row = GetDriver();
			try
            {
                InitFromRow(row);
            }
            catch (Exception ex)
            {
                throw (new Exception("Unable to load Employee from database", ex));
            }
		}

        /// <summary>
        /// Initialize the object from the given datarow
        /// </summary>
        /// <param name="row">The row to load into the current driver object</param>
        private void InitFromRow(DataRow row)
        {
        
        if (!row.IsNull("COMP_ID"))
            {
                _COMP_ID = _COMP_ID_orig = Convert.ToDouble(row["COMP_ID"]);
            }
            if (!row.IsNull("RNDGRPID")){
                _RNDGRPID = _RNDGRPID_orig = Convert.ToInt16(row["RNDGRPID"]);
        }        
            if (!row.IsNull("NAME"))            {
                _NAME = _NAME_orig = CTPA.Common.Validator.capitalizeFirstWord(row["NAME"].ToString());
            }
            if (!row.IsNull("FIRSTNAME"))
            {
                _FIRSTNAME = _FIRSTNAME_orig = CTPA.Common.Validator.capitalizeFirstWord(row["FIRSTNAME"].ToString());
            }
            if (!row.IsNull("MIDDLENAME"))   
            {
                _MIDDLENAME = _MIDDLENAME_orig = CTPA.Common.Validator.capitalizeFirstWord(row["MIDDLENAME"].ToString());
            }
            if (!row.IsNull("LASTNAME"))          
            {
                _LASTNAME = _LASTNAME_orig = CTPA.Common.Validator.capitalizeFirstWord(row["LASTNAME"].ToString());
            }
            if (!row.IsNull("TITLENAME"))          
            {
                _TITLENAME = _TITLENAME_orig = CTPA.Common.Validator.ValidateTitleName(row["TITLENAME"].ToString());
            }
            if (!row.IsNull("ADDRESS1"))      
            {
                _ADDRESS1 = _ADDRESS1_orig = CTPA.Common.Validator.ValidateAddress(row["ADDRESS1"].ToString());
            }
            if (!row.IsNull("ADDRESS2"))   
            {
                _ADDRESS2 = _ADDRESS2_orig = CTPA.Common.Validator.ValidateAddress(row["ADDRESS2"].ToString());
            }
            if (!row.IsNull("CITY"))          
            {
                _CITY = _CITY_orig = CTPA.Common.Validator.ValidateCity(row["CITY"].ToString()); 
            }
            if (!row.IsNull("STATE"))     
            {
                _STATE = _STATE_orig = CTPA.Common.Validator.ValidateState(row["State"].ToString());
            }
            if (!row.IsNull("ZIP"))   
            {
                _ZIP = _ZIP_orig = CTPA.Common.Validator.ValidateZIP(row["ZIP"].ToString());
            }
            if (!row.IsNull("HOMEPHONE"))  
            {
                _HOMEPHONE = _HOMEPHONE_orig = CTPA.Common.Validator.ValidatePhone(row["HOMEPHONE"].ToString());
            }
            if (!row.IsNull("WORKPHONE"))     
            {
                _WORKPHONE = _WORKPHONE_orig = CTPA.Common.Validator.ValidatePhone(row["WORKPHONE"].ToString());
            }
            if (!row.IsNull("EMERPHONE"))     
            {
                _EMERPHONE = _EMERPHONE_orig = CTPA.Common.Validator.ValidatePhone(row["EMERPHONE"].ToString());
            }
            if (!row.IsNull("CDL_NUM"))     
            {
                _CDL_NUM = _CDL_NUM_orig = CTPA.Common.Validator.ValidateDL(row["CDL_NUM"].ToString());
            }
            if (!row.IsNull("SS_NUM"))   
            {
                _SS_NUM = _SS_NUM_orig = CTPA.Common.Validator.ValidateSSN(row["SS_NUM"].ToString());
            }
            if (!row.IsNull("BIRTH_DATE"))          
            {
                _BIRTH_DATE = _BIRTH_DATE_orig = row["BIRTH_DATE"].ToString();
            }
            if (!row.IsNull("STATUSFLAG"))     
            {
                _STATUSFLAG = _STATUSFLAG_orig = row["STATUSFLAG"].ToString();
            }
            if (!row.IsNull("CARD"))    
            {
                _CARD = _CARD_orig = row["CARD"].ToString();
            }
            if (!row.IsNull("HIREDT"))        
            {
                _HIREDT = _HIREDT_orig = row["HIREDT"].ToString();
            }
            if (!row.IsNull("ACTIVE"))      
            {
                _ACTIVE = _ACTIVE_orig = row["ACTIVE"].ToString();
            }
            if (!row.IsNull("INACTIVE"))  
            {
                _INACTIVE = _INACTIVE_orig = row["INACTIVE"].ToString();
            }
            if (!row.IsNull("CELLPHONE")) 
            {
                _CELLPHONE = _CELLPHONE_orig = CTPA.Common.Validator.ValidatePhone(row["CELLPHONE"].ToString());
            }
            if (!row.IsNull("PAGERPHONE"))          
            {
                _PAGERPHONE = _PAGERPHONE_orig = CTPA.Common.Validator.ValidatePhone(row["PAGERPHONE"].ToString());
            }
            if (!row.IsNull("OOSID"))                
            {
               _OOSID = _OOSID_orig = (int)row["OOSID"];
            }
            if (!row.IsNull("OOSDATE"))          
                {
                _OOSDATE = _OOSDATE_orig = row["OOSDATE"].ToString();
            }      
            if (!row.IsNull("OOSEXPDATE"))    
            {
                _OOSEXPDATE = _OOSEXPDATE_orig = row["OOSEXPDATE"].ToString();
            }      
            if (!row.IsNull("OOSEXPACTION"))      
            {
               _OOSEXPACTION = _OOSEXPACTION_orig = (int)row["OOSEXPACTION"];
            }  
            if (!row.IsNull("TAG_IDCARD"))      
            {
                _TAG_IDCARD = _TAG_IDCARD_orig = Convert.ToBoolean(row["TAG_IDCARD"]);
            }     
            if (!row.IsNull("RNDWARNINGS"))          
            {
                _RNDWARNINGS = _RNDWARNINGS_orig = Convert.ToInt16(row["RNDWARNINGS"]);
            }     
            if (!row.IsNull("RNDWARNINGREC"))          
            {
                _RNDWARNINGREC = _RNDWARNINGREC_orig = Convert.ToInt16(row["RNDWARNINGREC"]);
            }
            if (!row.IsNull("OOSRNDAUTOID"))        
            {
                _OOSRNDAUTOID = _OOSRNDAUTOID_orig = (int)row["OOSRNDAUTOID"];
            }       
            if (!row.IsNull("RNDWAVIER"))         
            {
                _RNDWAVIER = _RNDWAVIER_orig = (float)row["RNDWAVIER"];
            }       
            if (!row.IsNull("RNDWAVIERBATCH"))       
            {
                _RNDWAVIERBATCH = _RNDWAVIERBATCH_orig = (float)row["RNDWAVIERBATCH"];
            }       
            if (!row.IsNull("RENEWALYEAR"))           
            {
                _RENEWALYEAR = _RENEWALYEAR_orig = Convert.ToInt16(row["RENEWALYEAR"]);
            }       
            if (!row.IsNull("statEA"))       
            {
                _statEA = _statEA_orig = Convert.ToBoolean(row["statEA"]);
            }  
            if (!row.IsNull("POOLID"))  
            {
                _POOLID = _POOLID_orig = (int)row["POOLID"];
            }    
            if (!row.IsNull("IDTAGstr"))   
            {
                _IDTAGstr = _IDTAGstr_orig = row["IDTAGstr"].ToString();
                }      
            if (!row.IsNull("sessiontag"))  
            {
                _sessiontag = _sessiontag_orig = row["sessiontag"].ToString();
                }  
            
            if (!row.IsNull("comments"))     
            {
                _comments = _comments_orig = row["comments"].ToString();
                }    
            if (!row.IsNull("newreserve"))    
            {
                _newreserve = _newreserve_orig = row["newreserve"].ToString();
                }     
            if (!row.IsNull("LOGMUSTREAD"))       
            {
                _LOGMUSTREAD = _LOGMUSTREAD_orig = Convert.ToBoolean(row["LOGMUSTREAD"]);
                }     
            if (!row.IsNull("RNDSeed"))    
            {
                _RNDSeed = _RNDSeed_orig = Convert.ToDouble(row["RNDSeed"]);
                }   
            if (!row.IsNull("RNDSeed2"))         
            {
                _RNDSeed2 = _RNDSeed2_orig = Convert.ToDouble(row["RNDSeed2"]);
                }     
            if (!row.IsNull("PreEmpTstComplete"))    
            {
                _PreEmpTstComplete = _PreEmpTstComplete_orig = row["PreEmpTstComplete"].ToString();
            }
            if (!row.IsNull("SpanMan"))
            {
                _SpanMan = _SpanMan_orig = row["SpanMan"].ToString();
            }
            if (!row.IsNull("ReHire"))
            {
                _ReHire = _ReHire_orig = row["ReHire"].ToString();
            }
            if (!row.IsNull("PreEmpTstDate"))
            {
                _PreEmpTstDate = _PreEmpTstDate_orig = row["PreEmpTstDate"].ToString();
            }
            if (!row.IsNull("SpecimenID"))
            {
                _SpecimenID = _SpecimenID_orig = row["SpecimenID"].ToString();
            }       
        } 

        /// <summary>
        /// Gets the data record from a stored procedure using the current Driver object's AutoID Key
        /// </summary>
        /// <returns></returns>
		private DataRow GetDriver()
		{
			SqlParameter[] prams = new SqlParameter[1];
			prams[0] = new SqlParameter("@AUTOID", SqlDbType.Int);
			prams[0].Value = _AUTOID;
			return (SqlHelper.ExecuteDataset(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.DRIVER_Select", prams).Tables[0].Rows[0]);			
		}

        /// <summary>
        /// Checks whether there is a pending web site update for a driver
        /// </summary>
        /// <param name="DriverID">The driver who may have changes pending from the website</param>
        /// <returns></returns>
        public static int checkPendingChange(int DriverID)
        {
            return WSUpdate.isPending(DriverID.ToString(), "Employee");
        }
#endregion
    }
}