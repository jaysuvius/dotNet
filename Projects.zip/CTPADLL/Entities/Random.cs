using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace CTPA.Entities
{
   
	public class Random {
        public enum LoadType
        {
            Driver,
            Test
        }

#region Declarations
		private int _RNDAUTOID;
		private int _RNDGRPID;
		private int _RNDID;
		private int _TESTID;
		private int _BATCHID;
		private string _DATERETURN;
		private string _DATEWARNINGSENT;
		private bool _WARNINGTAG;
		private bool _NRTAG;
		private string _DATEWARNINGRETURN;
		private string _DATEVOIDED;
		private string _DATEVOIDED_AL;
		private string _DATETESTED;
		private string _DATETESTED_AL;
		private bool _DTAM;
		private bool _DTCA;
		private bool _DTCO;
		private bool _DTOP;
		private bool _DTPH;
		private int _DTRJID;
		private bool _DTAL;
		private bool _WARNINGPOS;
		private string _SPECIMENID;
		private int _RNDDTRESULTSID;
		private int _RNDALRESULTSID;
		private bool _DONOTSETOOS;
		private bool _RECWAVED;
		private int _SYNCLOCK;
		private int _DTMROORIGINID;
		private bool _DTSYNC;
		private bool _DTRefusal;
		private bool _DTInv;
		private bool _DTSub;
		private bool _DTAdu;
		private bool _DTcan;
		private bool _DTngd;
		private string _ConsortRefusal;
		private string _EmployerRefusal;
		private string _DATECCFrcv;
		private string _Comment;
#endregion

		// constructor
		public Random () {
            _RNDAUTOID= 0;
		}

		public Random(int LoadID, LoadType whichType)
		{
            if (whichType == LoadType.Driver)
            {
                _RNDAUTOID = 0;
                _RNDID = LoadID;
            }
            else if (whichType == LoadType.Test)
            {
                _RNDAUTOID = LoadID;
                _RNDID = 0;
            }
            else
            {
                throw new Exception("Invalid argument for Random constructor");
            }
            LoadRANDOMIZE_TBL();
		}

#region Properties
		public int RNDAUTOID {get {return _RNDAUTOID;} set {_RNDAUTOID = value;}}
		public int RNDGRPID {get {return _RNDGRPID;} set {_RNDGRPID = value;}}
		public int RNDID {get {return _RNDID;} set {_RNDID = value;}}
		public int TESTID {get {return _TESTID;} set {_TESTID = value;}}
		public int BATCHID {get {return _BATCHID;} set {_BATCHID = value;}}
		public string DATERETURN {get {return _DATERETURN;} set {_DATERETURN = value;}}
		public string DATEWARNINGSENT {get {return _DATEWARNINGSENT;} set {_DATEWARNINGSENT = value;}}
		public bool WARNINGTAG {get {return _WARNINGTAG;} set {_WARNINGTAG = value;}}
		public bool NRTAG {get {return _NRTAG;} set {_NRTAG = value;}}
		public string DATEWARNINGRETURN {get {return _DATEWARNINGRETURN;} set {_DATEWARNINGRETURN = value;}}
		public string DATEVOIDED {get {return _DATEVOIDED;} set {_DATEVOIDED = value;}}
		public string DATEVOIDED_AL {get {return _DATEVOIDED_AL;} set {_DATEVOIDED_AL = value;}}
		public string DATETESTED {get {return _DATETESTED;} set {_DATETESTED = value;}}
		public string DATETESTED_AL {get {return _DATETESTED_AL;} set {_DATETESTED_AL = value;}}
		public bool DTAM {get {return _DTAM;} set {_DTAM = value;}}
		public bool DTCA {get {return _DTCA;} set {_DTCA = value;}}
		public bool DTCO {get {return _DTCO;} set {_DTCO = value;}}
		public bool DTOP {get {return _DTOP;} set {_DTOP = value;}}
		public bool DTPH {get {return _DTPH;} set {_DTPH = value;}}
		public int DTRJID {get {return _DTRJID;} set {_DTRJID = value;}}
		public bool DTAL {get {return _DTAL;} set {_DTAL = value;}}
		public bool WARNINGPOS {get {return _WARNINGPOS;} set {_WARNINGPOS = value;}}
		public string SPECIMENID {get {return _SPECIMENID;} set {_SPECIMENID = value;}}
		public int RNDDTRESULTSID {get {return _RNDDTRESULTSID;} set {_RNDDTRESULTSID = value;}}
		public int RNDALRESULTSID {get {return _RNDALRESULTSID;} set {_RNDALRESULTSID = value;}}
		public bool DONOTSETOOS {get {return _DONOTSETOOS;} set {_DONOTSETOOS = value;}}
		public bool RECWAVED {get {return _RECWAVED;} set {_RECWAVED = value;}}
		public int SYNCLOCK {get {return _SYNCLOCK;} set {_SYNCLOCK = value;}}
		public int DTMROORIGINID {get {return _DTMROORIGINID;} set {_DTMROORIGINID = value;}}
		public bool DTSYNC {get {return _DTSYNC;} set {_DTSYNC = value;}}
		public bool DTRefusal {get {return _DTRefusal;} set {_DTRefusal = value;}}
		public bool DTInv {get {return _DTInv;} set {_DTInv = value;}}
		public bool DTSub {get {return _DTSub;} set {_DTSub = value;}}
		public bool DTAdu {get {return _DTAdu;} set {_DTAdu = value;}}
		public bool DTcan {get {return _DTcan;} set {_DTcan = value;}}
		public bool DTngd {get {return _DTngd;} set {_DTngd = value;}}
		public string ConsortRefusal {get {return _ConsortRefusal;} set {_ConsortRefusal = value;}}
		public string EmployerRefusal {get {return _EmployerRefusal;} set {_EmployerRefusal = value;}}
		public string DATECCFrcv {get {return _DATECCFrcv;} set {_DATECCFrcv = value;}}
		public string Comment {get {return _Comment;} set {_Comment = value;}}
        public Entities.Driver driver{ get { if (_RNDID != 0) { return new Driver(_RNDID); } else { return null; } } }
        public string DTDRG { get {
            if (_DTcan)
                return "CAN";
            else if (_DTRefusal)
                return "REF";
            else if (_DTInv)
                return "INV";
            else if (_DTSub)
                return "SUB";
            else if (_DTAdu)
                return "ADU";
            else if (_NRTAG)
                return ("DNR");
            else if ((_DTCO || _DTOP || _DTPH || _DTAM || _DTCA ) && (_DTRJID <= 0) && (_DATEVOIDED==null || _DATEVOIDED == string.Empty))
                return "POS";
            else if (_DATEVOIDED != null && _DATEVOIDED != string.Empty)
                return "DTV";
            else if (_DTRJID > 0)
                return "REJ";
            else if (_SPECIMENID == string.Empty || _SPECIMENID == null)
                return "REQ";
            else if (_DATETESTED == null)
                return "PEN";
            else if (_Comment.ToUpper().Contains("HOLD"))
                return "HLD";
            else return "NEG";}}

        public string DTALC { get {
            if (_TESTID != 3)
                return "-";
            else if (_NRTAG)
                return "ANR";
            else if (_DATEVOIDED_AL != null && _DATEVOIDED_AL != string.Empty)
                return "ATV";
            else if (_DATETESTED_AL == null || _DATETESTED_AL == string.Empty)
                return "REQ";
            else if (_DTAL)
                return "POS";
            else return "NEG";}}
#endregion

	
		// LoadRANDOMIZE_TBL
		private void LoadRANDOMIZE_TBL()
		{
			SqlDataReader reader = GetRANDOMIZE_TBL();
			try
			{
				if (reader.HasRows)
				{
					if (reader.Read())
					{
						_RNDAUTOID = (int) reader["RNDAUTOID"];
						_RNDGRPID = (int) reader["RNDGRPID"];
						_RNDID = (int) reader["RNDID"];
						_TESTID = (int) reader["TESTID"];
						_BATCHID = (int) reader["BATCHID"];
						_DATERETURN = reader["DATERETURN"].ToString();
						_DATEWARNINGSENT = reader["DATEWARNINGSENT"].ToString();
						_WARNINGTAG = Convert.ToBoolean(reader["WARNINGTAG"]);
						_NRTAG = Convert.ToBoolean(reader["NRTAG"]);
						_DATEWARNINGRETURN = reader["DATEWARNINGRETURN"].ToString();
						_DATEVOIDED = reader["DATEVOIDED"].ToString();
						_DATEVOIDED_AL = reader["DATEVOIDED_AL"].ToString();
						_DATETESTED = reader["DATETESTED"].ToString();
						_DATETESTED_AL = reader["DATETESTED_AL"].ToString();
						_DTAM = Convert.ToBoolean(reader["DTAM"]);
						_DTCA = Convert.ToBoolean(reader["DTCA"]);
						_DTCO = Convert.ToBoolean(reader["DTCO"]);
						_DTOP = Convert.ToBoolean(reader["DTOP"]);
						_DTPH = Convert.ToBoolean(reader["DTPH"]);
						_DTRJID = Convert.ToInt16(reader["DTRJID"]);
						_DTAL = Convert.ToBoolean(reader["DTAL"]);
						_WARNINGPOS = Convert.ToBoolean(reader["WARNINGPOS"]);
						_SPECIMENID = reader["SPECIMENID"].ToString();
						_RNDDTRESULTSID = Convert.ToInt16(reader["RNDDTRESULTSID"]);
						_RNDALRESULTSID = Convert.ToInt16(reader["RNDALRESULTSID"]);
						_DONOTSETOOS = Convert.ToBoolean(reader["DONOTSETOOS"]);
						_RECWAVED = Convert.ToBoolean(reader["RECWAVED"]);
						_SYNCLOCK = (int) reader["SYNCLOCK"];
						_DTMROORIGINID = Convert.ToInt16(reader["DTMROORIGINID"]);
						_DTSYNC = Convert.ToBoolean(reader["DTSYNC"]);
						_DTRefusal = Convert.ToBoolean(reader["DTRefusal"]);
						_DTInv = Convert.ToBoolean(reader["DTInv"]);
						_DTSub = Convert.ToBoolean(reader["DTSub"]);
						_DTAdu = Convert.ToBoolean(reader["DTAdu"]);
						_DTcan = Convert.ToBoolean(reader["DTcan"]);
						_DTngd = Convert.ToBoolean(reader["DTngd"]);
						_ConsortRefusal = reader["ConsortRefusal"].ToString();
						_EmployerRefusal = reader["EmployerRefusal"].ToString();
						_DATECCFrcv = reader["DATECCFrcv"].ToString();
						_Comment = reader["Comment"].ToString();
					}
				}
			}
			catch (Exception ex)
			{
				throw(new Exception("Unable to load RANDOMIZE_TBL from database", ex));
			}
		}

		private SqlDataReader GetRANDOMIZE_TBL()
		{
            SqlParameter[] prams;
            if (_RNDAUTOID != 0)
            {
                prams = new SqlParameter[1];
                prams[0] = new SqlParameter("@RNDAUTOID", SqlDbType.Int);
                prams[0].Value = _RNDAUTOID;
                return (SqlHelper.ExecuteReader(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.RANDOMIZE_TBL_Select", prams));
            }
            else if (_RNDID != 0)
            {
                prams = new SqlParameter[1];
                prams[0] = new SqlParameter("@RNDID", SqlDbType.Int);
                prams[0].Value = _RNDID;
                return (SqlHelper.ExecuteReader(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.RANDOMIZE_TBL_Select_By_Driver", prams));
            }
            else
            {
                return null;
            }
			
		}
	}
}