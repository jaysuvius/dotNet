using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Net;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

using System.Web.Services.Protocols;
using Rse2005 = CTPADLL.ReportExecution005;

namespace CTPA.common
{

    public class PDFWrapper
    {
        private string RptMemo = "";

        // protected void LinkButton1_Click(object sender, EventArgs e)
        // {

        //     RenderPdf("/EMPLOYEES");
        //}

        //Call Reporting service to render PDF
        public void RenderPdf(string compid, string strReportName)
        {

            // Prepare Render arguments
            //long intCompID = Profile.CompID;
            //string strCompID = (string)intCompID;
            //string strCompID = null;
            System.Guid FileGuid;
            string strFileName = null;
            string historyID = null;
            string deviceInfo = null;
            string format = "PDF";
            Byte[] results;
            string encoding = String.Empty;
            string mimeType = String.Empty;
            string extension = String.Empty;
            Rse2005.Warning[] warnings = null;
            string[] streamIDs = null;
            string strResponsePram = null;
            string strResponsePath = ConfigurationSettings.AppSettings["AppDocumentPath"];
            System.Text.StringBuilder sb = new System.Text.StringBuilder();


            Rse2005.ReportExecutionService rsExec = new Rse2005.ReportExecutionService();
            rsExec.Credentials = System.Net.CredentialCache.DefaultCredentials;

            //rsExec.Credentials = new NetworkCredential(rcs, Sierra117, cdtoasbs);

            Rse2005.ExecutionInfo ei = rsExec.LoadReport(strReportName, historyID);
            Rse2005.ParameterValue[] rptParameters = new Rse2005.ParameterValue[1];

            rptParameters[0] = new Rse2005.ParameterValue();
            rptParameters[0].Name = "COMP_ID";
            rptParameters[0].Value = compid;


            //render the PDF
            rsExec.SetExecutionParameters(rptParameters, "en-us");
            results = rsExec.Render(format, deviceInfo, out extension, out encoding, out mimeType, out warnings, out streamIDs);
            sb.Append(compid.ToString());
            sb.Append("_");
            FileGuid = Guid.NewGuid();
            //strCompID = compid.ToString();
            strFileName = compid;
            strFileName += "_";
            strFileName += FileGuid.ToString();
            strResponsePram += "attachment; filename= ";
            strResponsePram += strFileName;
            strResponsePram += ".pdf";
            strResponsePath += strFileName;
            strResponsePath += ".pdf";
            //Response.AddHeader("content-disposition", strResponsePram);
            //Response.OutputStream.Write(results, 0, results.Length);
            FileStream stream = File.Create(strResponsePath, results.Length);
            //Console.WriteLine("File created.");
            stream.Write(results, 0, results.Length);
            //Console.WriteLine("Result written to the file.");
            stream.Close();


            //This is very important if you want to directly download from stream instead of file
            //Response.End();

        }

    }

}