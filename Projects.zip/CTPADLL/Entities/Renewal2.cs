using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;

namespace CTPA.Entities
{

    public class Renewal
    {
        #region Declarations
        private StringBuilder sbUpdateDesc = new StringBuilder();
        private StringBuilder sbUpdateCommandText = new StringBuilder();
        private Int32 _RENEWAL_ID;
        private Int32 _RENEWAL_ID_orig;
        private Int32 _COMP_ID;
        private Int32 _COMP_ID_orig;
        private DateTime _COMP_INFO_CONFIRMED;
        private DateTime _COMP_INFO_CONFIRMED_orig;
        private string _COMP_INFO_CONFIRMED_by;
        private string _COMP_INFO_CONFIRMED_by_orig;
        private DateTime _EMP_INFO_CONFIRMED;
        private DateTime _EMP_INFO_CONFIRMED_orig;
        private string _EMP_INFO_CONFIRMED_BY;
        private string _EMP_INFO_CONFIRMED_BY_orig;
        private DateTime _AGREEMENTS_SIGNED_RECEIVED;
        private DateTime _AGREEMENTS_SIGNED_RECEIVED_orig;
        private DateTime _AGREEMENTS_SIGNED_ONLINE;
        private DateTime _AGREEMENTS_SIGNED_ONLINE_orig;
        private string _AGREEMENTS_SIGNED_ONLINE_BY;
        private string _AGREEMENTS_SIGNED_ONLINE_BY_orig;
        private string _AGREEMENTS_SIGNATURE;
        private string _AGREEMENTS_SIGNATURE_orig;
        private DateTime _AGREEMENTS_SIGNATURE_DATE;
        private DateTime _AGREEMENTS_SIGNATURE_DATE_orig;
        private DateTime _PAYMENT_RECEIVED_PENDING;
        private DateTime _PAYMENT_RECEIVED_PENDING_orig;
        private DateTime _PAYMENT_RECEIVED_PROCESSED;
        private DateTime _PAYMENT_RECEIVED_PROCESSED_orig;
        private bool _PAID_ONLINE;
        private bool _PAID_ONLINE_orig;
        private bool _PROCESS_COMPLETE;
        private bool _PROCESS_COMPLETE_orig;
        private string _CC_NUMBER;
        private string _CC_NUMBER_orig;
        private DateTime _CC_EXP;
        private string _CC_EXP_orig;
        private int _CC_CCV;
        private int _CC_CCV_orig;
        private string _CC_NAME;
        private string _CC_NAME_orig;
        private string _CC_ADDRESS;
        private string _CC_ADDRESS_orig;
        private string _CC_CITY;
        private string _CC_CITY_orig;
        private string _CC_STATE;
        private string _CC_STATE_orig;
        private Int32 _CC_ZIP;
        private Int32 _CC_ZIP_orig;
        #endregion

        // constructor
        public Renewal()
        {
        }

        public Renewal(Int32 LoadID)
        {
            COMP_ID = LoadID;
        }

        public void Save()
        {
            try
            {
                SqlDataReader reader = GetRenewal();

                if (reader.HasRows)
                {
                    Update();

                }
                else
                    Insert();
                {
                }

            }
            catch (Exception ex)
            {
                Insert();
            }
        } 
        #region Properties
        //public string updateDesc { get { return sbUpdateDesc.ToString(); } }
        //public string updateCommand { get { return sbUpdateCommandText.ToString(); } }
        public Int32 RENEWAL_ID { get { return _RENEWAL_ID; } set { _RENEWAL_ID = value; } }
        public Int32 COMP_ID { get { return _COMP_ID; } set { _COMP_ID = value; } }
        public DateTime COMP_INFO_CONFIRMED { get { return _COMP_INFO_CONFIRMED; } set { _COMP_INFO_CONFIRMED = value; } }
        public string COMP_INFO_CONFIRMED_by { get { return _COMP_INFO_CONFIRMED_by; } set { _COMP_INFO_CONFIRMED_by = value; } }
        public DateTime EMP_INFO_CONFIRMED { get { return _EMP_INFO_CONFIRMED; } set { _EMP_INFO_CONFIRMED = value; } }
        public string EMP_INFO_CONFIRMED_BY { get { return _EMP_INFO_CONFIRMED_BY; } set { _EMP_INFO_CONFIRMED_BY = value; } }
        public DateTime AGREEMENTS_SIGNED_RECEIVED { get { return _AGREEMENTS_SIGNED_RECEIVED; } set { _AGREEMENTS_SIGNED_RECEIVED = value; } }
        public DateTime AGREEMENTS_SIGNED_ONLINE { get { return _AGREEMENTS_SIGNED_ONLINE; } set { _AGREEMENTS_SIGNED_ONLINE = value; } }
        public string AGREEMENTS_SIGNED_ONLINE_BY { get { return _AGREEMENTS_SIGNED_ONLINE_BY; } set { _AGREEMENTS_SIGNED_ONLINE_BY = value; } }
        public string AGREEMENTS_SIGNATURE { get { return _AGREEMENTS_SIGNATURE; } set { _AGREEMENTS_SIGNATURE = value; } }
        public DateTime AGREEMENTS_SIGNATURE_DATE { get { return _AGREEMENTS_SIGNATURE_DATE; } set { _AGREEMENTS_SIGNATURE_DATE = value; } }
        public DateTime PAYMENT_RECEIVED_PENDING { get { return _PAYMENT_RECEIVED_PENDING; } set { _PAYMENT_RECEIVED_PENDING = value; } }
        public DateTime PAYMENT_RECEIVED_PROCESSED { get { return _PAYMENT_RECEIVED_PROCESSED; } set { _PAYMENT_RECEIVED_PROCESSED = value; } }
        public bool PAID_ONLINE { get { return _PAID_ONLINE; } set { _PAID_ONLINE = value; } }
        public bool PROCESS_COMPLETE { get { return _PROCESS_COMPLETE; } set { _PROCESS_COMPLETE = value; } }
        public string CC_NUMBER { get { return _CC_NUMBER; } set { _CC_NUMBER = value; } }
        public DateTime CC_EXP { get { return _CC_EXP; } set { _CC_EXP = value; } }
        public int CC_CCV { get { return _CC_CCV; } set { _CC_CCV = value; } }
        public string CC_NAME { get { return _CC_NAME; } set { _CC_NAME = value; } }
        public string CC_ADDRESS { get { return _CC_ADDRESS; } set { _CC_ADDRESS = value; } }
        public string CC_CITY { get { return _CC_CITY; } set { _CC_CITY = value; } }
        public string CC_STATE { get { return _CC_STATE; } set { _CC_STATE = value; } }
        public Int32 CC_ZIP { get { return _CC_ZIP; } set { _CC_ZIP = value; } }
        #endregion

       
        private void Insert()
        {
            SqlParameter[] prams = new SqlParameter[1];
            prams[0] = new SqlParameter("@COMP_ID", SqlDbType.BigInt);
            prams[0].Value = _COMP_ID;
            SqlHelper.ExecuteNonQuery(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.RENEWALS_Insert", prams);
            Update();
        }

       
        //Update
        public void Update()
        {
            SqlParameter[] prams = new SqlParameter[22];
	        prams[0] = new SqlParameter("@RENEWAL_ID", SqlDbType.BigInt);
	        prams[0].Value = RENEWAL_ID;
	        prams[1] = new SqlParameter("@COMP_ID", SqlDbType.BigInt);
	        prams[1].Value = COMP_ID;
            prams[2] = new SqlParameter("@COMP_INFO_CONFIRMED", SqlDbType.DateTime);
            if (_COMP_INFO_CONFIRMED != CTPA.Common.Config.InitialDateTime)
            {        
                prams[2].Value = COMP_INFO_CONFIRMED;
   	        }
            else
            {
                prams[2].Value = System.DBNull.Value;
            }
	        prams[3] = new SqlParameter("@COMP_INFO_CONFIRMED_by", SqlDbType.NChar, 64);
	        prams[3].Value = COMP_INFO_CONFIRMED_by;
            prams[4] = new SqlParameter("@EMP_INFO_CONFIRMED", SqlDbType.DateTime);
             if (_EMP_INFO_CONFIRMED != CTPA.Common.Config.InitialDateTime)
            {
	            prams[4].Value = EMP_INFO_CONFIRMED;
            }
             else
             {
                prams[4].Value = System.DBNull.Value;
             }
            prams[5] = new SqlParameter("@EMP_INFO_CONFIRMED_BY", SqlDbType.NChar, 64);
	        prams[5].Value = EMP_INFO_CONFIRMED_BY; 
            prams[6] = new SqlParameter("@AGREEMENTS_SIGNED_RECEIVED", SqlDbType.DateTime);
            if (_AGREEMENTS_SIGNED_RECEIVED != CTPA.Common.Config.InitialDateTime)
            {
	            prams[6].Value = AGREEMENTS_SIGNED_RECEIVED;
            }
                 else
            {
                prams[6].Value = System.DBNull.Value;
            }
            prams[7] = new SqlParameter("@AGREEMENTS_SIGNED_ONLINE", SqlDbType.DateTime);
             if (_AGREEMENTS_SIGNED_ONLINE != CTPA.Common.Config.InitialDateTime)
             {
                prams[7].Value = AGREEMENTS_SIGNED_ONLINE;
             }
             else
             {
                prams[7].Value = System.DBNull.Value;
             }
            prams[8] = new SqlParameter("@AGREEMENTS_SIGNED_ONLINE_BY", SqlDbType.NChar, 64);
	        prams[8].Value = AGREEMENTS_SIGNED_ONLINE_BY;
	        prams[9] = new SqlParameter("@AGREEMENTS_SIGNATURE", SqlDbType.NChar, 64);
  	        prams[9].Value = AGREEMENTS_SIGNATURE;

	        if (_AGREEMENTS_SIGNATURE_DATE!=CTPA.Common.Config.InitialDateTime)
            {
                prams[10].Value = AGREEMENTS_SIGNATURE_DATE;
            }
            else
            {
                prams[10].Value = System.DBNull.Value;
            }
        	
             prams[11] = new SqlParameter("@PAYMENT_RECEIVED_PENDING", SqlDbType.DateTime);
             if (_PAYMENT_RECEIVED_PENDING != CTPA.Common.Config.InitialDateTime)
             {
                prams[11].Value = PAYMENT_RECEIVED_PENDING;
             }
             else
             {
                 prams[11].Value = System.DBNull.Value;
             }
            prams[12] = new SqlParameter("@PAYMENT_RECEIVED_PROCESSED", SqlDbType.DateTime);
             if (_PAYMENT_RECEIVED_PROCESSED != CTPA.Common.Config.InitialDateTime)
             {
                prams[12].Value = PAYMENT_RECEIVED_PROCESSED;
             }
             else
             {
                 prams[12].Value = System.DBNull.Value;
             }
	        prams[13] = new SqlParameter("@PAID_ONLINE", SqlDbType.Bit);
	        prams[13].Value = PAID_ONLINE;
	        prams[14] = new SqlParameter("@PROCESS_COMPLETE", SqlDbType.Bit);
	        prams[14].Value = PROCESS_COMPLETE;
	        prams[15] = new SqlParameter("@CC_NUMBER", SqlDbType.NVarChar, 50);
	        prams[15].Value = CC_NUMBER;
            prams[16] = new SqlParameter("@CC_EXP", SqlDbType.DateTime);
            if (_CC_EXP != CTPA.Common.Config.InitialDateTime)
            {
                prams[16].Value = CC_EXP;
            }
            else
            {
                prams[16].Value = System.DBNull.Value;
            }
	        prams[17] = new SqlParameter("@CC_CCV", SqlDbType.Int);
	        prams[17].Value = CC_CCV;
	        prams[18] = new SqlParameter("@CC_NAME", SqlDbType.NChar, 64);
	        prams[18].Value = CC_NAME;
	        prams[19] = new SqlParameter("@CC_ADDRESS", SqlDbType.NChar, 64);
	        prams[19].Value = CC_ADDRESS;
	        prams[20] = new SqlParameter("@CC_CITY", SqlDbType.NChar, 64);
	        prams[20].Value = CC_CITY;
	        prams[21] = new SqlParameter("@CC_STATE", SqlDbType.NChar, 2);
	        prams[21].Value = CC_STATE;
	        prams[22] = new SqlParameter("@CC_ZIP", SqlDbType.BigInt);
	        prams[22].Value = CC_ZIP;
        }

        // LoadRENEWALS
        private void LoadRenewal()
		{
			SqlDataReader reader = GetRenewal();
			try
			{
				if (reader.HasRows)
				{
					if (reader.Read())
					{
                        if (reader["_RENEWAL_ID"] != System.DBNull.Value)
                        {
						    _RENEWAL_ID  = RENEWAL_ID;
                        }
                        if (reader["_COMP_ID"] != System.DBNull.Value)
                        {
						    _COMP_ID = _COMP_ID_orig = COMP_ID;
                        }
                        if (reader["COMP_INFO_CONFIRMED"] != System.DBNull.Value)
                        {
                            _COMP_INFO_CONFIRMED = Convert.ToDateTime(reader["COMP_INFO_CONFIRMED"]);
                        } 
                        if (reader["COMP_INFO_CONFIRMED_by"] != System.DBNull.Value)
                        {
                            _COMP_INFO_CONFIRMED_by = reader["COMP_INFO_CONFIRMED_by"].ToString().Trim();
                        }
                        if (reader["EMP_INFO_CONFIRMED"] != System.DBNull.Value)
                        {
                            _EMP_INFO_CONFIRMED = Convert.ToDateTime(reader["EMP_INFO_CONFIRMED"]);
                        }
                        if (reader["EMP_INFO_CONFIRMED_By"] != System.DBNull.Value)
                        {
                            _EMP_INFO_CONFIRMED_BY = reader["COMP_INFO_CONFIRMED_by"].ToString().Trim();
                        }
						if (reader["AGREEMENTS_SIGNED_RECEIVED"] != System.DBNull.Value)
                        {
                            _AGREEMENTS_SIGNED_RECEIVED  = Convert.ToDateTime(reader["AGREEMENTS_SIGNED_RECEIVED"]);
						}
                        if (reader["AGREEMENTS_SIGNED_ONLINE"] != System.DBNull.Value)
                        {                      
                            _AGREEMENTS_SIGNED_ONLINE = Convert.ToDateTime(reader["AGREEMENTS_SIGNED_ONLINE"]);
						}
                        if (reader["AGREEMENTS_SIGNED_ONLINE_BY"] != System.DBNull.Value)
                        {
                            _AGREEMENTS_SIGNED_ONLINE_BY = reader["AGREEMENTS_SIGNED_ONLINE_BY"].ToString();
                        }
						if (reader["AGREEMENTS_SIGNATURE"] != System.DBNull.Value)
                        {
                            _AGREEMENTS_SIGNATURE = reader["AGREEMENTS_SIGNATURE"].ToString();
						}
                         if (reader["AGREEMENTS_SIGNATURE_DATE"] != System.DBNull.Value)
                        {
                            _AGREEMENTS_SIGNATURE_DATE = Convert.ToDateTime(reader["AGREEMENTS_SIGNATURE_DATE"]);
                        }
						if (reader["PAYMENT_RECEIVED_PENDING "] != System.DBNull.Value)
                        {
                            _PAYMENT_RECEIVED_PENDING = Convert.ToDateTime(reader["PAYMENT_RECEIVED_PENDING"]);
						}
                        if (reader["PAYMENT_RECEIVED_PROCESSED"] != System.DBNull.Value)
                        {
                            _PAYMENT_RECEIVED_PROCESSED = Convert.ToDateTime(reader["PAYMENT_RECEIVED_PROCESSED"]);
						}
                        if (reader["PAID_ONLINE"] != System.DBNull.Value)
                        {
                            _PAID_ONLINE = Convert.ToBoolean(reader["PAID_ONLINE"]);
                        }
                        if (reader["PROCESS_COMPLETE"] != System.DBNull.Value)
                        {
                            _PROCESS_COMPLETE = Convert.ToBoolean(reader["PROCESS_COMPLETE"]);
						}
                        if (reader["CC_NUMBER"] != System.DBNull.Value)
                        {
                            _CC_NUMBER =  reader["CC_NUMBER"].ToString();
						}
                        if (reader["CC_EXP"] != System.DBNull.Value)
                        {
                            _CC_EXP =  Convert.ToDateTime(reader["CC_EXP"]);
						}
                        if (reader["CC_CCV"] != System.DBNull.Value)
                        {
                            _CC_CCV = _CC_CCV_orig = (int) reader["CC_CCV"];
						}
                        if (reader["CC_NAME"] != System.DBNull.Value)
                        {
                            _CC_NAME = _CC_NAME_orig = reader["CC_NAME"].ToString();
						}
                        if (reader["CC_ADDRESS"] != System.DBNull.Value)
                        {
                            _CC_ADDRESS = _CC_ADDRESS_orig = reader["CC_ADDRESS"].ToString();
						}
                        if (reader["CC_CITY"] != System.DBNull.Value)
                        {
                            _CC_CITY = _CC_CITY_orig = reader["CC_CITY"].ToString();
						}
                        if (reader["CC_STATE"] != System.DBNull.Value)
                        {
                            _CC_STATE = _CC_STATE_orig = reader["CC_STATE"].ToString();
                        }
                        if (reader["CC_ZIP"] != System.DBNull.Value)
                        {
                            _CC_ZIP = _CC_ZIP_orig = CC_ZIP;
					    }
                        
                    }
                
            }
         }    
            catch (Exception ex)
			{
				throw(new Exception("Unable to load RENEWALS from database", ex));
			}
		}
        

        private SqlDataReader GetRenewal()
        {
            SqlParameter[] prams = new SqlParameter[1];
            prams[0] = new SqlParameter("@RENEWAL_ID", SqlDbType.BigInt);
            prams[0].Value = _RENEWAL_ID;
            return (SqlHelper.ExecuteReader(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.RENEWALS_Select", prams));

        }
    }
}
