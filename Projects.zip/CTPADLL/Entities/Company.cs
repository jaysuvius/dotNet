using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;


namespace CTPA.Entities
{    
    /// <summary>
    /// This Class is the structure for accessing company information and encapualting it for using in the application. 
    /// </summary>
    public class Company
     
    {
        #region Declarations
        private StringBuilder sbUpdateDesc = new StringBuilder();
        private StringBuilder sbUpdateCommandText = new StringBuilder();
        private bool _ACCOUNT_LOCK = false;
        private bool _ACCOUNT_LOCK_orig = false;
        private double _COMP_ID = 0;
        private double _COMP_ID_orig = 0;
        private string _LOCATIONID = string.Empty;
        private string _LOCATIONID_orig = string.Empty;
        private string _COMPANY = string.Empty;
        private string _COMPANY_orig = string.Empty;
        private string _zzz_OWNEROP = string.Empty;
        private string _zzz_OWNEROP_orig = string.Empty;
        private double _ORIGAMT = 0;
        private double _ORIGAMT_orig = 0;
        private double _AMT_PAID = 0;
        private double _AMT_PAID_orig = 0;
        private double _DRIVERS = 0;
        private double _DRIVERS_orig = 0;
        private string _NAME = string.Empty;
        private string _NAME_orig = string.Empty;
        private string _ADDRESS1 = string.Empty;
        private string _ADDRESS1_orig = string.Empty;
        private string _ADDRESS2 = string.Empty;
        private string _ADDRESS2_orig = string.Empty;
        private string _CITY = string.Empty;
        private string _CITY_orig = string.Empty;
        private string _STATE = string.Empty;
        private string _STATE_orig = string.Empty;
        private string _ZIP = string.Empty;
        private string _ZIP_orig = string.Empty;
        private string _CITY2 = string.Empty;
        private string _CITY2_orig = string.Empty;
        private string _STATE2 = string.Empty;
        private string _STATE2_orig = string.Empty;
        private string _ZIP2 = string.Empty;
        private string _ZIP2_orig = string.Empty;
        private string _CERT_SENT = string.Empty;
        private string _CERT_SENT_orig = string.Empty;
        private string _CERT_SENT1 = string.Empty;
        private string _CERT_SENT1_orig = string.Empty;
        private string _UPS = string.Empty;
        private string _UPS_orig = string.Empty;
        private string _CLASS = string.Empty;
        private string _CLASS_orig = string.Empty;
        private double _ZZZ_CPUC = 0;
        private double _ZZZ_CPUC_orig = 0;
        private string _LicID = string.Empty;
        private string _LicID_orig = string.Empty;
        private int _LicType = 0;
        private int _LicType_orig = 0;
        private string _ZZZ_ICC = string.Empty;
        private string _ZZZ_ICC_orig = string.Empty;
        private string _HOMEPHONE = string.Empty;
        private string _HOMEPHONE_orig = string.Empty;
        private string _WORKPHONE = string.Empty;
        private string _WORKPHONE_orig = string.Empty;
        private string _EMERPHONE = string.Empty;
        private string _EMERPHONE_orig = string.Empty;
        private string _FAX = string.Empty;
        private string _FAX_orig = string.Empty;
        private string _CONTACT = string.Empty;
        private string _CONTACT_orig = string.Empty;
        private string _STATUSFLAG = string.Empty;
        private string _STATUSFLAG_orig = string.Empty;
        private string _LC_REQUEST = string.Empty;
        private string _LC_REQUEST_orig = string.Empty;
        private string _LC_SETUP = string.Empty;
        private string _LC_SETUP_orig = string.Empty;
        private string _BILLTYPE = string.Empty;
        private string _BILLTYPE_orig = string.Empty;
        private double _STMT_NUM = 0;
        private double _STMT_NUM_orig = 0;
        private string _ACTIVE = string.Empty;
        private string _ACTIVE_orig = string.Empty;
        private string _INACTIVE = string.Empty;
        private string _INACTIVE_orig = string.Empty;
        private double _COC_FORMS = 0;
        private double _COC_FORMS_orig = 0;
        private string _COUNTY = string.Empty;
        private string _COUNTY_orig = string.Empty;
        private double _ACTIVEDR = 0;
        private double _ACTIVEDR_orig = 0;
        private double _INACTIVEDR = 0;
        private double _INACTIVEDR_orig = 0;
        private double _OPENDRIVER = 0;
        private double _OPENDRIVER_orig = 0;
        private double _DELETEDDR = 0;
        private double _DELETEDDR_orig = 0;
        private string _CELLPHONE = string.Empty;
        private string _CELLPHONE_orig = string.Empty;
        private string _PAGERPHONE = string.Empty;
        private string _PAGERPHONE_orig = string.Empty;
        private string _LNAME = string.Empty;
        private string _LNAME_orig = string.Empty;
        private string _OTHER = string.Empty;
        private string _OTHER_orig = string.Empty;
        private int _TOTAL_SLOTS = 0;
        private int _TOTAL_SLOTS_orig = 0;
        private int _LABID = 0;
        private int _LABID_orig = 0;
        private string _EMAIL = string.Empty;
        private string _EMAIL_orig = string.Empty;
        private int _REPLACEPOINTS = 0;
        private int _REPLACEPOINTS_orig = 0;
        private string _MEMBERYEAR = string.Empty;
        private string _MEMBERYEAR_orig = string.Empty;
        private string _RENEWDATE = string.Empty;
        private string _RENEWDATE_orig = string.Empty;
        private int _RESERVESLOTS = 0;
        private int _RESERVESLOTS_orig = 0;
        private bool _STOPRENEWAL = false;
        private bool _STOPRENEWAL_orig = false;
        private bool _tag_labsetup = false;
        private bool _tag_labsetup_orig = false;
        private int _RNDGRPID_CD = 0;
        private int _RNDGRPID_CD_orig = 0;
        private int _RNDGRPID_OO = 0;
        private int _RNDGRPID_OO_orig = 0;
        private int _RNDGRPID_DF = 0;
        private int _RNDGRPID_DF_orig = 0;
        private int _RNDGRPID_PUC = 0;
        private int _RNDGRPID_PUC_orig = 0;
        private string _OLD_PHARMCHEMID = string.Empty;
        private string _OLD_PHARMCHEMID_orig = string.Empty;
        private string _OLD_DRUGFREEID = string.Empty;
        private string _OLD_DRUGFREEID_orig = string.Empty;
        private string _OLD_LABCORPID = string.Empty;
        private string _OLD_LABCORPID_orig = string.Empty;
        private string _SUPERNAME = string.Empty;
        private string _SUPERNAME_orig = string.Empty;
        private string _TAGstr = string.Empty;
        private string _TAGstr_orig = string.Empty;
        private int _LANGUAGEHELPID = 0;
        private int _LANGUAGEHELPID_orig = 0;
        private int _SERVREPID = 0;
        private int _SERVREPID_orig = 0;
        private int _LABRESPONSEID = 0;
        private int _LABRESPONSEID_orig = 0;
        private string _old2_LABCORP_ID = string.Empty;
        private string _old2_LABCORP_ID_orig = string.Empty;
        private string _old2_DRUGFREEID = string.Empty;
        private string _old2_DRUGFREEID_orig = string.Empty;
        private string _FORMCERTTYPE = string.Empty;
        private string _FORMCERTTYPE_orig = string.Empty;
        private string _FORMSATYPE = string.Empty;
        private string _FORMSATYPE_orig = string.Empty;
        private float _stats_recurbalance = 0;
        private float _stats_recurbalance_orig = 0;
        private int _stats_cnt_oo = 0;
        private int _stats_cnt_oo_orig = 0;
        private int _stats_cnt_cd = 0;
        private int _stats_cnt_cd_orig = 0;
        private int _stats_cnt_df = 0;
        private int _stats_cnt_df_orig = 0;
        private int _stats_cnt_puc = 0;
        private int _stats_cnt_puc_orig = 0;
        private int _stats_cnt_actives = 0;
        private int _stats_cnt_actives_orig = 0;
        private int _stats_cnt_opens = 0;
        private int _stats_cnt_opens_orig = 0;
        private int _stats_cnt_enroll = 0;
        private int _stats_cnt_enroll_orig = 0;
        private int _stats_cnt_y2dDROPs = 0;
        private int _stats_cnt_y2dDROPs_orig = 0;
        private int _stats_cnt_y2dADDs = 0;
        private int _stats_cnt_y2dADDs_orig = 0;
        private string _stats_cnt_lastupdate = string.Empty;
        private string _stats_cnt_lastupdate_orig = string.Empty;
        private string _AFFCODE = string.Empty;
        private string _AFFCODE_orig = string.Empty;
        private string _CLASS_OLDREF = string.Empty;
        private string _CLASS_OLDREF_orig = string.Empty;
        private int _DEACTIVATEID = 0;
        private int _DEACTIVATEID_orig = 0;
        private bool _FORCENONEEDSUPERVISOR = false;
        private bool _FORCENONEEDSUPERVISOR_orig = false;
        private string _WEB_LOGIN_PASS = string.Empty;
        private string _WEB_LOGIN_PASS_orig = string.Empty;
        #endregion
        #region Properties
        public string updateDesc { get { Update(); return sbUpdateDesc.ToString(); } }
        public string updateCommand { get { Update(); return sbUpdateCommandText.ToString(); } }
        public bool ACCOUNT_LOCK { get { return _ACCOUNT_LOCK; } set { _ACCOUNT_LOCK = value; } }
        public double COMP_ID { get { return _COMP_ID; } set { _COMP_ID = value; } }
        public string LOCATIONID { get { return _LOCATIONID; } set { _LOCATIONID = value; } }
        public string COMPANY { get { return _COMPANY; } set { _COMPANY = value; } }
        public string zzz_OWNEROP { get { return _zzz_OWNEROP; } set { _zzz_OWNEROP = value; } }
        public double ORIGAMT { get { return _ORIGAMT; } set { _ORIGAMT = value; } }
        public double AMT_PAID { get { return _AMT_PAID; } set { _AMT_PAID = value; } }
        public double DRIVERS { get { return _DRIVERS; } set { _DRIVERS = value; } }
        public string NAME { get { return _NAME; } set { _NAME = value; } }
        public string ADDRESS1 { get { return _ADDRESS1; } set { _ADDRESS1 = value; } }
        public string ADDRESS2 { get { return _ADDRESS2; } set { _ADDRESS2 = value; } }
        public string CITY { get { return _CITY; } set { _CITY = value; } }
        public string STATE { get { return _STATE; } set { _STATE = value; } }
        public string ZIP { get { return _ZIP; } set { _ZIP = value; } }
        public string CITY2 { get { return _CITY2; } set { _CITY2 = value; } }
        public string STATE2 { get { return _STATE2; } set { _STATE2 = value; } }
        public string ZIP2 { get { return _ZIP2; } set { _ZIP2 = value; } }
        public string CERT_SENT { get { return _CERT_SENT; } set { _CERT_SENT = value; } }
        public string CERT_SENT1 { get { return _CERT_SENT1; } set { _CERT_SENT1 = value; } }
        public string UPS { get { return _UPS; } set { _UPS = value; } }
        public string CLASS { get { return _CLASS; } set { _CLASS = value; } }
        public double ZZZ_CPUC { get { return _ZZZ_CPUC; } set { _ZZZ_CPUC = value; } }
        public string LicID { get { return _LicID; } set { _LicID = value; } }
        public int LicType { get { return _LicType; } set { _LicType = value; } }
        public string ZZZ_ICC { get { return _ZZZ_ICC; } set { _ZZZ_ICC = value; } }
        public string HOMEPHONE { get { return _HOMEPHONE; } set { _HOMEPHONE = value; } }
        public string WORKPHONE { get { return _WORKPHONE; } set { _WORKPHONE = value; } }
        public string EMERPHONE { get { return _EMERPHONE; } set { _EMERPHONE = value; } }
        public string FAX { get { return _FAX; } set { _FAX = value; } }
        public string CONTACT { get { return _CONTACT; } set { _CONTACT = value; } }
        public string STATUSFLAG { get { return _STATUSFLAG; } set { _STATUSFLAG = value; } }
        public string LC_REQUEST { get { return _LC_REQUEST; } set { _LC_REQUEST = value; } }
        public string LC_SETUP { get { return _LC_SETUP; } set { _LC_SETUP = value; } }
        public string BILLTYPE { get { return _BILLTYPE; } set { _BILLTYPE = value; } }
        public double STMT_NUM { get { return _STMT_NUM; } set { _STMT_NUM = value; } }
        public string ACTIVE { get { return _ACTIVE; } set { _ACTIVE = value; } }
        public string INACTIVE { get { return _INACTIVE; } set { _INACTIVE = value; } }
        public double COC_FORMS { get { return _COC_FORMS; } set { _COC_FORMS = value; } }
        public string COUNTY { get { return _COUNTY; } set { _COUNTY = value; } }
        public double ACTIVEDR { get { return _ACTIVEDR; } set { _ACTIVEDR = value; } }
        public double INACTIVEDR { get { return _INACTIVEDR; } set { _INACTIVEDR = value; } }
        public double OPENDRIVER { get { return _OPENDRIVER; } set { _OPENDRIVER = value; } }
        public double DELETEDDR { get { return _DELETEDDR; } set { _DELETEDDR = value; } }
        public string CELLPHONE { get { return _CELLPHONE; } set { _CELLPHONE = value; } }
        public string PAGERPHONE { get { return _PAGERPHONE; } set { _PAGERPHONE = value; } }
        public string LNAME { get { return _LNAME; } set { _LNAME = value; } }
        public string OTHER { get { return _OTHER; } set { _OTHER = value; } }
        public int TOTAL_SLOTS { get { return _TOTAL_SLOTS; } set { _TOTAL_SLOTS = value; } }
        public int LABID { get { return _LABID; } set { _LABID = value; } }
        public string EMAIL { get { return _EMAIL; } set { _EMAIL = value; } }
        public int REPLACEPOINTS { get { return _REPLACEPOINTS; } set { _REPLACEPOINTS = value; } }
        public string MEMBERYEAR { get { return _MEMBERYEAR; } set { _MEMBERYEAR = value; } }
        public string RENEWDATE { get { return _RENEWDATE; } set { _RENEWDATE = value; } }
        public int RESERVESLOTS { get { return _RESERVESLOTS; } set { _RESERVESLOTS = value; } }
        public bool STOPRENEWAL { get { return _STOPRENEWAL; } set { _STOPRENEWAL = value; } }
        public bool tag_labsetup { get { return _tag_labsetup; } set { _tag_labsetup = value; } }
        public int RNDGRPID_CD { get { return _RNDGRPID_CD; } set { _RNDGRPID_CD = value; } }
        public int RNDGRPID_OO { get { return _RNDGRPID_OO; } set { _RNDGRPID_OO = value; } }
        public int RNDGRPID_DF { get { return _RNDGRPID_DF; } set { _RNDGRPID_DF = value; } }
        public int RNDGRPID_PUC { get { return _RNDGRPID_PUC; } set { _RNDGRPID_PUC = value; } }
        public string OLD_PHARMCHEMID { get { return _OLD_PHARMCHEMID; } set { _OLD_PHARMCHEMID = value; } }
        public string OLD_DRUGFREEID { get { return _OLD_DRUGFREEID; } set { _OLD_DRUGFREEID = value; } }
        public string OLD_LABCORPID { get { return _OLD_LABCORPID; } set { _OLD_LABCORPID = value; } }
        public string SUPERNAME { get { return _SUPERNAME; } set { _SUPERNAME = value; } }
        public string TAGstr { get { return _TAGstr; } set { _TAGstr = value; } }
        public int LANGUAGEHELPID { get { return _LANGUAGEHELPID; } set { _LANGUAGEHELPID = value; } }
        public int SERVREPID { get { return _SERVREPID; } set { _SERVREPID = value; } }
        public int LABRESPONSEID { get { return _LABRESPONSEID; } set { _LABRESPONSEID = value; } }
        public string old2_LABCORP_ID { get { return _old2_LABCORP_ID; } set { _old2_LABCORP_ID = value; } }
        public string old2_DRUGFREEID { get { return _old2_DRUGFREEID; } set { _old2_DRUGFREEID = value; } }
        public string FORMCERTTYPE { get { return _FORMCERTTYPE; } set { _FORMCERTTYPE = value; } }
        public string FORMSATYPE { get { return _FORMSATYPE; } set { _FORMSATYPE = value; } }
        public float stats_recurbalance { get { return _stats_recurbalance; } set { _stats_recurbalance = value; } }
        public int stats_cnt_oo { get { return _stats_cnt_oo; } set { _stats_cnt_oo = value; } }
        public int stats_cnt_cd { get { return _stats_cnt_cd; } set { _stats_cnt_cd = value; } }
        public int stats_cnt_df { get { return _stats_cnt_df; } set { _stats_cnt_df = value; } }
        public int stats_cnt_puc { get { return _stats_cnt_puc; } set { _stats_cnt_puc = value; } }
        public int stats_cnt_actives { get { return _stats_cnt_actives; } set { _stats_cnt_actives = value; } }
        public int stats_cnt_opens { get { return _stats_cnt_opens; } set { _stats_cnt_opens = value; } }
        public int stats_cnt_enroll { get { return _stats_cnt_enroll; } set { _stats_cnt_enroll = value; } }
        public int stats_cnt_y2dDROPs { get { return _stats_cnt_y2dDROPs; } set { _stats_cnt_y2dDROPs = value; } }
        public int stats_cnt_y2dADDs { get { return _stats_cnt_y2dADDs; } set { _stats_cnt_y2dADDs = value; } }
        public string stats_cnt_lastupdate { get { return _stats_cnt_lastupdate; } set { _stats_cnt_lastupdate = value; } }
        public string AFFCODE { get { return _AFFCODE; } set { _AFFCODE = value; } }
        public string CLASS_OLDREF { get { return _CLASS_OLDREF; } set { _CLASS_OLDREF = value; } }
        public int DEACTIVATEID { get { return _DEACTIVATEID; } set { _DEACTIVATEID = value; } }
        public bool FORCENONEEDSUPERVISOR { get { return _FORCENONEEDSUPERVISOR; } set { _FORCENONEEDSUPERVISOR = value; } }
        public string WEB_LOGIN_PASS { get { return _WEB_LOGIN_PASS; } set { _WEB_LOGIN_PASS = value; } }
        public bool isChanged { get { Update();  return updateDesc != ""; } }
        public int hasPendingChange { get { return checkPendingChange(_COMP_ID); } }
        public int statsYTDAdds
        {
            get
            {
                SqlParameter[] prams = new SqlParameter[1];
                prams[0] = new SqlParameter("@COMP_ID", SqlDbType.Real);
                prams[0].Value = _COMP_ID;
                try
                {
                    return Convert.ToInt32(SqlHelper.ExecuteDataset(Common.Config.ConnectionString, CommandType.StoredProcedure, "STATS_YTD_DRIVER_ADDS", prams).Tables[0].Rows[0]["COUNTADDS"]);
                }
                catch (Exception ex)
                {
                    return 0;
                }
            }
        }
        public int statsYTDDrops
        {
            get
            {
                SqlParameter[] prams = new SqlParameter[1];
                prams[0] = new SqlParameter("@COMP_ID", SqlDbType.Real);
                prams[0].Value = _COMP_ID;
                try
                {
                    return Convert.ToInt32(SqlHelper.ExecuteDataset(Common.Config.ConnectionString, CommandType.StoredProcedure, "STATS_YTD_DRIVER_DROPS", prams).Tables[0].Rows[0]["COUNTDROPS"]);
                }
                catch (Exception ex)
                {
                    return 0;
                }
            }
        }
        #endregion
        #region Member Functions

        /// <summary>
        /// Default constructor unused
        /// </summary>
        private Company()
        {
        }

        /// <summary>
        /// Creates a company object and loads a record. 
        /// </summary>
        /// <param name="LoadID">TPA company ID to load into entity</param>
        public Company(int LoadID)
        {
            _COMP_ID = LoadID;
            LoadCompany();
        }
     
        /// <summary>
        /// Build the updateDesc and updateCmd strings based on the current object
        /// </summary>
        private void Update()
        {
            sbUpdateDesc.Remove(0, sbUpdateDesc.Length);
            sbUpdateCommandText.Remove(0, sbUpdateCommandText.Length);
            if (_ACCOUNT_LOCK != _ACCOUNT_LOCK_orig)
            {
                sbUpdateDesc.Append("ACCOUNT_LOCK changed from " + _ACCOUNT_LOCK_orig + " to " + _ACCOUNT_LOCK + ";");
                sbUpdateCommandText.Append("ACCOUNT_LOCK = " + convertToSQL(  _ACCOUNT_LOCK.ToString() ) + ", ");
            }
            if (_COMP_ID != _COMP_ID_orig)
            {
                sbUpdateDesc.Append("COMP_ID changed from " + _COMP_ID_orig + " to " + _COMP_ID + ";");
                sbUpdateCommandText.Append("COMP_ID = " + convertToSQL(  _COMP_ID.ToString() ) + ", ");
            }
            if (_LOCATIONID != _LOCATIONID_orig)
            {
                sbUpdateDesc.Append("LOCATIONID changed from " + _LOCATIONID_orig + " to " + _LOCATIONID + ";");
                sbUpdateCommandText.Append("LOCATIONID = " + convertToSQL(  _LOCATIONID.ToString() ) + ", ");
            }
            if (_COMPANY != _COMPANY_orig)
            {
                sbUpdateDesc.Append("COMPANY changed from " + _COMPANY_orig + " to " + _COMPANY + ";");
                sbUpdateCommandText.Append("COMPANY = " + convertToSQL(  _COMPANY.ToString() ) + ", ");
            }
            if (_zzz_OWNEROP != _zzz_OWNEROP_orig)
            {
                sbUpdateDesc.Append("zzz_OWNEROP changed from " + _zzz_OWNEROP_orig + " to " + _zzz_OWNEROP + ";");
                sbUpdateCommandText.Append("zzz_OWNEROP = " + convertToSQL(  _zzz_OWNEROP.ToString() ) + ", ");
            }
            if (_ORIGAMT != _ORIGAMT_orig)
            {
                sbUpdateDesc.Append("ORIGAMT changed from " + _ORIGAMT_orig + " to " + _ORIGAMT + ";");
                sbUpdateCommandText.Append("ORIGAMT = " + convertToSQL(  _ORIGAMT.ToString() ) + ", ");
            }
            if (_AMT_PAID != _AMT_PAID_orig)
            {
                sbUpdateDesc.Append("AMT_PAID changed from " + _AMT_PAID_orig + " to " + _AMT_PAID + ";");
                sbUpdateCommandText.Append("AMT_PAID = " + convertToSQL(  _AMT_PAID.ToString() ) + ", ");
            }
            if (_DRIVERS != _DRIVERS_orig)
            {
                sbUpdateDesc.Append("DRIVERS changed from " + _DRIVERS_orig + " to " + _DRIVERS + ";");
                sbUpdateCommandText.Append("DRIVERS = " + convertToSQL(  _DRIVERS.ToString() ) + ", ");
            }
            if (_NAME != _NAME_orig)
            {
                sbUpdateDesc.Append("NAME changed from " + _NAME_orig + " to " + _NAME + ";");
                sbUpdateCommandText.Append("NAME = " + convertToSQL(  _NAME.ToString() ) + ", ");
            }
            if (_ADDRESS1 != _ADDRESS1_orig)
            {
                sbUpdateDesc.Append("ADDRESS1 changed from " + _ADDRESS1_orig + " to " + _ADDRESS1 + ";");
                sbUpdateCommandText.Append("ADDRESS1 = " + convertToSQL(  _ADDRESS1.ToString() ) + ", ");
            }
            if (_ADDRESS2 != _ADDRESS2_orig)
            {
                sbUpdateDesc.Append("ADDRESS2 changed from " + _ADDRESS2_orig + " to " + _ADDRESS2 + ";");
                sbUpdateCommandText.Append("ADDRESS2 = " + convertToSQL(  _ADDRESS2.ToString() ) + ", ");
            }
            if (_CITY != _CITY_orig)
            {
                sbUpdateDesc.Append("CITY changed from " + _CITY_orig + " to " + _CITY + ";");
                sbUpdateCommandText.Append("CITY = " + convertToSQL(  _CITY.ToString() ) + ", ");
            }
            if (_STATE != _STATE_orig)
            {
                sbUpdateDesc.Append("STATE changed from " + _STATE_orig + " to " + _STATE + ";");
                sbUpdateCommandText.Append("STATE = " + convertToSQL(  _STATE.ToString() ) + ", ");
            }
            if (_ZIP != _ZIP_orig)
            {
                sbUpdateDesc.Append("ZIP changed from " + _ZIP_orig + " to " + _ZIP + ";");
                sbUpdateCommandText.Append("ZIP = " + convertToSQL(  _ZIP.ToString() ) + ", ");
            }
            if (_CITY2 != _CITY2_orig)
            {
                sbUpdateDesc.Append("CITY2 changed from " + _CITY2_orig + " to " + _CITY2 + ";");
                sbUpdateCommandText.Append("CITY2 = " + convertToSQL(  _CITY2.ToString() ) + ", ");
            }
            if (_STATE2 != _STATE2_orig)
            {
                sbUpdateDesc.Append("STATE2 changed from " + _STATE2_orig + " to " + _STATE2 + ";");
                sbUpdateCommandText.Append("STATE2 = " + convertToSQL(  _STATE2.ToString() ) + ", ");
            }
            if (_ZIP2 != _ZIP2_orig)
            {
                sbUpdateDesc.Append("ZIP2 changed from " + _ZIP2_orig + " to " + _ZIP2 + ";");
                sbUpdateCommandText.Append("ZIP2 = " + convertToSQL(  _ZIP2.ToString() ) + ", ");
            }
            if (_CERT_SENT != _CERT_SENT_orig)
            {
                sbUpdateDesc.Append("CERT_SENT changed from " + _CERT_SENT_orig + " to " + _CERT_SENT + ";");
                sbUpdateCommandText.Append("CERT_SENT = " + convertToSQL(  _CERT_SENT.ToString() ) + ", ");
            }
            if (_CERT_SENT1 != _CERT_SENT1_orig)
            {
                sbUpdateDesc.Append("CERT_SENT1 changed from " + _CERT_SENT1_orig + " to " + _CERT_SENT1 + ";");
                sbUpdateCommandText.Append("CERT_SENT1 = " + convertToSQL(  _CERT_SENT1.ToString() ) + ", ");
            }
            if (_UPS != _UPS_orig)
            {
                sbUpdateDesc.Append("UPS changed from " + _UPS_orig + " to " + _UPS + ";");
                sbUpdateCommandText.Append("UPS = " + convertToSQL(  _UPS.ToString() ) + ", ");
            }
            if (_CLASS != _CLASS_orig)
            {
                sbUpdateDesc.Append("CLASS changed from " + _CLASS_orig + " to " + _CLASS + ";");
                sbUpdateCommandText.Append("CLASS = " + convertToSQL(  _CLASS.ToString() ) + ", ");
            }
            if (_ZZZ_CPUC != _ZZZ_CPUC_orig)
            {
                sbUpdateDesc.Append("ZZZ_CPUC changed from " + _ZZZ_CPUC_orig + " to " + _ZZZ_CPUC + ";");
                sbUpdateCommandText.Append("ZZZ_CPUC = " + convertToSQL(  _ZZZ_CPUC.ToString() ) + ", ");
            }
            if (_LicID != _LicID_orig)
            {
                sbUpdateDesc.Append("LicID changed from " + _LicID_orig + " to " + _LicID + ";");
                sbUpdateCommandText.Append("LicID = " + convertToSQL(  _LicID.ToString() ) + ", ");
            }
            if (_LicType != _LicType_orig)
            {
                sbUpdateDesc.Append("LicType changed from " + _LicType_orig + " to " + _LicType + ";");
                sbUpdateCommandText.Append("LicType = " + convertToSQL( _LicType.ToString() ) + ", ");
            }
            if (_ZZZ_ICC != _ZZZ_ICC_orig)
            {
                sbUpdateDesc.Append("ZZZ_ICC changed from " + _ZZZ_ICC_orig + " to " + _ZZZ_ICC + ";");
                sbUpdateCommandText.Append("ZZZ_ICC = " + convertToSQL(  _ZZZ_ICC.ToString() ) + ", ");
            }
            if (_HOMEPHONE != _HOMEPHONE_orig)
            {
                sbUpdateDesc.Append("HOMEPHONE changed from " + _HOMEPHONE_orig + " to " + _HOMEPHONE + ";");
                sbUpdateCommandText.Append("HOMEPHONE = " + convertToSQL(  _HOMEPHONE.ToString() ) + ", ");
            }
            if (_WORKPHONE != _WORKPHONE_orig)
            {
                sbUpdateDesc.Append("WORKPHONE changed from " + _WORKPHONE_orig + " to " + _WORKPHONE + ";");
                sbUpdateCommandText.Append("WORKPHONE = " + convertToSQL(  _WORKPHONE.ToString() ) + ", ");
            }
            if (_EMERPHONE != _EMERPHONE_orig)
            {
                sbUpdateDesc.Append("EMERPHONE changed from " + _EMERPHONE_orig + " to " + _EMERPHONE + ";");
                sbUpdateCommandText.Append("EMERPHONE = " + convertToSQL(  _EMERPHONE.ToString() ) + ", ");
            }
            if (_FAX != _FAX_orig)
            {
                sbUpdateDesc.Append("FAX changed from " + _FAX_orig + " to " + _FAX + ";");
                sbUpdateCommandText.Append("FAX = " + convertToSQL(  _FAX.ToString() ) + ", ");
            }
            if (_CONTACT != _CONTACT_orig)
            {
                sbUpdateDesc.Append("CONTACT changed from " + _CONTACT_orig + " to " + _CONTACT + ";");
                sbUpdateCommandText.Append("CONTACT = " + convertToSQL(  _CONTACT.ToString() ) + ", ");
            }
            if (_STATUSFLAG != _STATUSFLAG_orig)
            {
                sbUpdateDesc.Append("STATUSFLAG changed from " + _STATUSFLAG_orig + " to " + _STATUSFLAG + ";");
                sbUpdateCommandText.Append("STATUSFLAG = " + convertToSQL(  _STATUSFLAG.ToString() ) + ", ");
            }
            if (_LC_REQUEST != _LC_REQUEST_orig)
            {
                sbUpdateDesc.Append("LC_REQUEST changed from " + _LC_REQUEST_orig + " to " + _LC_REQUEST + ";");
                sbUpdateCommandText.Append("LC_REQUEST = " + convertToSQL(  _LC_REQUEST.ToString() ) + ", ");
            }
            if (_LC_SETUP != _LC_SETUP_orig)
            {
                sbUpdateDesc.Append("LC_SETUP changed from " + _LC_SETUP_orig + " to " + _LC_SETUP + ";");
                sbUpdateCommandText.Append("LC_SETUP = " + convertToSQL(  _LC_SETUP.ToString() ) + ", ");
            }
            if (_BILLTYPE != _BILLTYPE_orig)
            {
                sbUpdateDesc.Append("BILLTYPE changed from " + _BILLTYPE_orig + " to " + _BILLTYPE + ";");
                sbUpdateCommandText.Append("BILLTYPE = " + convertToSQL(  _BILLTYPE.ToString() ) + ", ");
            }
            if (_STMT_NUM != _STMT_NUM_orig)
            {
                sbUpdateDesc.Append("STMT_NUM changed from " + _STMT_NUM_orig + " to " + _STMT_NUM + ";");
                sbUpdateCommandText.Append("STMT_NUM = " + convertToSQL(  _STMT_NUM.ToString() ) + ", ");
            }
            if (_ACTIVE != _ACTIVE_orig)
            {
                sbUpdateDesc.Append("ACTIVE changed from " + _ACTIVE_orig + " to " + _ACTIVE + ";");
                sbUpdateCommandText.Append("ACTIVE = " + convertToSQL(  _ACTIVE.ToString() ) + ", ");
            }
            if (_INACTIVE != _INACTIVE_orig)
            {
                sbUpdateDesc.Append("INACTIVE changed from " + _INACTIVE_orig + " to " + _INACTIVE + ";");
                sbUpdateCommandText.Append("INACTIVE = " + convertToSQL(  _INACTIVE.ToString() ) + ", ");
            }
            if (_COC_FORMS != _COC_FORMS_orig)
            {
                sbUpdateDesc.Append("COC_FORMS changed from " + _COC_FORMS_orig + " to " + _COC_FORMS + ";");
                sbUpdateCommandText.Append("COC_FORMS = " + convertToSQL(  _COC_FORMS.ToString() ) + ", ");
            }
            if (_COUNTY != _COUNTY_orig)
            {
                sbUpdateDesc.Append("COUNTY changed from " + _COUNTY_orig + " to " + _COUNTY + ";");
                sbUpdateCommandText.Append("COUNTY = " + convertToSQL(  _COUNTY.ToString() ) + ", ");
            }
            if (_ACTIVEDR != _ACTIVEDR_orig)
            {
                sbUpdateDesc.Append("ACTIVEDR changed from " + _ACTIVEDR_orig + " to " + _ACTIVEDR + ";");
                sbUpdateCommandText.Append("ACTIVEDR = " + convertToSQL(  _ACTIVEDR.ToString() ) + ", ");
            }
            if (_INACTIVEDR != _INACTIVEDR_orig)
            {
                sbUpdateDesc.Append("INACTIVEDR changed from " + _INACTIVEDR_orig + " to " + _INACTIVEDR + ";");
                sbUpdateCommandText.Append("INACTIVEDR = " + convertToSQL(  _INACTIVEDR.ToString() ) + ", ");
            }
            if (_OPENDRIVER != _OPENDRIVER_orig)
            {
                sbUpdateDesc.Append("OPENDRIVER changed from " + _OPENDRIVER_orig + " to " + _OPENDRIVER + ";");
                sbUpdateCommandText.Append("OPENDRIVER = " + convertToSQL(  _OPENDRIVER.ToString() ) + ", ");
            }
            if (_DELETEDDR != _DELETEDDR_orig)
            {
                sbUpdateDesc.Append("DELETEDDR changed from " + _DELETEDDR_orig + " to " + _DELETEDDR + ";");
                sbUpdateCommandText.Append("DELETEDDR = " + convertToSQL(  _DELETEDDR.ToString() ) + ", ");
            }
            if (_CELLPHONE != _CELLPHONE_orig)
            {
                sbUpdateDesc.Append("CELLPHONE changed from " + _CELLPHONE_orig + " to " + _CELLPHONE + ";");
                sbUpdateCommandText.Append("CELLPHONE = " + convertToSQL(  _CELLPHONE.ToString() ) + ", ");
            }
            if (_PAGERPHONE != _PAGERPHONE_orig)
            {
                sbUpdateDesc.Append("PAGERPHONE changed from " + _PAGERPHONE_orig + " to " + _PAGERPHONE + ";");
                sbUpdateCommandText.Append("PAGERPHONE = " + convertToSQL(  _PAGERPHONE.ToString() ) + ", ");
            }
            if (_LNAME != _LNAME_orig)
            {
                sbUpdateDesc.Append("LNAME changed from " + _LNAME_orig + " to " + _LNAME + ";");
                sbUpdateCommandText.Append("LNAME = " + convertToSQL(  _LNAME.ToString() ) + ", ");
            }
            if (_OTHER != _OTHER_orig)
            {
                sbUpdateDesc.Append("OTHER changed from " + _OTHER_orig + " to " + _OTHER + ";");
                sbUpdateCommandText.Append("OTHER = " + convertToSQL(  _OTHER.ToString() ) + ", ");
            }
            if (_TOTAL_SLOTS != _TOTAL_SLOTS_orig)
            {
                sbUpdateDesc.Append("TOTAL_SLOTS changed from " + _TOTAL_SLOTS_orig + " to " + _TOTAL_SLOTS + ";");
                sbUpdateCommandText.Append("TOTAL_SLOTS = " + convertToSQL(  _TOTAL_SLOTS.ToString() ) + ", ");
            }
            if (_LABID != _LABID_orig)
            {
                sbUpdateDesc.Append("LABID changed from " + _LABID_orig + " to " + _LABID + ";");
                sbUpdateCommandText.Append("LABID = " + convertToSQL(  _LABID.ToString() ) + ", ");
            }
            if (_EMAIL != _EMAIL_orig)
            {
                sbUpdateDesc.Append("EMAIL changed from " + _EMAIL_orig + " to " + _EMAIL + ";");
                sbUpdateCommandText.Append("EMAIL = " + convertToSQL(  _EMAIL.ToString() ) + ", ");
            }
            if (_REPLACEPOINTS != _REPLACEPOINTS_orig)
            {
                sbUpdateDesc.Append("REPLACEPOINTS changed from " + _REPLACEPOINTS_orig + " to " + _REPLACEPOINTS + ";");
                sbUpdateCommandText.Append("REPLACEPOINTS = " + convertToSQL(  _REPLACEPOINTS.ToString() ) + ", ");
            }
            if (_MEMBERYEAR != _MEMBERYEAR_orig)
            {
                sbUpdateDesc.Append("MEMBERYEAR changed from " + _MEMBERYEAR_orig + " to " + _MEMBERYEAR + ";");
                sbUpdateCommandText.Append("MEMBERYEAR = " + convertToSQL(  _MEMBERYEAR.ToString() ) + ", ");
            }
            if (_RENEWDATE != _RENEWDATE_orig)
            {
                sbUpdateDesc.Append("RENEWDATE changed from " + _RENEWDATE_orig + " to " + _RENEWDATE + ";");
                sbUpdateCommandText.Append("RENEWDATE = " + convertToSQL(  _RENEWDATE.ToString() ) + ", ");
            }
            if (_RESERVESLOTS != _RESERVESLOTS_orig)
            {
                sbUpdateDesc.Append("RESERVESLOTS changed from " + _RESERVESLOTS_orig + " to " + _RESERVESLOTS + ";");
                sbUpdateCommandText.Append("RESERVESLOTS = " + convertToSQL( _RESERVESLOTS.ToString() ) + ", ");
            }
            if (_STOPRENEWAL != _STOPRENEWAL_orig)
            {
                sbUpdateDesc.Append("STOPRENEWAL changed from " + _STOPRENEWAL_orig + " to " + _STOPRENEWAL + ";");
                sbUpdateCommandText.Append("STOPRENEWAL = " + convertToSQL(  _STOPRENEWAL.ToString() ) + ", ");
            }
            if (_tag_labsetup != _tag_labsetup_orig)
            {
                sbUpdateDesc.Append("tag_labsetup changed from " + _tag_labsetup_orig + " to " + _tag_labsetup + ";");
                sbUpdateCommandText.Append("tag_labsetup = " + convertToSQL(  _tag_labsetup.ToString() ) + ", ");
            }
            if (_RNDGRPID_CD != _RNDGRPID_CD_orig)
            {
                sbUpdateDesc.Append("RNDGRPID_CD changed from " + _RNDGRPID_CD_orig + " to " + _RNDGRPID_CD + ";");
                sbUpdateCommandText.Append("RNDGRPID_CD = " + convertToSQL(  _RNDGRPID_CD.ToString() ) + ", ");
            }
            if (_RNDGRPID_OO != _RNDGRPID_OO_orig)
            {
                sbUpdateDesc.Append("RNDGRPID_OO changed from " + _RNDGRPID_OO_orig + " to " + _RNDGRPID_OO + ";");
                sbUpdateCommandText.Append("RNDGRPID_OO = " + convertToSQL(  _RNDGRPID_OO.ToString() ) + ", ");
            }
            if (_RNDGRPID_DF != _RNDGRPID_DF_orig)
            {
                sbUpdateDesc.Append("RNDGRPID_DF changed from " + _RNDGRPID_DF_orig + " to " + _RNDGRPID_DF + ";");
                sbUpdateCommandText.Append("RNDGRPID_DF = " + convertToSQL(  _RNDGRPID_DF.ToString() ) + ", ");
            }
            if (_RNDGRPID_PUC != _RNDGRPID_PUC_orig)
            {
                sbUpdateDesc.Append("RNDGRPID_PUC changed from " + _RNDGRPID_PUC_orig + " to " + _RNDGRPID_PUC + ";");
                sbUpdateCommandText.Append("RNDGRPID_PUC = " + convertToSQL(  _RNDGRPID_PUC.ToString() ) + ", ");
            }
            if (_OLD_PHARMCHEMID != _OLD_PHARMCHEMID_orig)
            {
                sbUpdateDesc.Append("OLD_PHARMCHEMID changed from " + _OLD_PHARMCHEMID_orig + " to " + _OLD_PHARMCHEMID + ";");
                sbUpdateCommandText.Append("OLD_PHARMCHEMID = " + convertToSQL(  _OLD_PHARMCHEMID.ToString() ) + ", ");
            }
            if (_OLD_DRUGFREEID != _OLD_DRUGFREEID_orig)
            {
                sbUpdateDesc.Append("OLD_DRUGFREEID changed from " + _OLD_DRUGFREEID_orig + " to " + _OLD_DRUGFREEID + ";");
                sbUpdateCommandText.Append("OLD_DRUGFREEID = " + convertToSQL(  _OLD_DRUGFREEID.ToString() ) + ", ");
            }
            if (_OLD_LABCORPID != _OLD_LABCORPID_orig)
            {
                sbUpdateDesc.Append("OLD_LABCORPID changed from " + _OLD_LABCORPID_orig + " to " + _OLD_LABCORPID + ";");
                sbUpdateCommandText.Append("OLD_LABCORPID = " + convertToSQL(  _OLD_LABCORPID.ToString() ) + ", ");
            }
            if (_SUPERNAME != _SUPERNAME_orig)
            {
                sbUpdateDesc.Append("SUPERNAME changed from " + _SUPERNAME_orig + " to " + _SUPERNAME + ";");
                sbUpdateCommandText.Append("SUPERNAME = " + convertToSQL(  _SUPERNAME.ToString() ) + ", ");
            }
            if (_TAGstr != _TAGstr_orig)
            {
                sbUpdateDesc.Append("TAGstr changed from " + _TAGstr_orig + " to " + _TAGstr + ";");
                sbUpdateCommandText.Append("TAGstr = " + convertToSQL(  _TAGstr.ToString() ) + ", ");
            }
            if (_LANGUAGEHELPID != _LANGUAGEHELPID_orig)
            {
                sbUpdateDesc.Append("LANGUAGEHELPID changed from " + _LANGUAGEHELPID_orig + " to " + _LANGUAGEHELPID + ";");
                sbUpdateCommandText.Append("LANGUAGEHELPID = " + convertToSQL(  _LANGUAGEHELPID.ToString() ) + ", ");
            }
            if (_SERVREPID != _SERVREPID_orig)
            {
                sbUpdateDesc.Append("SERVREPID changed from " + _SERVREPID_orig + " to " + _SERVREPID + ";");
                sbUpdateCommandText.Append("SERVREPID = " + convertToSQL(  _SERVREPID.ToString() ) + ", ");
            }
            if (_LABRESPONSEID != _LABRESPONSEID_orig)
            {
                sbUpdateDesc.Append("LABRESPONSEID changed from " + _LABRESPONSEID_orig + " to " + _LABRESPONSEID + ";");
                sbUpdateCommandText.Append("LABRESPONSEID = " + convertToSQL(  _LABRESPONSEID.ToString() ) + ", ");
            }
            if (_old2_LABCORP_ID != _old2_LABCORP_ID_orig)
            {
                sbUpdateDesc.Append("old2_LABCORP_ID changed from " + _old2_LABCORP_ID_orig + " to " + _old2_LABCORP_ID + ";");
                sbUpdateCommandText.Append("old2_LABCORP_ID = " + convertToSQL(  _old2_LABCORP_ID.ToString() ) + ", ");
            }
            if (_old2_DRUGFREEID != _old2_DRUGFREEID_orig)
            {
                sbUpdateDesc.Append("old2_DRUGFREEID changed from " + _old2_DRUGFREEID_orig + " to " + _old2_DRUGFREEID + ";");
                sbUpdateCommandText.Append("old2_DRUGFREEID = " + convertToSQL(  _old2_DRUGFREEID.ToString() ) + ", ");
            }
            if (_FORMCERTTYPE != _FORMCERTTYPE_orig)
            {
                sbUpdateDesc.Append("FORMCERTTYPE changed from " + _FORMCERTTYPE_orig + " to " + _FORMCERTTYPE + ";");
                sbUpdateCommandText.Append("FORMCERTTYPE = " + convertToSQL(  _FORMCERTTYPE.ToString() ) + ", ");
            }
            if (_FORMSATYPE != _FORMSATYPE_orig)
            {
                sbUpdateDesc.Append("FORMSATYPE changed from " + _FORMSATYPE_orig + " to " + _FORMSATYPE + ";");
                sbUpdateCommandText.Append("FORMSATYPE = " + convertToSQL(  _FORMSATYPE.ToString() ) + ", ");
            }
            if (_stats_recurbalance != _stats_recurbalance_orig)
            {
                sbUpdateDesc.Append("stats_recurbalance changed from " + _stats_recurbalance_orig + " to " + _stats_recurbalance + ";");
                sbUpdateCommandText.Append("stats_recurbalance = " + convertToSQL(  _stats_recurbalance.ToString() ) + ", ");
            }
            if (_stats_cnt_oo != _stats_cnt_oo_orig)
            {
                sbUpdateDesc.Append("stats_cnt_oo changed from " + _stats_cnt_oo_orig + " to " + _stats_cnt_oo + ";");
                sbUpdateCommandText.Append("stats_cnt_oo = " + convertToSQL(  _stats_cnt_oo.ToString() ) + ", ");
            }
            if (_stats_cnt_cd != _stats_cnt_cd_orig)
            {
                sbUpdateDesc.Append("stats_cnt_cd changed from " + _stats_cnt_cd_orig + " to " + _stats_cnt_cd + ";");
                sbUpdateCommandText.Append("stats_cnt_cd = " + convertToSQL(  _stats_cnt_cd.ToString() ) + ", ");
            }
            if (_stats_cnt_df != _stats_cnt_df_orig)
            {
                sbUpdateDesc.Append("stats_cnt_df changed from " + _stats_cnt_df_orig + " to " + _stats_cnt_df + ";");
                sbUpdateCommandText.Append("stats_cnt_df = " + convertToSQL(  _stats_cnt_df.ToString() ) + ", ");
            }
            if (_stats_cnt_puc != _stats_cnt_puc_orig)
            {
                sbUpdateDesc.Append("stats_cnt_puc changed from " + _stats_cnt_puc_orig + " to " + _stats_cnt_puc + ";");
                sbUpdateCommandText.Append("stats_cnt_puc = " + convertToSQL(  _stats_cnt_puc.ToString() ) + ", ");
            }
            if (_stats_cnt_actives != _stats_cnt_actives_orig)
            {
                sbUpdateDesc.Append("stats_cnt_actives changed from " + _stats_cnt_actives_orig + " to " + _stats_cnt_actives + ";");
                sbUpdateCommandText.Append("stats_cnt_actives = " + convertToSQL(  _stats_cnt_actives.ToString() ) + ", ");
            }
            if (_stats_cnt_opens != _stats_cnt_opens_orig)
            {
                sbUpdateDesc.Append("stats_cnt_opens changed from " + _stats_cnt_opens_orig + " to " + _stats_cnt_opens + ";");
                sbUpdateCommandText.Append("stats_cnt_opens = " + convertToSQL(  _stats_cnt_opens.ToString() ) + ", ");
            }
            if (_stats_cnt_enroll != _stats_cnt_enroll_orig)
            {
                sbUpdateDesc.Append("stats_cnt_enroll changed from " + _stats_cnt_enroll_orig + " to " + _stats_cnt_enroll + ";");
                sbUpdateCommandText.Append("stats_cnt_enroll = " + convertToSQL(  _stats_cnt_enroll.ToString() ) + ", ");
            }
            if (_stats_cnt_y2dDROPs != _stats_cnt_y2dDROPs_orig)
            {
                sbUpdateDesc.Append("stats_cnt_y2dDROPs changed from " + _stats_cnt_y2dDROPs_orig + " to " + _stats_cnt_y2dDROPs + ";");
                sbUpdateCommandText.Append("stats_cnt_y2dDROPs = " + convertToSQL(  _stats_cnt_y2dDROPs.ToString() ) + ", ");
            }
            if (_stats_cnt_y2dADDs != _stats_cnt_y2dADDs_orig)
            {
                sbUpdateDesc.Append("stats_cnt_y2dADDs changed from " + _stats_cnt_y2dADDs_orig + " to " + _stats_cnt_y2dADDs + ";");
                sbUpdateCommandText.Append("stats_cnt_y2dADDs = " + convertToSQL(  _stats_cnt_y2dADDs.ToString() ) + ", ");
            }
            if (_stats_cnt_lastupdate != _stats_cnt_lastupdate_orig)
            {
                sbUpdateDesc.Append("stats_cnt_lastupdate changed from " + _stats_cnt_lastupdate_orig + " to " + _stats_cnt_lastupdate + ";");
                sbUpdateCommandText.Append("stats_cnt_lastupdate = " + convertToSQL(  _stats_cnt_lastupdate.ToString() ) + ", ");
            }
            if (_AFFCODE != _AFFCODE_orig)
            {
                sbUpdateDesc.Append("AFFCODE changed from " + _AFFCODE_orig + " to " + _AFFCODE + ";");
                sbUpdateCommandText.Append("AFFCODE = " + convertToSQL(  _AFFCODE.ToString() ) + ", ");
            }
            if (_CLASS_OLDREF != _CLASS_OLDREF_orig)
            {
                sbUpdateDesc.Append("CLASS_OLDREF changed from " + _CLASS_OLDREF_orig + " to " + _CLASS_OLDREF + ";");
                sbUpdateCommandText.Append("CLASS_OLDREF = " + convertToSQL(  _CLASS_OLDREF.ToString() ) + ", ");
            }
            if (_DEACTIVATEID != _DEACTIVATEID_orig)
            {
                sbUpdateDesc.Append("DEACTIVATEID changed from " + _DEACTIVATEID_orig + " to " + _DEACTIVATEID + ";");
                sbUpdateCommandText.Append("DEACTIVATEID = " + convertToSQL(  _DEACTIVATEID.ToString() ) + ", ");
            }
            if (_FORCENONEEDSUPERVISOR != _FORCENONEEDSUPERVISOR_orig)
            {
                sbUpdateDesc.Append("FORCENONEEDSUPERVISOR changed from " + _FORCENONEEDSUPERVISOR_orig + " to " + _FORCENONEEDSUPERVISOR + ";");
                sbUpdateCommandText.Append("FORCENONEEDSUPERVISOR = " + convertToSQL(  _FORCENONEEDSUPERVISOR.ToString() ) + ", ");
            }
            if (_WEB_LOGIN_PASS != _WEB_LOGIN_PASS_orig)
            {
                sbUpdateDesc.Append("WEB_LOGIN_PASS changed from " + _WEB_LOGIN_PASS_orig + " to " + _WEB_LOGIN_PASS + ";");
                sbUpdateCommandText.Append("WEB_LOGIN_PASS = " + convertToSQL(  _WEB_LOGIN_PASS.ToString() ) + ", ");
            }
            if (sbUpdateDesc.ToString() != "")
            {
                sbUpdateDesc.Insert(0, "WebSite Update by " + CTPA.Common.Config.getWSUser.UserName + " to Company " + COMP_ID + " (" + COMPANY + ") at " + DateTime.Now.ToString() + " =");
                sbUpdateCommandText.Insert(0, "UPDATE CALDATA_TBL set ");
                sbUpdateCommandText.Remove(sbUpdateCommandText.Length - 2, 1);
                sbUpdateCommandText.Append(" WHERE COMP_ID = " + _COMP_ID_orig + ";" ) ;
            }
        }

        /// <summary>
        /// Populates the current company object with data from the database
        /// </summary>
        private void LoadCompany()
        {
            DataRow row = GetCompany();
           try
            {
                    if (!row.HasErrors)
                    {
                        if (!row.IsNull("ACCOUNT_LOCK"))
                        {
                        _ACCOUNT_LOCK = _ACCOUNT_LOCK_orig = Convert.ToBoolean(row["ACCOUNT_LOCK"]);
                        }
                        if (!row.IsNull("COMP_ID"))    
                        {
                        _COMP_ID = _COMP_ID_orig = Convert.ToDouble(row["COMP_ID"]);
                        }
                        if (!row.IsNull("LOCATIONID"))       
                        {
                        _LOCATIONID = _LOCATIONID_orig = row["LOCATIONID"].ToString();
                        }
                        if (!row.IsNull("COMPANY"))       
                        {
                        _COMPANY = _COMPANY_orig = CTPA.Common.Validator.capitalizeAllWords(row["COMPANY"].ToString());
                        }
                        if (!row.IsNull("zzz_OWNEROP"))      
                        {
                        _zzz_OWNEROP = _zzz_OWNEROP_orig = row["zzz_OWNEROP"].ToString();
                        } 
                        if (!row.IsNull("ORIGAMT"))       
                        {
                        _ORIGAMT = _ORIGAMT_orig = Convert.ToDouble(row["ORIGAMT"]);
                        }
                        if (!row.IsNull("AMT_PAID"))      
                        {
                        _AMT_PAID = _AMT_PAID_orig = Convert.ToDouble(row["AMT_PAID"]);
                        }
                        if (!row.IsNull("DRIVERS"))    
                        {
                        _DRIVERS = _DRIVERS_orig = Convert.ToDouble(row["DRIVERS"]);
                        }
                        if (!row.IsNull("NAME"))  
                        {
                        _NAME = _NAME_orig = CTPA.Common.Validator.capitalizeAllWords(row["NAME"].ToString());
                        }
                        if (!row.IsNull("ADDRESS1"))         
                        {
                        _ADDRESS1 = _ADDRESS1_orig = CTPA.Common.Validator.ValidateAddress(row["ADDRESS1"].ToString());
                        }
                        if (!row.IsNull("ADDRESS2"))         
                        {
                        _ADDRESS2 = _ADDRESS2_orig = CTPA.Common.Validator.ValidateAddress(row["ADDRESS2"].ToString());
                        }
                        if (!row.IsNull("CITY"))            
                        {
                        _CITY = _CITY_orig = CTPA.Common.Validator.ValidateCity(row["CITY"].ToString());
                        }
                        if (!row.IsNull("STATE"))
                        {
                        _STATE = _STATE_orig = CTPA.Common.Validator.ValidateState(row["STATE"].ToString());
                        }
                        if (!row.IsNull("ZIP"))            
                        {
                        _ZIP = _ZIP_orig = CTPA.Common.Validator.ValidateZIP(row["ZIP"].ToString());
                        }
                        if (!row.IsNull("CITY2"))           
                        {
                        _CITY2 = _CITY2_orig = CTPA.Common.Validator.ValidateCity(row["CITY2"].ToString());
                        }
                        if (!row.IsNull("STATE2"))           
                        {
                        _STATE2 = _STATE2_orig = CTPA.Common.Validator.ValidateState(row["STATE2"].ToString());
                        }
                        if (!row.IsNull("ZIP2"))          
                        {
                        _ZIP2 = _ZIP2_orig = CTPA.Common.Validator.ValidateZIP(row["ZIP2"].ToString());
                        }
                        if (!row.IsNull("CERT_SENT"))           
                        {
                        _CERT_SENT = _CERT_SENT_orig = row["CERT_SENT"].ToString();
                        }
                        if (!row.IsNull("CERT_SENT1"))          
                        {
                        _CERT_SENT1 = _CERT_SENT1_orig = row["CERT_SENT1"].ToString();
                        }
                        if (!row.IsNull("UPS"))           
                        {
                        _UPS = _UPS_orig = row["UPS"].ToString();
                        }
                        if (!row.IsNull("CLASS"))           
                        {
                        _CLASS = _CLASS_orig = row["CLASS"].ToString();
                        }
                        if (!row.IsNull("ZZZ_CPUC"))        
                        {
                        _ZZZ_CPUC = _ZZZ_CPUC_orig = Convert.ToDouble(row["ZZZ_CPUC"]);
                        }
                        if (!row.IsNull("LicID"))  
                        {
                        _LicID = _LicID_orig = row["LicID"].ToString();
                        }
                        if (!row.IsNull("LicType"))          
                        {
                        _LicType = _LicType_orig = Convert.ToInt16(row["LicType"]);
                        }
                        if (!row.IsNull("ZZZ_ICC"))          
                        {
                        _ZZZ_ICC = _ZZZ_ICC_orig = row["ZZZ_ICC"].ToString();
                        }
                        if (!row.IsNull("HOMEPHONE"))         
                        {
                        _HOMEPHONE = _HOMEPHONE_orig = CTPA.Common.Validator.ValidatePhone(row["HOMEPHONE"].ToString());
                        }
                        if (!row.IsNull("WORKPHONE"))        
                        {
                        _WORKPHONE = _WORKPHONE_orig = CTPA.Common.Validator.ValidatePhone(row["WORKPHONE"].ToString());
                        }
                        if (!row.IsNull("EMERPHONE"))          
                        {
                        _EMERPHONE = _EMERPHONE_orig = CTPA.Common.Validator.ValidatePhone(row["EMERPHONE"].ToString());
                        }
                        if (!row.IsNull("FAX"))         
                        {
                        _FAX = _FAX_orig = CTPA.Common.Validator.ValidatePhone(row["FAX"].ToString());
                        }
                        if (!row.IsNull("CONTACT"))          
                        {
                        _CONTACT = _CONTACT_orig = CTPA.Common.Validator.capitalizeAllWords(row["CONTACT"].ToString());
                        }
                        if (!row.IsNull("STATUSFLAG"))            
                        {
                        _STATUSFLAG = _STATUSFLAG_orig = row["STATUSFLAG"].ToString();
                        }
                        if (!row.IsNull("LC_REQUEST"))         
                        {
                        _LC_REQUEST = _LC_REQUEST_orig = row["LC_REQUEST"].ToString();
                        }
                        if (!row.IsNull("LC_SETUP"))          
                        {
                        _LC_SETUP = _LC_SETUP_orig = row["LC_SETUP"].ToString();
                        }
                        if (!row.IsNull("BILLTYPE"))         
                        {
                        _BILLTYPE = _BILLTYPE_orig = row["BILLTYPE"].ToString();
                        }
                        if (!row.IsNull("STMT_NUM"))           
                        {
                        _STMT_NUM = _STMT_NUM_orig = Convert.ToDouble(row["STMT_NUM"]);
                        }
                        if (!row.IsNull("ACTIVE"))            
                        {
                        _ACTIVE = _ACTIVE_orig = row["ACTIVE"].ToString();
                        }
                        if (!row.IsNull("INACTIVE"))        
                        {
                        _INACTIVE = _INACTIVE_orig = row["INACTIVE"].ToString();
                        }
                        if (!row.IsNull("COC_FORMS"))            
                        {
                        _COC_FORMS = _COC_FORMS_orig = Convert.ToDouble(row["COC_FORMS"]);
                        }
                        if (!row.IsNull("COUNTY"))           
                        {
                        _COUNTY = _COUNTY_orig = row["COUNTY"].ToString();
                        }
                        if (!row.IsNull("ACTIVEDR"))            
                        {
                        _ACTIVEDR = _ACTIVEDR_orig = Convert.ToDouble(row["ACTIVEDR"]);
                        }
                        if (!row.IsNull("INACTIVEDR"))          
                        {
                        _INACTIVEDR = _INACTIVEDR_orig = Convert.ToDouble(row["INACTIVEDR"]);
                        }
                        if (!row.IsNull("OPENDRIVER"))       
                        {
                        _OPENDRIVER = _OPENDRIVER_orig = Convert.ToDouble(row["OPENDRIVER"]);
                        }
                        if (!row.IsNull("DELETEDDR"))  
                        {
                        _DELETEDDR = _DELETEDDR_orig = Convert.ToDouble(row["DELETEDDR"]);
                        }
                        if (!row.IsNull("CELLPHONE"))       
                        {
                        _CELLPHONE = _CELLPHONE_orig = CTPA.Common.Validator.ValidatePhone(row["CELLPHONE"].ToString());
                        }
                        if (!row.IsNull("PAGERPHONE"))          
                        {
                        _PAGERPHONE = _PAGERPHONE_orig = CTPA.Common.Validator.ValidatePhone(row["PAGERPHONE"].ToString());
                        }
                        if (!row.IsNull("LNAME"))
                        {
                            _LNAME = _LNAME_orig = row["LNAME"].ToString();
                        }
                        if (!row.IsNull("OTHER"))         
                        {
                        _OTHER = _OTHER_orig = row["OTHER"].ToString();
                        }
                        if (!row.IsNull("TOTAL_SLOTS"))          
                        {
                        _TOTAL_SLOTS = _TOTAL_SLOTS_orig = (int)row["TOTAL_SLOTS"];
                        }
                        if (!row.IsNull("LABID"))         
                        {
                  _LABID = _LABID_orig = (int)(row["LABID"]);
                        }
                        if (!row.IsNull("REPLACEPOINTS"))
                        {
                            _REPLACEPOINTS = _REPLACEPOINTS_orig = (int)row["REPLACEPOINTS"];
                        }
                        if (!row.IsNull("MEMBERYEAR"))        
                        {
                        _MEMBERYEAR = _MEMBERYEAR_orig = row["MEMBERYEAR"].ToString();
                        }
                        if (!row.IsNull("RENEWDATE"))       
                        {
                        _RENEWDATE = _RENEWDATE_orig = row["RENEWDATE"].ToString();
                        }
                        if (!row.IsNull("RESERVESLOTS"))           
                        {             
                            _RESERVESLOTS = _RESERVESLOTS_orig = Convert.ToInt16(row["RESERVESLOTS"]);
                        }
                        if (!row.IsNull("STOPRENEWAL"))        
                        {
                        _STOPRENEWAL = _STOPRENEWAL_orig = Convert.ToBoolean(row["STOPRENEWAL"]);
                        }
                        if (!row.IsNull("tag_labsetup"))           
                        {
                        _tag_labsetup = _tag_labsetup_orig = Convert.ToBoolean(row["tag_labsetup"]);
                        }
                        if (!row.IsNull("RNDGRPID_CD"))         
                        {
                        _RNDGRPID_CD = _RNDGRPID_CD_orig = (int)row["RNDGRPID_CD"];
                        }
                        if (!row.IsNull("RNDGRPID_OO"))            
                        {
                        _RNDGRPID_OO = _RNDGRPID_OO_orig = (int)row["RNDGRPID_OO"];
                        }
                        if (!row.IsNull("RNDGRPID_DF"))            
                        {
                        _RNDGRPID_DF = _RNDGRPID_DF_orig = (int)row["RNDGRPID_DF"];
                        }
                        if (!row.IsNull("RNDGRPID_PUC"))           
                        {
                        _RNDGRPID_PUC = _RNDGRPID_PUC_orig = (int)row["RNDGRPID_PUC"];
                        }
                        if (!row.IsNull("OLD_PHARMCHEMID"))     
                        {
                        _OLD_PHARMCHEMID = _OLD_PHARMCHEMID_orig = row["OLD_PHARMCHEMID"].ToString();
                        }
                        if (!row.IsNull("OLD_DRUGFREEID"))           
                        {
                        _OLD_DRUGFREEID = _OLD_DRUGFREEID_orig = row["OLD_DRUGFREEID"].ToString();
                        }
                        if (!row.IsNull("OLD_LABCORPID"))           
                        {
                        _OLD_LABCORPID = _OLD_LABCORPID_orig = row["OLD_LABCORPID"].ToString();
                        }
                        if (!row.IsNull("SUPERNAME"))           
                        {
                        _SUPERNAME = _SUPERNAME_orig = row["SUPERNAME"].ToString();
                        }
                        if (!row.IsNull("TAGstr"))        
                        {
                        _TAGstr = _TAGstr_orig = row["TAGstr"].ToString();
                        }
                        if (!row.IsNull("LANGUAGEHELPID"))         
                        {
                        _LANGUAGEHELPID = _LANGUAGEHELPID_orig = (int)row["LANGUAGEHELPID"];
                        }
                        if (!row.IsNull("SERVREPID"))         
                        {
                        _SERVREPID = _SERVREPID_orig = (int)row["SERVREPID"];
                        }
                        if (!row.IsNull("LABRESPONSEID"))        
                        {
                        _LABRESPONSEID = _LABRESPONSEID_orig = (int)row["LABRESPONSEID"];
                        }
                        if (!row.IsNull("old2_LABCORP_ID"))   
                        {
                        _old2_LABCORP_ID = _old2_LABCORP_ID_orig = row["old2_LABCORP_ID"].ToString();
                        }
                        if (!row.IsNull("old2_DRUGFREEID"))           
                        {
                        _old2_DRUGFREEID = _old2_DRUGFREEID_orig = row["old2_DRUGFREEID"].ToString();
                        }
                        if (!row.IsNull("FORMCERTTYPE"))       
                        {
                        _FORMCERTTYPE = _FORMCERTTYPE_orig = row["FORMCERTTYPE"].ToString();
                        }
                        if (!row.IsNull("FORMSATYPE"))         
                        {
                        _FORMSATYPE = _FORMSATYPE_orig = row["FORMSATYPE"].ToString();
                        }
                        if (!row.IsNull("stats_recurbalance"))          
                        {
                        _stats_recurbalance = _stats_recurbalance_orig = (float) Convert.ToDouble(row["stats_recurbalance"]);
                        }
                        if (!row.IsNull("stats_cnt_oo"))     
                        {
                        _stats_cnt_oo = _stats_cnt_oo_orig = (int)row["stats_cnt_oo"];
                        }
                        if (!row.IsNull("stats_cnt_cd"))           
                        {
                        _stats_cnt_cd = _stats_cnt_cd_orig = (int)row["stats_cnt_cd"];
                        }
                        if (!row.IsNull("stats_cnt_df"))         
                        {
                        _stats_cnt_df = _stats_cnt_df_orig = (int)row["stats_cnt_df"];
                        }
                        if (!row.IsNull("stats_cnt_puc")) 
                        {
                        _stats_cnt_puc = _stats_cnt_puc_orig = (int)row["stats_cnt_puc"];
                        }
                        if (!row.IsNull("stats_cnt_actives"))           
                        {
                        _stats_cnt_actives = _stats_cnt_actives_orig = (int)row["stats_cnt_actives"];
                        }
                        if (!row.IsNull("stats_cnt_opens"))     
                        {
                        _stats_cnt_opens = _stats_cnt_opens_orig = (int)row["stats_cnt_opens"];
                        }
                        if (!row.IsNull("stats_cnt_enroll"))         
                        {
                        _stats_cnt_enroll = _stats_cnt_enroll_orig = (int)row["stats_cnt_enroll"];
                        }
                        if (!row.IsNull("stats_cnt_y2dDROPs"))          
                        {
                        _stats_cnt_y2dDROPs = _stats_cnt_y2dDROPs_orig = (int)row["stats_cnt_y2dDROPs"];
                        }
                        if (!row.IsNull("stats_cnt_y2dADDs"))    
                        {
                        _stats_cnt_y2dADDs = _stats_cnt_y2dADDs_orig = (int)row["stats_cnt_y2dADDs"];
                        }
                        if (!row.IsNull("stats_cnt_lastupdate"))      
                        {
                        _stats_cnt_lastupdate = _stats_cnt_lastupdate_orig = row["stats_cnt_lastupdate"].ToString();
                        }       
                       if (!row.IsNull("AFFCODE"))      
                       {
                        _AFFCODE = _AFFCODE_orig = row["AFFCODE"].ToString();
                       }
                       if (!row.IsNull("CLASS_OLDREF"))       
                        {
                        _CLASS_OLDREF = _CLASS_OLDREF_orig = row["CLASS_OLDREF"].ToString();
                        }
                        if (!row.IsNull("DEACTIVATEID"))      
                        {
                        _DEACTIVATEID = _DEACTIVATEID_orig = (int)row["DEACTIVATEID"];
                        }
                        if (!row.IsNull("FORCENONEEDSUPERVISOR"))
                        {
                            _FORCENONEEDSUPERVISOR = _FORCENONEEDSUPERVISOR_orig = Convert.ToBoolean(row["FORCENONEEDSUPERVISOR"]);
                        }
                        if (!row.IsNull("WEB_LOGIN_PASS"))
                        {
                        _WEB_LOGIN_PASS = _WEB_LOGIN_PASS_orig = row["WEB_LOGIN_PASS"].ToString();
                        }
                    
                }
            }
            catch (Exception ex)
            {
                throw (new Exception("Unable to load Company from database", ex));
            }
        }

        /// <summary>
        /// Get the company record from the database
        /// </summary>
        /// <returns>A datarow containing the company record</returns>
        private DataRow GetCompany()
        {
            SqlParameter[] prams = new SqlParameter[1];
            prams[0] = new SqlParameter("@COMP_ID", SqlDbType.Int);
            prams[0].Value = _COMP_ID;
            return (SqlHelper.ExecuteDataset(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.Company_Select", prams).Tables[0].Rows[0]);

        }
        
        /// <summary>
        /// Convert an object to an SQL formatted string
        /// </summary>
        /// <param name="Field">The object to convert</param>
        /// <returns>The string use in SQL</returns>
        private string convertToSQL(object Field)
        {
            string returnVal;
            if (Field == null)
            {
                returnVal = "NULL";
            }
            else
            {
                char[] dot = new char[1];
                dot[0] = '.';
                switch (Field.GetType().ToString().Split(dot)[1])
                {
                    case "Integer":
                    case "Float":
                    case "Double":
                    case "Int32":
                    case "Long":
                    case "Short":
                    case "boolean":
                    case "Int16":
                        returnVal = Field.ToString();
                        break;
                    case "String":
                    case "Date":
                        returnVal = "'" + Field.ToString() + "'";
                        break;
                    default:
                        returnVal = "REPORT ERROR: Unhandled field type in COMPANY.CS" + Field.GetType().ToString();
                        break;
                }
            }
            return returnVal;
        }

        /// <summary>
        /// Determine the number of drivers from the company in the testing pool with the specified ID number
        /// </summary>
        /// <param name="PoolID">The pool ID to check</param>
        /// <returns>The number of drivers from this company in the pool with the specified ID</returns>
        public int getPoolCount(int PoolID)
        {
            SqlParameter[] prams = new SqlParameter[2];
            DataSet ds;
            DataRow dr;
            prams[0] = new SqlParameter("@COMP_ID", SqlDbType.Real);
            prams[0].Value = _COMP_ID;
            prams[1] = new SqlParameter("@POOLID", SqlDbType.Int);
            prams[1].Value = PoolID;
            ds = SqlHelper.ExecuteDataset(Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.DRIVERUP_primary_getcount_By_CompID_And_PoolID", prams);
            try
            {
                dr = (ds.Tables[0].Rows[0]);
            }
            catch (Exception ex)
            {
                return 0;
            }
            
            return (Convert.ToInt16(dr["COUNTACTIVES"]));
        }

        /// <summary>
        /// Checks whether a company has any pending web site changes
        /// </summary>
        /// <param name="CompanyID">The company ID to check for pending changes</param>
        /// <returns>0 indicates changes, 1 or greater indicates that changes are pending</returns>
        public static int checkPendingChange(double CompanyID)
        {
            return WSUpdate.isPending(CompanyID.ToString(), "Company");
        }
        #endregion
    }
}