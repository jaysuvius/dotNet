﻿Public Partial Class UserRoles
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            If Roles.IsUserInRole("SuperaUser") Then
            Else
                Try
                    If Not Roles.RoleExists("SuperUser") Then
                        Roles.CreateRole("SuperUser")
                    End If
                    If Not Roles.IsUserInRole("Administrator", "SuperUser") Then
                        Roles.AddUserToRole("Administrator", "SuperUser")
                    End If
                Catch ex As Exception
                    If Membership.GetUser().UserName <> "Administrator" Then
                    Else
                        Throw New Exception("Could not put administrator into necessary roles", ex)
                    End If
                End Try
                'Response.Redirect("~/Login.aspx")
            End If
            loadUsersAndRoles()
        End If
    End Sub

    Private Sub loadUsersAndRoles()
        Dim muc As System.Web.Security.MembershipUserCollection = Membership.GetAllUsers()
        Dim iter As System.Collections.IEnumerator = muc.GetEnumerator()
        iter.Reset()
        While iter.MoveNext()
            Dim username As String = CType(iter.Current, MembershipUser).UserName
            ListBox1.Items.Add(CType(iter.Current, MembershipUser).UserName)
        End While
        For Each role As String In Roles.GetAllRoles()
            ListBox2.Items.Add(role)
        Next
        ListBox1.SelectedIndex = 0
        ListBox2.SelectedIndex = 0
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim username As String
        username = ListBox1.SelectedItem.Text
        If Not Roles.IsUserInRole(username, ListBox2.SelectedItem.Text) Then
            Roles.AddUserToRole(username, ListBox2.Items(ListBox2.SelectedIndex).Text)
            Label1.Text = "User " & ListBox1.Items(ListBox1.SelectedIndex).Text & " added to role " & ListBox2.Items(ListBox2.SelectedIndex).Text
        Else
            Label1.Text = "User " & ListBox1.Items(ListBox1.SelectedIndex).Text & " already in role " & ListBox2.Items(ListBox2.SelectedIndex).Text
        End If
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim username As String
        username = ListBox1.SelectedItem.Text
        If Roles.IsUserInRole(username, ListBox2.SelectedItem.Text) Then
            Roles.RemoveUserFromRole(username, ListBox2.Items(ListBox2.SelectedIndex).Text)
            Label1.Text = "User " & ListBox1.Items(ListBox1.SelectedIndex).Text & " removed from role " & ListBox2.Items(ListBox2.SelectedIndex).Text
        Else
            Label1.Text = "User " & ListBox1.Items(ListBox1.SelectedIndex).Text & " not yet in role " & ListBox2.Items(ListBox2.SelectedIndex).Text & ", cannot remove"
        End If
    End Sub
End Class