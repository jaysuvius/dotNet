﻿Partial Public Class ManageUsers
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Me.LookupDQFUserID.Visible = False
            GridView1.DataBind()
        End If
    End Sub

    Public Sub GetUser(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName = "GetUser" Then
            Me.UserDataPanel.Visible = True
            Me.UserGridPanel.Visible = False
            Dim u As MembershipUserCollection
            u = Membership.FindUsersByName(GridView1.Rows(e.CommandArgument).Cells(1).Text)
            If u.Count = 1 Then
                Dim us As MembershipUser
                us = u(GridView1.Rows(e.CommandArgument).Cells(1).Text)
                UserNameTextBox.Text = us.UserName
                EmailAddressTextBox.Text = us.Email
                CommentTextBox.Text = us.Comment
                ApprovedCheckBox.Checked = us.IsApproved
                Dim WSUsersToCompaniesTableAdapter As New UserDataTableAdapters.WSUsersToCompaniesTableAdapter
                Dim dt As DataTable = WSUsersToCompaniesTableAdapter.GetDataByWSUName(us.UserName)
                Dim dr As DataRow
                If dt.Rows.Count > 0 Then
                    dr = dt.Rows(0)
                    CompanyIDTextBox.Text = dr("DQFCompanyID")
                    UserIDTextBox.Text = dr("DQFUserID")
                End If
            End If
        End If
    End Sub

    Private Sub LookupUserButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LookupUserButton.Click
        DQFUserGridview.DataSourceID = "ObjectDataSource1"
        DQFUserGridview.DataBind()
        Me.LookupDQFUserID.Visible = True
    End Sub

    Private Sub FilterButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FilterButton1.Click
       

    End Sub

    Private Sub DQFUserGridview_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles DQFUserGridview.PageIndexChanging
        DQFUserGridview.PageIndex = e.NewPageIndex
        DQFUserGridview.DataSource = ViewState("DQFGridView_Datasource")
        DQFUserGridview.DataBind()
    End Sub

    Private Sub DQFUserGridview_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles DQFUserGridview.Sorting
        Dim dt As DataTable = ViewState("DQFGridView_Datasource")

        If dt IsNot Nothing Then
            Dim dv As New DataView(dt)
            dv.Sort = e.SortExpression & " " & ConvertSortDirectionToSQL(e.SortDirection)
            DQFUserGridview.DataSource = dv
            DQFUserGridview.DataBind()
        End If
    End Sub

    Private Function ConvertSortDirectionToSQL(ByVal sd As SortDirection) As String
        Dim NewSortDirection As String = String.Empty
        Select Case sd
            Case SortDirection.Ascending
                NewSortDirection = "ASC"
                Exit Select
            Case SortDirection.Descending
                NewSortDirection = "DESC"
                Exit Select
        End Select
        Return NewSortDirection
    End Function

    Public Sub GetUserAndCorpID(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName = "SelectUser" Then
            Me.UserIDTextBox.Text = DQFUserGridview.Rows(e.CommandArgument).Cells(1).Text
            Me.CompanyIDTextBox.Text = DQFUserGridview.Rows(e.CommandArgument).Cells(7).Text
            Me.LookupDQFUserID.Visible = False
        End If
    End Sub

    Private Sub LookupCompanyButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LookupCompanyButton.Click
        Me.LookupDQFUserID.Visible = True
    End Sub


    Private Sub SaveButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveButton.Click
        Dim u As MembershipUserCollection
        u = Membership.FindUsersByName(UserNameTextBox.Text)
        If u.Count = 1 Then
            Dim us As MembershipUser
            us = u(UserNameTextBox.Text)
            us.Email = EmailAddressTextBox.Text
            us.Comment = CommentTextBox.Text
            us.IsApproved = ApprovedCheckBox.Checked
            Membership.UpdateUser(us)
            Dim WSUsersToCompaniesTableAdapter As New UserDataTableAdapters.WSUsersToCompaniesTableAdapter
            Dim dt As DataTable = WSUsersToCompaniesTableAdapter.GetDataByWSUName(us.UserName)
            Dim dr As DataRow
            If dt.Rows.Count > 0 Then
                dr = dt.Rows(0)
                dr("DQFCompanyID") = CompanyIDTextBox.Text
                dr("DQFUserID") = UserIDTextBox.Text
                WSUsersToCompaniesTableAdapter.Update(dt)
            Else
                WSUsersToCompaniesTableAdapter.Insert(Guid.NewGuid, us.UserName, CompanyIDTextBox.Text, UserIDTextBox.Text)
            End If
        End If
        Me.UserDataPanel.Visible = False
        Me.UserGridPanel.Visible = True
        Me.LookupDQFUserID.Visible = False
    End Sub

    Private Sub CancelButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancelButton.Click
        Me.UserDataPanel.Visible = False
        Me.UserGridPanel.Visible = True
        Me.LookupDQFUserID.Visible = False
    End Sub

    Private Sub DeleteButon_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles DeleteButon.Click
        Dim rtnval As Integer
        rtnval = MsgBox("Are you sure you wish to delete this user?", vbYesNo, "Delete?")
        If rtnval = vbYes Then
            Membership.DeleteUser(UserNameTextBox.Text)
        End If
    End Sub

    Private Sub ApplyASPFilterButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ApplyASPFilterButton.Click
        Dim LoginFilter As Object = Nothing
        Dim LastNameFilter As Object = Nothing
        Dim FirstNameFilter As Object = Nothing
        Dim CorpNameFilter As Object = Nothing
        Dim NoFilter As Boolean = True

        If ASPLoginFilterTextBox.Text.Length > 0 Then
            LoginFilter = Me.ASPLoginFilterTextBox.Text
            NoFilter = False

        End If
        If ASPLastNameFilterTextBox.Text.Length > 0 Then
            LastNameFilter = Me.ASPLastNameFilterTextBox.Text
            NoFilter = False

        End If
        If ASPFirstNameFilterTextBox.Text.Length > 0 Then
            FirstNameFilter = Me.ASPFirstNameFilterTextBox.Text
            NoFilter = False

        End If
        If ASPCorpFilterTextBox.Text.Length > 0 Then
            CorpNameFilter = ASPCorpFilterTextBox.Text
            NoFilter = False
        End If


        If NoFilter Then
            GridView1.DataSourceID = "ObjectDataSource2"
            DQFUserGridview.DataBind()
        Else
            Dim UserTableAdapter As New UserDataTableAdapters.MembershipUsersTableAdapter
            GridView1.DataSourceID = ""
            GridView1.DataSource = UserTableAdapter.GetDataByFilters(LoginFilter, FirstNameFilter, LastNameFilter, CorpNameFilter)
            GridView1.DataBind()
        End If

        ViewState("DQFGridView_Datasource2") = DQFUserGridview.DataSource
    End Sub

    Private Sub FilterButton_Click1(ByVal sender As Object, ByVal e As System.EventArgs) Handles FilterButton.Click
        Dim UserIDFilter As Object = Nothing
        Dim LoginFilter As Object = Nothing
        Dim LastNameFilter As Object = Nothing
        Dim FirstNameFilter As Object = Nothing
        Dim CorpNameFilter As Object = Nothing
        Dim NoFilter As Boolean = True

        If UserIDFilterTextBox.Text.Length > 0 Then
            UserIDFilter = CInt(Me.UserIDFilterTextBox.Text)
            NoFilter = False
        End If
        If LoginFilterTextBox.Text.Length > 0 Then
            LoginFilter = Me.LoginFilterTextBox.Text
            NoFilter = False

        End If
        If LastNameFilterTextBox.Text.Length > 0 Then
            LastNameFilter = Me.LastNameFilterTextBox.Text
            NoFilter = False

        End If
        If FirstNameFilterTextBox.Text.Length > 0 Then
            FirstNameFilter = Me.FirstNameFilterTextBox.Text
            NoFilter = False

        End If
        If CorpFilterTextBox.Text.Length > 0 Then
            CorpNameFilter = CorpFilterTextBox.Text
            NoFilter = False

        End If


        If NoFilter Then
            DQFUserGridview.DataSourceID = "ObjectDataSource1"
            DQFUserGridview.DataBind()
        Else
            Dim UserTableAdapter As New UserDataTableAdapters.DQFUsersTableAdapter
            DQFUserGridview.DataSourceID = ""
            DQFUserGridview.DataSource = UserTableAdapter.GetDataByFilters(UserIDFilter, LoginFilter, LastNameFilter, FirstNameFilter, CorpNameFilter)
            DQFUserGridview.DataBind()
        End If

        ViewState("DQFGridView_Datasource") = DQFUserGridview.DataSource
    End Sub
End Class