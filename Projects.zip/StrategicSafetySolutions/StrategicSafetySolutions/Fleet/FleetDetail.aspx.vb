﻿Public Partial Class FleetDetail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            PopulateDropDowns()
            If Not Session("IsNewFleet") Then
                PopulateForm()
            Else
                Dim TruckIDAdapter As New TruckFleetTableAdapters.FleetDetailTableAdapter
                Session("TruckID") = TruckIDAdapter.NextTruckID
            End If
        End If
    End Sub

    Private Sub PopulateDropDowns()
        Dim StatePickListAdapter As New TruckFleetTableAdapters.StatePickListTableAdapter

        Me.RegStateDropDownList.DataSource = StatePickListAdapter.GetData
        Me.RegStateDropDownList.DataBind()

    End Sub

    Private Sub PopulateForm()
        Dim FleetDetailTableAdapter As New TruckFleetTableAdapters.FleetDetailTableAdapter
        Dim FleetDetailTable As New TruckFleet.FleetDetailDataTable

        Dim TruckID As Integer = CInt(Session("TruckID"))

        FleetDetailTableAdapter.FillByTruckID(FleetDetailTable, TruckID)

        'Try
        If FleetDetailTable.Rows.Count > 0 Then

            Dim dr As DataRow

            dr = FleetDetailTable.Rows(0)

            Me.VinTextBox.Text = dr("Vin").ToString
            Me.UnitNumberTextBox.Text = dr("UnitNumber").ToString
            If IsDate(dr("DF_TFI_REG_EXPDATE")) Then
                Me.RegExpirationDateTextBox.Text = String.Format("{0:d}", CDate(dr("DF_TFI_REG_EXPDATE")))
            End If
            If IsDate(dr("DF_TFI_EVAL_DATE")) Then
                Me.LastEvalDateTextBox.Text = String.Format("{0:d}", CDate(dr("DF_TFI_EVAL_DATE")))
            End If
            Me.VehicleValueTextBox.Text = dr("VehicleValue").ToString
            Me.PlateNumberTextBox.Text = dr("PlateNumber").ToString
            Me.MakeTextBox.Text = dr("Make").ToString
            Me.ModelTextBox.Text = dr("Model").ToString
            Me.ColorTextBox.Text = dr("Color").ToString
            Me.TruckYearTextBox.Text = dr("TruckYear").ToString
            Me.UnladenWeightTextBox.Text = dr("UnladenWeight").ToString
            Me.GrossWeightTextBox.Text = dr("GrossWeight").ToString
            Me.AxlesTextBox.Text = dr("Axles").ToString
            Me.InsuranceNameTextBox.Text = dr("InsuranceCompanyName").ToString
            Me.InsurancePolicyNumberTextBox.Text = dr("InsurancePolicyNumber").ToString
            Me.InsuranceLimitTextBox.Text = dr("InsuranceLimit").ToString
            If IsDate(dr("InsuranceExpirationDate")) Then
                Me.InsuranceExpirationTextBox.Text = String.Format("{0:d}", CDate(dr("InsuranceExpirationDate")))
            End If
            Select Case dr("TruckOwner")
                Case "1"
                    Me.TruckOwnerRadioButtonList.SelectedValue = "1"
                Case "2"
                    Me.TruckOwnerRadioButtonList.SelectedValue = "2"
                Case "3"
                    Me.TruckOwnerRadioButtonList.SelectedValue = "3"
            End Select

            VTypeDropDownList.SelectedValue = dr("TruckType").ToString

            Me.RegStateDropDownList.SelectedValue = dr("RegistrationState").ToString

            Dim VendorTableAdapter As New TruckFleetTableAdapters.FleetVendorTableAdapter
            Dim VendorTable As New TruckFleet.FleetVendorDataTable

            VendorTableAdapter.FillByTruckID(VendorTable, TruckID)

            If VendorTable.Rows.Count > 0 Then

                Dim dr2 As DataRow
                dr2 = VendorTable.Rows(0)

                Session("VendorID") = dr2("DF_TVI_ID").ToString
                Me.VendorCodeTextBox.Text = dr2("DF_TVI_VENDORCODE").ToString
                Me.VendorInfoOOAddressTextBox.Text = dr2("DF_TVI_COMPANYADDRESS").ToString
                Me.VendorCityTextBox.Text = dr2("DF_TVI_CITY").ToString
                Me.VendorZipTextBox.Text = dr2("DF_TVI_ZIP").ToString
                Me.VendorInfoOOPhoneTextBox.Text = dr2("DF_TVI_PHONE").ToString
                Me.VendorInfoOOTextBox.Text = dr2("DF_TVI_COMPANYNAME").ToString
                Me.FederID1TextBox.Text = dr2("DF_TVI_FEDERALID").ToString
                Me.VendorSSNTextBox.Text = dr2("DF_TVI_SSN").ToString

                VendorInfoOORadioButtonList.SelectedValue = dr2("DF_TVI_TYPE").ToString

            End If

            BindGridViews(TruckID)

        Else
            Me.TruckFleetErrorLabel.Text = "No truck found"
            Me.TruckFleetErrorLabel.Visible = True
        End If

        'Catch ex As Exception
        'Me.TruckFleetErrorLabel.Text = ex.ToString
        'Me.TruckFleetErrorLabel.Visible = True
        'End Try

    End Sub

    Private Sub BindGridViews(ByVal truckID As Integer)
        FillInspectionGrid(truckID)
        BindDriverGridView(truckID)
    End Sub


    '**************************************************************************************
    '*Inspection Gridview Methods
    '**************************************************************************************

    Private Sub FillInspectionGrid(ByVal truckID As Integer)
        Dim InspectionTableAdapter As New TruckFleetTableAdapters.FleetInspectionTableAdapter


        Dim dt As New DataTable
        dt = InspectionTableAdapter.GetDataByTruckID(truckID)

        If dt.Rows.Count > 0 Then
            InspectionInfoGridView.DataSource = dt
            InspectionInfoGridView.DataBind()
            Session("ITable") = InspectionInfoGridView.DataSource
        Else
            Dim emptyDT As New DataTable
            Dim col1 As DataColumn = New DataColumn("InspectionDate")
            Dim col2 As DataColumn = New DataColumn("InspectorCompany")
            Dim col3 As DataColumn = New DataColumn("InspectorName")
            Dim col4 As DataColumn = New DataColumn("InspectorNumber")
            Dim col5 As DataColumn = New DataColumn("InspectionFormNumber")
            Dim col6 As DataColumn = New DataColumn("ExpirationDate")
            Dim col7 As DataColumn = New DataColumn("InspectionDate1")
            Dim col8 As DataColumn = New DataColumn("InspectionShopNotes")
            Dim col9 As DataColumn = New DataColumn("InspectionResult")

            emptyDT.Columns.Add(col1)
            emptyDT.Columns.Add(col2)
            emptyDT.Columns.Add(col3)
            emptyDT.Columns.Add(col4)
            emptyDT.Columns.Add(col5)
            emptyDT.Columns.Add(col6)
            emptyDT.Columns.Add(col7)
            emptyDT.Columns.Add(col8)
            emptyDT.Columns.Add(col9)

            Dim row As DataRow = emptyDT.NewRow
            row.Item("InspectionDate") = DateTime.Today
            row.Item("InspectorCompany") = ""
            row.Item("InspectorName") = ""
            row.Item("InspectorNumber") = ""
            row.Item("InspectionFormNumber") = ""
            row.Item("InspectionDate1") = ""
            row.Item("ExpirationDate") = ""
            row.Item("InspectionShopNotes") = ""
            row.Item("InspectionResult") = ""
            emptyDT.Rows.Add(row)

            InspectionInfoGridView.DataSource = emptyDT
            InspectionInfoGridView.DataBind()

            Dim TotalColumns As Integer = InspectionInfoGridView.Rows(0).Cells.Count
            InspectionInfoGridView.Rows(0).Cells.Clear()
            InspectionInfoGridView.Rows(0).Cells.Add(New TableCell())
            InspectionInfoGridView.Rows(0).Cells(0).ColumnSpan = TotalColumns
            InspectionInfoGridView.Rows(0).Cells(0).Text = "No Record Found"
        End If

        InspectionInfoGridView.ShowFooter = True

    End Sub

    Private Sub InspectionInfoGridView_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles InspectionInfoGridView.RowDataBound
        InspectionInfoGridView.ShowFooter = True

        Dim dv As DataTable = InspectionInfoGridView.DataSource

        If e.Row.RowIndex > -1 Then
            Dim Result As String = dv.Rows(e.Row.RowIndex)("InspectionResult").ToString
            Dim ResultRadioList As RadioButtonList = CType(e.Row.FindControl("ReadOnlyResultRadioButtonList"), RadioButtonList)

            If ResultRadioList IsNot Nothing Then
                If Result.ToUpper = "FAILED" Then
                    ResultRadioList.SelectedValue = "Failed"
                Else
                    ResultRadioList.SelectedValue = "Passed"
                End If
            End If

        End If

    End Sub

    Protected Sub InspectionGridView_RowCommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs) Handles InspectionInfoGridView.RowCommand
        Dim InspectionTableAdapter As New TruckFleetTableAdapters.FleetInspectionTableAdapter
        Dim bValid As Boolean = True
        Dim ErrorMessage As String = String.Empty

        If e.CommandName.Equals("Insert") Then
            Dim NewResultRadioButtonList As RadioButtonList = CType(InspectionInfoGridView.FooterRow.FindControl("NewResultRadioButtonList"), RadioButtonList)
            Dim NewInspectionDateTextBox As TextBox = CType(InspectionInfoGridView.FooterRow.FindControl("NewInspectionDateTextBox"), TextBox)
            Dim NewInspectionCompanyTextBox As TextBox = CType(InspectionInfoGridView.FooterRow.FindControl("NewInspectionCompanyTextBox"), TextBox)
            Dim NewInspectorNameTextBox As TextBox = CType(InspectionInfoGridView.FooterRow.FindControl("NewInspectorNameTextBox"), TextBox)
            Dim NewInspectorNumberTextBox As TextBox = CType(InspectionInfoGridView.FooterRow.FindControl("NewInspectorNumberTextBox"), TextBox)
            Dim NewInspectionFormNumberTextBox As TextBox = CType(InspectionInfoGridView.FooterRow.FindControl("NewInspectionFormNumberTextBox"), TextBox)
            Dim NewInspectionFormExpirationDate As TextBox = CType(InspectionInfoGridView.FooterRow.FindControl("NewInspectionFormExpirationDate"), TextBox)
            Dim NewBITDateTextBox As TextBox = CType(InspectionInfoGridView.FooterRow.FindControl("NewBITDateTextBox"), TextBox)
            Dim NewShopNotesTextBox As TextBox = CType(InspectionInfoGridView.FooterRow.FindControl("NewShopNotesTextBox"), TextBox)

            Dim NewInspectionDate As Object = Nothing
            Dim NewInspectionCompany As Object = Nothing
            Dim NewInspectorName As Object = Nothing
            Dim NewInspectorNumber As Object = Nothing
            Dim NewInspectionFormNumber As Object = Nothing
            Dim NewInspectionFormExpDate As Object = Nothing
            Dim NewBitDate As Object = Nothing
            Dim NewShopNotes As Object = Nothing
            Dim NewResult As Object = Nothing

            If NewInspectionDateTextBox.Text IsNot Nothing Then
                If IsDate(NewInspectionDateTextBox.Text) Then
                    NewInspectionDate = CDate(NewInspectionDateTextBox.Text)
                ElseIf NewInspectionDateTextBox.Text.Length > 0 Then
                    ErrorMessage = ErrorMessage & "New Inspection Date is not a valid date"
                    bValid = False
                End If
            End If
            If NewInspectionCompanyTextBox IsNot Nothing Then
                If NewInspectionCompanyTextBox.Text.Length > 0 Then
                    NewInspectionCompany = NewInspectionCompanyTextBox.Text
                End If
            End If
            If NewInspectorNameTextBox IsNot Nothing Then
                If NewInspectorNameTextBox.Text.Length > 0 Then
                    NewInspectorName = NewInspectorNameTextBox.Text
                End If
            End If
            If NewInspectorNumberTextBox IsNot Nothing Then
                If NewInspectorNumberTextBox.Text.Length > 0 Then
                    NewInspectorNumber = NewInspectorNumberTextBox.Text
                End If
            End If
            If NewInspectionFormNumberTextBox IsNot Nothing Then
                If NewInspectionFormNumberTextBox.Text.Length > 0 Then
                    NewInspectionFormNumber = NewInspectionFormNumberTextBox.Text
                End If
            End If
            If NewInspectionFormExpirationDate IsNot Nothing Then
                If IsDate(NewInspectionFormExpirationDate.Text) Then
                    NewInspectionFormExpDate = CDate(NewInspectionFormExpirationDate.Text)
                ElseIf NewInspectionFormExpirationDate.Text.Length > 0 Then
                    ErrorMessage = ErrorMessage & "New inspection form expiration date is not a valid date"
                    bValid = False
                End If
            End If
            If NewBITDateTextBox IsNot Nothing Then
                If IsDate(NewBITDateTextBox.Text) Then
                    NewBitDate = CDate(NewBITDateTextBox.Text)
                ElseIf NewBITDateTextBox.Text.Length > 0 Then
                    ErrorMessage = ErrorMessage & "New BIT date is not a valid date"
                    bValid = False
                End If
            End If
            If NewShopNotesTextBox IsNot Nothing Then
                If NewShopNotesTextBox.Text.Length > 0 Then
                    NewShopNotes = NewShopNotesTextBox.Text
                End If
            End If
            If NewResultRadioButtonList IsNot Nothing Then
                If NewResultRadioButtonList.SelectedValue = "Passed" Then
                    NewResult = "Passed"
                ElseIf NewResultRadioButtonList.SelectedValue = "Passed" Then
                    NewResult = "Failed"
                Else
                    NewResult = "Failed"
                End If
            End If

            If bValid Then
                Try
                    InspectionTableAdapter.Insert(CInt(Session("TruckID")), "1", NewInspectionDate, NewInspectionCompany, NewInspectorName, NewInspectorNumber, NewInspectionFormNumber, _
                                                 NewResult, NewInspectionDate, NewShopNotes, Today, "Website", "1", NewInspectionFormExpDate, 0)
                Catch ex As Exception
                    InspectionErrorLabel.Text = ex.ToString
                    InspectionErrorLabel.Visible = True
                End Try
            Else
                InspectionErrorLabel.Text = ErrorMessage
                InspectionErrorLabel.Visible = True
            End If

        End If

        If bValid Then
            BindGridViews(Session("TruckID"))
        End If
    End Sub

    Private Sub InspectionInfoGridView_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles InspectionInfoGridView.RowUpdating
        Dim InspectionTableAdapter As New TruckFleetTableAdapters.FleetInspectionTableAdapter
        Dim bValid As Boolean = True
        Dim ErrorMessage As String = String.Empty
        Dim TempTable As DataTable
        Dim InspectionID As Object = Nothing
        Dim InspectionDate As Object = Nothing
        Dim InspectionCompany As Object = Nothing
        Dim InspectorName As Object = Nothing
        Dim InspectorNumber As Object = Nothing
        Dim InspectionFormNumber As Object = Nothing
        Dim InspectionFormExpDate As Object = Nothing
        Dim BitDate As Object = Nothing
        Dim ShopNotes As Object = Nothing
        Dim Result As Object = Nothing

        Dim InspectionIDField As HiddenField = CType(InspectionInfoGridView.Rows(e.RowIndex).FindControl("InspectionID"), HiddenField)
        Dim ResultRadioButtonList As RadioButtonList = CType(InspectionInfoGridView.Rows(e.RowIndex).FindControl("ResultRadioButtonList"), RadioButtonList)
        Dim InspectionDateTextBox As TextBox = CType(InspectionInfoGridView.Rows(e.RowIndex).FindControl("InspectionDateTextBox"), TextBox)
        Dim InspectionCompanyTextBox As TextBox = CType(InspectionInfoGridView.Rows(e.RowIndex).FindControl("InspectionCompanyTextBox"), TextBox)
        Dim InspectorNameTextBox As TextBox = CType(InspectionInfoGridView.Rows(e.RowIndex).FindControl("InspectorNameTextBox"), TextBox)
        Dim InspectorNumberTextBox As TextBox = CType(InspectionInfoGridView.Rows(e.RowIndex).FindControl("InspectorNumberTextBox"), TextBox)
        Dim InspectionFormNumberTextBox As TextBox = CType(InspectionInfoGridView.Rows(e.RowIndex).FindControl("InspectionFormNumberTextBox"), TextBox)
        Dim InspectionFormExpirationDate As TextBox = CType(InspectionInfoGridView.Rows(e.RowIndex).FindControl("InspectionFormExpirationDate"), TextBox)
        Dim BITDateTextBox As TextBox = CType(InspectionInfoGridView.Rows(e.RowIndex).FindControl("BITDateTextBox"), TextBox)
        Dim ShopNotesTextBox As TextBox = CType(InspectionInfoGridView.Rows(e.RowIndex).FindControl("ShopNotesTextBox"), TextBox)


        If InspectionIDField IsNot Nothing Then
            InspectionID = InspectionIDField.Value
        End If


        If InspectionDateTextBox.Text IsNot Nothing Then
            If IsDate(InspectionDateTextBox.Text) Then
                InspectionDate = CDate(InspectionDateTextBox.Text)
            ElseIf InspectionDateTextBox.Text.Length > 0 Then
                ErrorMessage = ErrorMessage & " Inspection Date is not a valid date"
                bValid = False
            End If
        End If
        If InspectionCompanyTextBox IsNot Nothing Then
            If InspectionCompanyTextBox.Text.Length > 0 Then
                InspectionCompany = InspectionCompanyTextBox.Text
            End If
        End If
        If InspectorNameTextBox IsNot Nothing Then
            If InspectorNameTextBox.Text.Length > 0 Then
                InspectorName = InspectorNameTextBox.Text
            End If
        End If
        If InspectorNumberTextBox IsNot Nothing Then
            If InspectorNumberTextBox.Text.Length > 0 Then
                InspectorNumber = InspectorNumberTextBox.Text
            End If
        End If
        If InspectionFormNumberTextBox IsNot Nothing Then
            If InspectionFormNumberTextBox.Text.Length > 0 Then
                InspectionFormNumber = InspectionFormNumberTextBox.Text
            End If
        End If
        If InspectionFormExpirationDate IsNot Nothing Then
            If IsDate(InspectionFormExpirationDate.Text) Then
                InspectionFormExpDate = CDate(InspectionFormExpirationDate.Text)
            ElseIf InspectionFormExpirationDate.Text.Length > 0 Then
                ErrorMessage = ErrorMessage & " inspection form expiration date is not a valid date"
                bValid = False
            End If
        End If
        If BITDateTextBox IsNot Nothing Then
            If IsDate(BITDateTextBox.Text) Then
                BitDate = CDate(BITDateTextBox.Text)
            ElseIf BITDateTextBox.Text.Length > 0 Then
                ErrorMessage = ErrorMessage & " BIT date is not a valid date"
                bValid = False
            End If
        End If
        If ShopNotesTextBox IsNot Nothing Then
            If ShopNotesTextBox.Text.Length > 0 Then
                ShopNotes = ShopNotesTextBox.Text
            End If
        End If
        If ResultRadioButtonList IsNot Nothing Then
            If ResultRadioButtonList.SelectedValue = "Passed" Then
                Result = "Passed"
            ElseIf ResultRadioButtonList.SelectedValue = "Passed" Then
                Result = "Failed"
            Else
                Result = "Failed"
            End If
        End If

        If bValid Then
            Try
                InspectionTableAdapter.Update(CInt(Session("TruckID")), "1", InspectionDate, InspectionCompany, InspectorName, InspectorNumber, InspectionFormNumber, _
                                             Result, InspectionDate, ShopNotes, Today, "Website", "1", InspectionFormExpDate, InspectionID)
            Catch ex As Exception
                InspectionErrorLabel.Text = ex.ToString
                InspectionErrorLabel.Visible = True
            End Try
        Else
            InspectionErrorLabel.Text = ErrorMessage
            InspectionErrorLabel.Visible = True
        End If

        If bValid Then
            InspectionInfoGridView.EditIndex = -1
            FillInspectionGrid(Session("TruckID"))
        End If

    End Sub
    'Private Sub InspectionInfoGridView_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles InspectionInfoGridView.RowUpdating
    'End Sub

    Protected Sub InspectionGridView_RowEditing(ByVal sender As Object, ByVal e As GridViewEditEventArgs) Handles InspectionInfoGridView.RowEditing
        InspectionInfoGridView.EditIndex = e.NewEditIndex
        BindGridViews(Session("TruckID"))
    End Sub

    Protected Sub InspectionGridView_RowCancelingEdit(ByVal sender As Object, ByVal e As GridViewCancelEditEventArgs) Handles InspectionInfoGridView.RowCancelingEdit
        'SpecErrorLabel.Visible = False
        'SpecErrorLabel.Text = String.Empty
        InspectionInfoGridView.EditIndex = -1
        BindGridViews(Session("TruckID"))
    End Sub

    Protected Sub InspectionGridView_RowDeleting(ByVal sender As Object, ByVal e As GridViewDeleteEventArgs) Handles InspectionInfoGridView.RowDeleting
        'Dim spec As New PARDataSetTableAdapters.PAR_SpecTableAdapter
        'Dim specID As String = InspectionInfoGridView.DataKeys(e.RowIndex).Values(0).ToString()
        'SpecErrorLabel.Visible = False
        'SpecErrorLabel.Text = String.Empty

        'Try
        '    spec.Delete(Utils.ConvertToGUID(specID))
        'Catch ex As Exception

        'End Try

        'BindGridViews()
    End Sub

    '***************************************************************************************
    '*Driver Gridview Mehods
    '***************************************************************************************
    Private Sub BindDriverGridView(ByVal truckID As Integer)
        Dim DriverTableAdapter As New TruckFleetTableAdapters.FleetDriversTableAdapter
        Dim DriverTable As New TruckFleet.FleetDriversDataTable

        DriverTableAdapter.FillByTruckID(DriverTable, truckID)

        DriverGridView.DataSource = DriverTable

        DriverGridView.DataBind()
    End Sub

    Protected Sub DriverGridView_RowDeleting(ByVal sender As Object, ByVal e As GridViewDeleteEventArgs) Handles DriverGridView.RowDeleting



    End Sub

    Private Sub CancelButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancelButton.Click
        Response.Redirect("Default.aspx")
    End Sub

    Private Sub SaveButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveButton.Click
        SaveData()
    End Sub

    Private Sub LinkNewDriverButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkNewDriverButton.Click
        Response.Redirect("LinkDriver.aspx")
    End Sub

    Private Sub SaveData()

        Dim FleetDetailTableAdapter As New TruckFleetTableAdapters.FleetDetailTableAdapter
        Dim FleetDetailTable As New TruckFleet.FleetDetailDataTable
        Dim IsInsert As Boolean = False
        Dim IsValid As Boolean = True
        Dim ErrorMessage As String = String.Empty

        Dim TruckID As Integer = CInt(Session("TruckID"))

        FleetDetailTableAdapter.FillByTruckID(FleetDetailTable, TruckID)

        Dim dr As DataRow

        'Try
        If FleetDetailTable.Rows.Count > 0 Then

            dr = FleetDetailTable.Rows(0)
            IsInsert = False

        Else
            IsInsert = True
        End If

        Dim Vin As Object = Nothing
        Dim UnitNumber As Object = Nothing
        Dim RegExpDate As Object = Nothing
        Dim VehicleValue As Object = Nothing
        Dim PlateNumber As Object = Nothing
        Dim Make As Object = Nothing
        Dim Model As Object = Nothing
        Dim Color As Object = Nothing
        Dim TruckYear As Object = Nothing
        Dim UnladenWeight As Object = Nothing
        Dim GrossWeight As Object = Nothing
        Dim Axles As Object = Nothing
        Dim LicNo As Object = Nothing
        Dim InsCompName As Object = Nothing
        Dim InsPolicyNum As Object = Nothing
        Dim InsLimit As Object = Nothing
        Dim InsExpDate As Object = Nothing
        Dim TruckOwner As Object = Nothing
        Dim State As Object = Nothing
        Dim LastEvaluationDate As Object = Nothing

        If VinTextBox.Text.Length > 0 Then
            Vin = VinTextBox.Text
        End If
        If UnitNumberTextBox.Text.Length > 0 Then
            UnitNumber = UnitNumberTextBox.Text
        End If
        If IsDate(RegExpirationDateTextBox.Text) Then
            RegExpDate = CDate(RegExpirationDateTextBox.Text)
        ElseIf RegExpirationDateTextBox.Text.Length > 0 Then
            ErrorMessage = ErrorMessage & "Registration Expiration Date must be a date"
            IsValid = False
        End If
        If IsDate(Me.LastEvalDateTextBox.Text) Then
            LastEvaluationDate = CDate(Me.LastEvalDateTextBox.Text)
        ElseIf Me.LastEvalDateTextBox.Text.Length > 0 Then
            ErrorMessage = ErrorMessage & "Last Evaluation Date must be a date"
            IsValid = False
        End If
        If VehicleValueTextBox.Text.Length > 0 Then
            VehicleValue = VehicleValueTextBox.Text
        End If
        If PlateNumberTextBox.Text.Length > 0 Then
            PlateNumber = PlateNumberTextBox.Text
        End If
        If MakeTextBox.Text.Length > 0 Then
            Make = MakeTextBox.Text
        End If
        If ModelTextBox.Text.Length > 0 Then
            Model = ModelTextBox.Text
        End If
        If ColorTextBox.Text.Length > 0 Then
            Color = ColorTextBox.Text
        End If
        If TruckYearTextBox.Text.Length > 0 Then
            TruckYear = TruckYearTextBox.Text
        End If
        If UnladenWeightTextBox.Text.Length > 0 Then
            UnladenWeight = UnladenWeightTextBox.Text
        End If
        If GrossWeightTextBox.Text.Length > 0 Then
            GrossWeight = GrossWeightTextBox.Text
        End If
        If AxlesTextBox.Text.Length > 0 Then
            Axles = AxlesTextBox.Text
        End If

        If InsuranceNameTextBox.Text.Length > 0 Then
            InsCompName = InsuranceNameTextBox.Text
        End If
        If InsurancePolicyNumberTextBox.Text.Length > 0 Then
            InsPolicyNum = InsurancePolicyNumberTextBox.Text
        End If
        If InsuranceLimitTextBox.Text.Length > 0 Then
            InsLimit = InsuranceLimitTextBox.Text
        End If
        If IsDate(InsuranceExpirationTextBox.Text) Then
            InsExpDate = CDate(InsuranceExpirationTextBox.Text)
        ElseIf InsuranceExpirationTextBox.Text.Length > 0 Then
            ErrorMessage = ErrorMessage & "Insurance Expiration Date must be a Date"
            IsValid = False
        End If
        Select Case TruckOwnerRadioButtonList.SelectedValue
            Case "1"
                TruckOwner = "1"
            Case "2"
                TruckOwner = "2"
            Case "3"
                TruckOwner = "3"
        End Select
        State = RegStateDropDownList.SelectedValue

        If IsValid Then
            If IsInsert Then

                FleetDetailTableAdapter.Insert(Vin, Session("CompanyID"), PlateNumber, UnitNumber, VTypeDropDownList.SelectedValue, Model, TruckYear, _
                                            Make, Color, UnladenWeight, GrossWeight, Axles, LicNo, State, VehicleValue, LastEvaluationDate, Today(), InsCompName, InsPolicyNum, _
                                            InsExpDate, InsLimit, TruckOwner, RegExpDate)
            Else
                FleetDetailTableAdapter.Update(Vin, CInt(Session("CompanyID")), "3", PlateNumber, UnitNumber, VTypeDropDownList.SelectedValue, Model, TruckYear, Make, Color, UnladenWeight, GrossWeight, Axles, LicNo, State, VehicleValue, LastEvaluationDate, Today(), InsCompName, InsPolicyNum, InsExpDate, InsLimit, TruckOwner, RegExpDate, TruckID)

            End If
        End If


        Dim VendorTableAdapter As New TruckFleetTableAdapters.FleetVendorTableAdapter
        Dim VendorTable As New TruckFleet.FleetVendorDataTable

        VendorTableAdapter.FillByTruckID(VendorTable, TruckID)

        If VendorTable.Rows.Count > 0 Then
            Session("VendorID") = VendorTable.Rows(0)("DF_TVI_ID")
            IsInsert = False
        Else
            IsInsert = True
        End If

        Dim VendorCode As Object = Nothing
        Dim VendorAddress As Object = Nothing
        Dim VCity As Object = Nothing
        Dim VZip As Object = Nothing
        Dim VPhone As Object = Nothing
        Dim VCompName As Object = Nothing
        Dim VFedID As Object = Nothing
        Dim VSSN As Object = Nothing
        Dim VType As Object = Nothing
        If VendorCodeTextBox.Text.Length > 0 Then
            VendorCode = VendorCodeTextBox.Text
        End If
        If VendorInfoOOAddressTextBox.Text.Length > 0 Then
            VendorAddress = VendorInfoOOAddressTextBox.Text
        End If
        If VendorCityTextBox.Text.Length > 0 Then
            VCity = VendorCityTextBox.Text
        End If
        If VendorZipTextBox.Text.Length > 0 Then
            VZip = VendorZipTextBox.Text
        End If
        If VendorInfoOOPhoneTextBox.Text.Length > 0 Then
            VPhone = VendorInfoOOPhoneTextBox.Text
        End If
        If VendorInfoOOTextBox.Text.Length > 0 Then
            VCompName = VendorInfoOOTextBox.Text
        End If
        If FederID1TextBox.Text.Length > 0 Then
            VFedID = FederID1TextBox.Text
        End If
        If VendorSSNTextBox.Text.Length > 0 Then
            VSSN = VendorSSNTextBox.Text
        End If
        Dim NullValue As Object = Nothing
        If VendorInfoOORadioButtonList.SelectedIndex > -1 Then
            VType = CInt(VendorInfoOORadioButtonList.SelectedValue)
        End If

        If IsInsert Then
            VendorTableAdapter.Insert(VendorTableAdapter.NextVendorID, TruckID.ToString, VType, VSSN, VFedID, 0, NullValue, Today, 3, VendorCode, VCompName, NullValue, _
                                      NullValue, VendorAddress, VCity, VZip, VPhone, NullValue, NullValue, NullValue, 0)
        Else
            VendorTableAdapter.Update(TruckID, VType, VSSN, VFedID, 3, VendorCode, VendorAddress, VCity, VZip, VCompName, VPhone, Session("VendorID"))
        End If

        If Not IsValid Then
            TruckFleetErrorLabel.Text = ErrorMessage
            TruckFleetErrorLabel.Visible = True
        Else
            BindGridViews(TruckID)
        End If




        'Catch ex As Exception
        'Me.TruckFleetErrorLabel.Text = ex.ToString
        'Me.TruckFleetErrorLabel.Visible = True
        'End Try




    End Sub


End Class