﻿Public Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim WSUsersToCompanies As New UserDataTableAdapters.WSUsersToCompaniesTableAdapter
        Dim wst As New UserData.WSUsersToCompaniesDataTable
        WSUsersToCompanies.FillByWSUName(wst, User.Identity.Name)
        If wst.Rows.Count > 0 Then
            Me.UserID.Value = wst.Rows(0)("DQFUserID")
            Me.CompanyID.Value = wst.Rows(0)("DQFCompanyID")
        End If
        Dim udata As New UserDataTableAdapters.DQFUsersTableAdapter
        Dim udt As New UserData.DQFUsersDataTable
        udata.FillByUID(udt, Me.UserID.Value)
        If udt.Rows.Count > 0 Then
            Me.WelcomeLabel.Text = "Welcome to the Fleet Module " & udt.Rows(0)("DF_UR_FISRTNAME") & " " & udt.Rows(0)("DF_UR_LASTNAME")
        End If
        Dim FleetDataTA As New TruckFleetTableAdapters.FleetListTableAdapter
        Dim FleetDataTb As New TruckFleet.FleetListDataTable
        FleetDataTA.Fill(FleetDataTb, CompanyID.Value)
        GridView1.DataSourceID = ""
        GridView1.DataSource = FleetDataTb

        GridView1.DataBind()

    End Sub

    Public Sub GetTruck(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        Session("TruckID") = Me.GridView1.Rows(e.CommandArgument).Cells(0).Text
        Session("CompanyID") = Me.CompanyID.Value
        Response.Redirect("FleetDetail.aspx")
    End Sub


    Private Sub AddNewButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles AddNewButton.Click
        Session("IsNewFleet") = True
        Response.Redirect("FleetDetail.aspx")
    End Sub
End Class