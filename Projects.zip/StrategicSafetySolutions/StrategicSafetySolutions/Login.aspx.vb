﻿Public Partial Class Login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If User.Identity.IsAuthenticated Then
            Response.Redirect("Logout.aspx")
        End If
        checkJavaScript()
        checkCookies()
        redirectUser()
    End Sub

    Protected Sub Login1_Authenticate(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.AuthenticateEventArgs) Handles Login1.Authenticate
        ' Log the user in and redirect them to this same page, which will redirect them to the appropriate screen
        If Membership.ValidateUser(Login1.UserName, Login1.Password) Then
            FormsAuthentication.SetAuthCookie(Login1.UserName, False)
            redirectUser()
        Else
            Response.Redirect("Login.aspx")
        End If
    End Sub

    Private Sub redirectUser()
        Dim currentUser As System.Web.Security.MembershipUser
        currentUser = Membership.GetUser(Login1.UserName)
        If Not (currentUser Is Nothing) Then
            If Request.QueryString("newLogin") = "True" Then
                Response.Redirect("Logout.aspx")
            ElseIf Roles.IsUserInRole(currentUser.UserName, "SSSAdmin") Then
                Response.Redirect("~/Admin/")
            ElseIf Roles.IsUserInRole(currentUser.UserName, "Fleet") Then
                Response.Redirect("~/Fleet/Default.aspx")
            ElseIf Roles.IsUserInRole(currentUser.UserName, "User") Then
                Response.Redirect("~/Membership/UserProfile.aspx")
            End If
        End If
    End Sub

    Private Sub checkCookies()
        If Not Page.IsPostBack Then
            'Check whether cookies are enabled
            If Request.QueryString("Trying") = "" Then
                ' this is the first time this page has been called
                ' set a cookie and redirect to this same page
                Response.SetCookie(New System.Web.HttpCookie("TryingCookie", "ON"))
                Response.Redirect(Request.ServerVariables("URL") & "?Trying=ON")
            Else
                ' we got here because of the redirection
                If (Request.Cookies("TryingCookie") Is Nothing) OrElse (Request.Cookies("TryingCookie").Value() = "") Then
                    ' cookies aren't supported - display an error message and exit
                    Label1.Text = "Cookies must be enabled for this website to work properly.<br/>Please check your browser settings.<br/>"
                    Label1.ForeColor = Drawing.Color.Red
                    Label1.Visible = True
                Else
                    Label1.Visible = False
                End If
                ' clear the trying cookie (optional)
                Response.SetCookie(New System.Web.HttpCookie("TryingCookie", ""))
            End If

            ' Cookies are enabled, so set the session timeout to 10 minutes
            If Session.IsNewSession Then
                Session.Timeout = 10
            End If
        End If
    End Sub

    Private Sub checkJavaScript()
        If Not Page.IsPostBack Then
            'Check whether Javascript is enabled
            If Not (Request.Browser.EcmaScriptVersion().Major >= 1) Then
                ' javascript isnt supported - display an error message and exit
                Label1.Text = "JavaScript and cookies must be enabled for this website to work properly.<br/>Please check your browser settings.<br/>"
                Label1.ForeColor = Drawing.Color.Red
                Label1.Visible = True
            Else
                Label1.Visible = False
            End If
        End If
    End Sub

End Class