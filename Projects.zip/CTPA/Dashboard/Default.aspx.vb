Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data
Imports RenewalStatementWebSvc.ReportingService2005
Imports microsoft.reporting.webforms
Partial Class AADTOnline_Dashboard_Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label2.Text = Today()
        Label4.Text = Profile.RepID
        Dim username As String = Profile.UserName
        If Roles.IsUserInRole(username, "Finance") Then
            Label3.Visible = False
            Label4.Visible = False
            RepGridView.Visible = False
            FinanceGridView.Visible = True
        Else
            RepGridView.Visible = True
            FinanceGridView.Visible = False
        End If
        Dim dv As Data.DataView
        Dim numChanges As Integer

        If Roles.IsUserInRole(username, "AccountRep") Then
            HyperLink1.Text = "There are website users who are not yet verified/approved.(" & Roles.GetUsersInRole("Unverified").GetLength(0) & ")"
            HyperLink1.NavigateUrl = "~/Admin/NewUsers.aspx"
            HyperLink1.Visible = True
        End If

        If Membership.GetUser.UserName.ToUpper <> "ADMINISTRATOR" Or Membership.GetUser.UserName.ToUpper <> "ADMIN" Then
            Dim prams(1) As Data.SqlClient.SqlParameter
            prams(0) = New Data.SqlClient.SqlParameter("@RepID", Data.SqlDbType.Int)
            If Profile.RepID = "" Then
                prams(0).Value = 0
            Else
                prams(0).Value = Convert.ToInt32(Profile.RepID)
            End If
            numChanges = Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteDataset(CTPA.Common.Config.ConnectionString, Data.CommandType.StoredProcedure, "UpdatesByRep", prams).Tables(0).Rows.Count()
        Else
            numChanges = Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteDataset(CTPA.Common.Config.ConnectionString, Data.CommandType.StoredProcedure, "GET_PENDING_WS_UPDATES").Tables(0).Rows.Count
        End If


        If numChanges = 0 And numChanges = 0 Then
            HyperLink2.Text = "There are no member changes waiting to be applied."
            HyperLink2.NavigateUrl = ""
            HyperLink2.Visible = True
        Else
            HyperLink2.Text = "There are " & numChanges & " changes waiting for approval."
            HyperLink2.NavigateUrl = "~/Admin/ApproveChanges.aspx"
            HyperLink2.Visible = True
        End If

        Dim PendingDAACount As Integer

        PendingDAACount = Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteDataset(CTPA.Common.Config.ConnectionString, Data.CommandType.StoredProcedure, "CountAgreements").Tables(0).Rows.Count
        If PendingDAACount > 0 Then
            HyperLink4.Text = "There are " & " " & PendingDAACount & " " & " agreements pending approval"
            HyperLink4.NavigateUrl = "~/Admin/BrokerAgreements/ApproveAgreements.aspx"
            HyperLink4.Visible = True
        Else
            HyperLink4.Text = "There are no agreements waiting for approval"
            HyperLink4.Text = ""
        End If


            dv = SqlDataSource2.Select(DataSourceSelectArguments.Empty)
            HyperLink3.Text = "There are " & dv.Table.Rows.Count & " active web site user accounts."
            HyperLink3.NavigateUrl = "~/Admin/ManageUsers.aspx"
            HyperLink3.Visible = True
    End Sub


    Protected Sub RepApproved(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        Dim comp_id As Integer
        Dim amount_due As Double
        Dim index As Integer = Convert.ToInt32(e.CommandArgument)

        ' Get the last name of the selected author from the appropriate
        ' cell in the GridView control
        Dim selectedRow As GridViewRow = RepGridView.Rows(index)
        Dim Cell As TableCell = selectedRow.Cells(2)
        Dim cell2 As TableCell = selectedRow.Cells(3)
        Dim cell3 As TableCell = selectedRow.Cells(5)
        Dim PaymentType As String
        PaymentType = cell3.Text
        If e.CommandName = "Approve" Then
            comp_id = Convert.ToInt32(Cell.Text)
            Dim r As CTPA.Entities.Renewal
            r = New CTPA.Entities.Renewal(comp_id)
            If InStr(PaymentType, "Check", CompareMethod.Text) Then
                'If cell3.Text <> "MasterCard" And cell3.Text <> "VISA" And cell3.Text <> "Amex" Then
                Dim prams(0) As SqlParameter
                prams(0) = New SqlParameter("@COMP_ID", SqlDbType.BigInt)
                prams(0).Value = Profile.CompID
                amount_due = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.GET_TOTAL_FEE_PROC", prams)
                r.CC_TYPE = "CHECK"
            Else
                Dim prams(0) As SqlParameter
                prams(0) = New SqlParameter("@COMP_ID", SqlDbType.BigInt)
                prams(0).Value = Profile.CompID
                amount_due = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.GET_TOTAL_FEE_PROC_CC", prams)
            End If
            r.CC_TYPE = PaymentType
            r.TOTAL_FEE = amount_due
            r.FINANCE_APPROVED = True
            r.REP_APPROVED = True
            r.PAYMENT_RECEIVED_PROCESSED = Today()
            r.PROCESS_COMPLETE = False
            r.Save()
            Response.Redirect("default.aspx")
        Else
            If e.CommandName = "Roster" Then
                Dim compid As Int32
                compid = Convert.ToInt32(Cell.Text)
                Dim ReportChoice As String
                If InStr(PaymentType, "Check", CompareMethod.Text) Then
                    ReportChoice = "/RenewalStatement"
                Else
                    ReportChoice = "/RenewalStatementCC"
                End If
                cell3.Text = PaymentType
                Dim parm1(0) As ReportParameter
                ReportViewer1.ServerReport.ReportPath = ReportChoice
                parm1(0) = New Microsoft.Reporting.WebForms.ReportParameter("COMP_ID", compid)
                ReportViewer1.ServerReport.SetParameters(parm1)
                ReportViewer1.ShowParameterPrompts = False
                ReportViewer1.Visible = True
            Else
                ReportViewer1.Visible = False
            End If
        End If
    End Sub
    Protected Sub FinanceApproved(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        Dim comp_id As Integer
        Dim amount_due As Double
        Dim index As Integer = Convert.ToInt32(e.CommandArgument)

        ' Get the last name of the selected author from the appropriate
        ' cell in the GridView control
        Dim selectedRow As GridViewRow = FinanceGridView.Rows(index)
        Dim Cell As TableCell = selectedRow.Cells(2)
        Dim cell2 As TableCell = selectedRow.Cells(3)
        Dim cell3 As TableCell = selectedRow.Cells(5)
        Dim PaymentType As String
        PaymentType = cell3.Text
        If e.CommandName = "Approve" Then
            comp_id = Convert.ToInt32(Cell.Text)
            Dim r As CTPA.Entities.Renewal
            r = New CTPA.Entities.Renewal(comp_id)
            If InStr(cell3.Text, "Check", CompareMethod.Text) Then
                Dim prams(0) As SqlParameter
                prams(0) = New SqlParameter("@COMP_ID", SqlDbType.BigInt)
                prams(0).Value = Profile.CompID
                amount_due = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.GET_TOTAL_FEE_PROC", prams)
                r.CC_TYPE = "CHECK"
            Else
                Dim prams(0) As SqlParameter
                prams(0) = New SqlParameter("@COMP_ID", SqlDbType.BigInt)
                prams(0).Value = Profile.CompID
                amount_due = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.GET_TOTAL_FEE_PROC_CC", prams)
            End If
            r.CC_TYPE = PaymentType
            r.TOTAL_FEE = amount_due
            r.FINANCE_APPROVED = True
            r.PAYMENT_RECEIVED_PROCESSED = Today()
            r.PROCESS_COMPLETE = False
            r.Save()
            Response.Redirect("default.aspx")
        Else
            If e.CommandName = "Roster" Then
                Dim compid As Int32
                compid = Convert.ToInt32(Cell.Text)
                Dim ReportChoice As String
                If InStr(PaymentType, "Check", CompareMethod.Text) Then
                    ReportChoice = "/RenewalStatement"
                Else
                    ReportChoice = "/RenewalStatementCC"
                End If
                cell3.Text = PaymentType
                Dim parm1(0) As ReportParameter
                ReportViewer1.ServerReport.ReportPath = ReportChoice
                parm1(0) = New Microsoft.Reporting.WebForms.ReportParameter("COMP_ID", compid)
                ReportViewer1.ServerReport.SetParameters(parm1)
                ReportViewer1.ShowParameterPrompts = False
                ReportViewer1.Visible = True
            Else
                ReportViewer1.Visible = False
            End If
        End If
    End Sub

    
End Class



