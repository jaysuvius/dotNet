
Partial Class CDATA_Default
    Inherits System.Web.UI.Page

    'Dim viewIndex As Integer

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack() Then
            ViewIndex.Text = 0
            newIndex()
            Button6.Visible = False
            Button7.Visible = False
            Label2.Visible = False
        End If
    End Sub

    Private Sub newIndex()
        If Roles.GetUsersInRole("Unverified").GetLength(0) = 0 Then
            Response.Redirect("./Default.aspx")
            Exit Sub
        End If
        If ViewIndex.Text >= Roles.GetUsersInRole("Unverified").GetLength(0) Then
            ViewIndex.Text = Roles.GetUsersInRole("Unverified").GetLength(0) - 1
            TextBox1.Text = "Test"
        ElseIf ViewIndex.Text < 0 Then
            ViewIndex.Text = 0
        End If
        TextBox1.Text = Membership.GetUser(Roles.GetUsersInRole("Unverified")(ViewIndex.Text)).UserName
        TextBox2.Text = Profile.GetProfile(Roles.GetUsersInRole("Unverified")(ViewIndex.Text)).CompanyName
        TextBox3.Text = Profile.GetProfile(Roles.GetUsersInRole("Unverified")(ViewIndex.Text)).FullName
        TextBox4.Text = Membership.GetUser(Roles.GetUsersInRole("Unverified")(ViewIndex.Text)).Email
        TextBox5.Text = Profile.GetProfile(Roles.GetUsersInRole("Unverified")(ViewIndex.Text)).Address1
        TextBox6.Text = Profile.GetProfile(Roles.GetUsersInRole("Unverified")(ViewIndex.Text)).City
        TextBox7.Text = Profile.GetProfile(Roles.GetUsersInRole("Unverified")(ViewIndex.Text)).State
        TextBox8.Text = Profile.GetProfile(Roles.GetUsersInRole("Unverified")(ViewIndex.Text)).ZIP
        TextBox9.Text = Profile.GetProfile(Roles.GetUsersInRole("Unverified")(ViewIndex.Text)).CompID
        TextBox10.Text = Profile.GetProfile(Roles.GetUsersInRole("Unverified")(ViewIndex.Text)).ContactPhoneNum
        TextBox11.Text = Profile.GetProfile(Roles.GetUsersInRole("Unverified")(ViewIndex.Text)).ContactPhoneExt
        TextBox12.Text = Profile.GetProfile(Roles.GetUsersInRole("Unverified")(ViewIndex.Text)).ContactMobile

        If Profile.GetProfile(Roles.GetUsersInRole("Unverified")(ViewIndex.Text)).EmailInvoice = "true" Then
            chkInvoice.Checked = True
        Else
            chkInvoice.Checked = False
        End If
        If Profile.GetProfile(Roles.GetUsersInRole("Unverified")(ViewIndex.Text)).EmailRenewal = "true" Then
            chkRenewal.Checked = True
        Else
            chkRenewal.Checked = False
        End If
        If Profile.GetProfile(Roles.GetUsersInRole("Unverified")(ViewIndex.Text)).EmailRandom = "true" Then
            chkRandoms.Checked = True
        Else
            chkRandoms.Checked = False
        End If

        Label1.Text = "Currently reviewing " & (ViewIndex.Text + 1) & " of " & Roles.GetUsersInRole("Unverified").GetLength(0) & " unverified website users"
        SqlDataSource1.Select(DataSourceSelectArguments.Empty)
        Button3.Visible = False
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        ViewIndex.Text = ViewIndex.Text - 1
        newIndex()
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        ViewIndex.Text = ViewIndex.Text + 1
        newIndex()
    End Sub


    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        If UserInCompanyExists() Then
            Button3.Text = "Link " & TextBox1.Text & " to company " & GridView1.SelectedRow.Cells(1).Text & " (" & (New CTPA.Entities.Company(GridView1.SelectedRow.Cells(1).Text).COMPANY) & ")."
        Else
            Button3.Text = "Link " & TextBox1.Text & " to company " & GridView1.SelectedRow.Cells(1).Text & " (" & (New CTPA.Entities.Company(GridView1.SelectedRow.Cells(1).Text).COMPANY) & ") and authorize as company admin."
        End If
        Button3.Visible = True
        Button3.Focus()
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        If Membership.GetUser(TextBox1.Text).IsOnline Then
            'User is online do not approve
            'Put a descriptive error message here
            Label1.Text = "This user is currently logged in.  Please wait for them to log out before approving them."
        End If
        Try
            If UserInCompanyExists() Then
            Else
                If Not Roles.IsUserInRole(TextBox1.Text, "WSAdmin") Then
                    Roles.AddUserToRole(TextBox1.Text, "WSAdmin")
                End If
            End If
        Catch ex As Exception
            Label1.Text = "Unknown error checking company accounts, cannot approve."
            CDataFunctions.CatchError(ex.Message, ex.Source, ex.StackTrace, ex.TargetSite, ex.HelpLink, ex.InnerException, ex.GetBaseException())
            Exit Sub
        End Try
        Dim profileUpdate As ProfileCommon
        profileUpdate = Profile.GetProfile(Roles.GetUsersInRole("Unverified")(ViewIndex.Text))
        profileUpdate.CompID = GridView1.SelectedRow.Cells(1).Text
        profileUpdate.CompanyName = GridView1.SelectedRow.Cells(2).Text
        profileUpdate.Address1 = TextBox5.Text
        profileUpdate.City = TextBox6.Text
        profileUpdate.State = TextBox7.Text
        profileUpdate.ZIP = TextBox8.Text
        profileUpdate.ContactPhoneNum = TextBox10.Text
        profileUpdate.ContactPhoneExt = TextBox11.Text
        profileUpdate.ContactMobile = TextBox12.Text
        If chkInvoice.Checked = True Then
            profileUpdate.EmailInvoice = "true"
        Else
            profileUpdate.EmailInvoice = "false"
        End If

        If chkInvoice.Checked = True Then
            profileUpdate.EmailRenewal = "true"
        Else
            profileUpdate.EmailRenewal = "false"
        End If

        If chkInvoice.Checked = True Then
            profileUpdate.EmailRandom = "true"
        Else
            profileUpdate.EmailRandom = "false"
        End If

        profileUpdate.Save()
        Dim oldCompID As Integer = 0
        Try
            oldCompID = CTPA.Common.MembershipTracking.GetWSUserCompany(TextBox1.Text)            
        Catch ex As Exception
            CDataFunctions.CatchError(ex.Message, ex.Source, ex.StackTrace, ex.TargetSite, ex.HelpLink, ex.InnerException, ex.GetBaseException())
        End Try
        Try
            If oldCompID <> 0 Then
                CTPA.Common.MembershipTracking.ChangeWSUserCompany(TextBox1.Text, Convert.ToDouble(GridView1.SelectedRow.Cells(1).Text))
            Else
                CTPA.Common.MembershipTracking.AddWSUserToCompany(TextBox1.Text, Convert.ToDouble(GridView1.SelectedRow.Cells(1).Text))
            End If
        Catch ex As Exception
            CDataFunctions.CatchError(ex.Message, ex.Source, ex.StackTrace, ex.TargetSite, ex.HelpLink, ex.InnerException, ex.GetBaseException())
            ' Could not track web site user account
        End Try
        ' Set the profile to "Verified"
        If Roles.IsUserInRole(TextBox1.Text, "Unverified") Then
            Roles.RemoveUserFromRole(TextBox1.Text, "Unverified")
        End If
        If Not (Roles.IsUserInRole(TextBox1.Text, "Verified")) Then
            Roles.AddUserToRole(TextBox1.Text, "Verified")
        End If
        CTPA.Common.Emailer.VerifiedStatusNotifyByEmail(Membership.GetUser(TextBox1.Text), True, Membership.GetUser.UserName)
        newIndex()
    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        SqlDataSource1.Select(DataSourceSelectArguments.Empty)
    End Sub

    Private Function UserInCompanyExists() As Boolean
        Dim dv As Data.DataView
        Dim dssa As DataSourceSelectArguments
        dssa = New DataSourceSelectArguments()
        Dim WCP As New System.Web.UI.WebControls.Parameter("@COMP_ID", TypeCode.Single)
        Try
            SqlDataSource2.SelectParameters(0).DefaultValue = Convert.ToSingle(GridView1.SelectedRow.Cells(1).Text)
            dv = SqlDataSource2.Select(DataSourceSelectArguments.Empty)
        Catch ex As Exception
            Throw New Exception("Error checking for first user in company", ex)
            CDataFunctions.CatchError(ex.Message, ex.Source, ex.StackTrace, ex.TargetSite, ex.HelpLink, ex.InnerException, ex.GetBaseException())
        End Try
        Return dv.Table.Rows.Count > 0
    End Function

    Private Sub DeleteUser()
        Dim username As String = TextBox1.Text
        Dim userProfile As ProfileCommon
        userProfile = Profile.GetProfile(username)
        userProfile.CompanyName = String.Empty
        userProfile.CompID = 0
        userProfile.FullName = String.Empty
        userProfile.Address1 = String.Empty
        userProfile.City = String.Empty
        userProfile.State = String.Empty
        userProfile.ZIP = String.Empty
        userProfile.ContactPhoneNum = String.Empty
        userProfile.ContactPhoneExt = String.Empty
        userProfile.ContactMobile = String.Empty
        userProfile.RepID = String.Empty
        userProfile.Save()
        Membership.DeleteUser(username, True)
        If Roles.IsUserInRole(username, "Unverified") Then
            Roles.RemoveUserFromRole(username, "Unverified")
        End If
        If Roles.IsUserInRole(username, "Verified") Then
            Roles.RemoveUserFromRole(username, "Verified")
        End If
        If Roles.IsUserInRole(username, "WSAdmin") Then
            Roles.RemoveUserFromRole(username, "WSAdmin")
        End If
        If Roles.IsUserInRole(username, "Results") Then
            Roles.RemoveUserFromRole(username, "Results")
        End If
        If Roles.IsUserInRole(username, "Drivers") Then
            Roles.RemoveUserFromRole(username, "Drivers")
        End If
        If Roles.IsUserInRole(username, "Company") Then
            Roles.RemoveUserFromRole(username, "Company")
        End If
        If Roles.IsUserInRole(username, "CDATA") Then
            Roles.RemoveUserFromRole(username, "CDATA")
        End If
        If Roles.IsUserInRole(username, "Superadmin") Then
            Roles.RemoveUserFromRole(username, "Superadmin")
        End If
        CTPA.Common.MembershipTracking.DelWSUser(username)
    End Sub

    Protected Sub Button5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button5.Click
        Button6.Visible = True
        Button7.Visible = True
        Label2.Visible = True
    End Sub

    Protected Sub Button6_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button6.Click
        DeleteUser()
        Label2.Text = "User Deleted!"
        Button6.Visible = False
        Button7.Visible = False
        Label2.Visible = False
        Response.Redirect("NewUsers.aspx")
    End Sub

    Protected Sub Button7_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button7.Click
        Button6.Visible = False
        Button7.Visible = False
        Label2.Visible = False
    End Sub

    Protected Sub BtnBroker_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnBroker.Click
        Session("UserID") = TextBox1.Text
        Response.Redirect("~/Admin/BrokerAgreements/ApproveBroker.aspx")
    End Sub
End Class
