
Partial Class CDATA_Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim dv As Data.DataView
        Dim numChanges As Integer

        If Membership.GetUser.UserName.ToUpper = "ADMINISTRATOR" Or Membership.GetUser.UserName.ToUpper = "ADMIN" Then
            Label1.Visible = False
            HyperLink1.Visible = True
            HyperLink2.Visible = True
            HyperLink3.Visible = True
            If (Roles.GetUsersInRole("Unverified").GetLength(0) = 0) Then
                HyperLink1.Text = "There are no website users who are not yet verified/approved."
                HyperLink1.NavigateUrl = ""
                HyperLink1.Visible = True
            Else
                HyperLink1.Text = "There are website users who are not yet verified/approved.(" & Roles.GetUsersInRole("Unverified").GetLength(0) & ")"
                HyperLink1.NavigateUrl = "NewUsers.aspx"
                HyperLink1.Visible = True
            End If


            If Membership.GetUser.UserName.ToUpper = "ADMINISTRATOR" Or Membership.GetUser.UserName.ToUpper = "ADMIN" Then
                numChanges = Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, Data.CommandType.StoredProcedure, "CountPendingUpdates")
            Else
                Dim prams(1) As Data.SqlClient.SqlParameter
                prams(0) = New Data.SqlClient.SqlParameter("@RepID", Data.SqlDbType.NVarChar)
                prams(0).Value = Profile.RepID
                numChanges = Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteDataset(CTPA.Common.Config.ConnectionString, Data.CommandType.StoredProcedure, "GET_PENDING_WS_UPDATES_BY_REP", prams).Tables(0).Rows.Count()
            End If


            If numChanges = 0 Then
                HyperLink2.Text = "There are no member changes waiting to be applied."
                HyperLink2.NavigateUrl = ""
                HyperLink2.Visible = True
            Else
                HyperLink2.Text = "There are " & numChanges & " user changes waiting for approval."
                HyperLink2.NavigateUrl = "ApproveChanges.aspx"
                HyperLink2.Visible = True
            End If


            dv = SqlDataSource2.Select(DataSourceSelectArguments.Empty)
            HyperLink3.Text = "There are " & dv.Table.Rows.Count & " active web site user accounts."
            HyperLink3.NavigateUrl = "ManageUsers.aspx"
            HyperLink3.Visible = True
        Else
            Label1.Visible = True
            HyperLink1.Visible = False
            HyperLink2.Visible = False
            HyperLink3.Visible = False
        End If
    End Sub

 
End Class
