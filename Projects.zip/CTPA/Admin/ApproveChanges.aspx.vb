
Partial Class AADTOnline_ApproveChanges
    Inherits System.Web.UI.Page

    Private AddString As String = "Website driver add by"
    Private DeActString As String = "Website driver deactivation"
    Private ReActString As String = "Website driver reactivation"


    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        Dim wsu As CTPA.Entities.WSUpdate = New CTPA.Entities.WSUpdate(Convert.ToInt32(GridView1.SelectedRow.Cells(6).Text.Trim))
        If wsu.ChangeType.ToUpper = "Employee" Then
            ' Need to find the driver's pool ID in order to select it on the update approval page.
            Dim d As New CTPA.Entities.Driver(GridView1.SelectedRow.Cells(3).Text.Trim)
            Dim ds As New Data.DataSet
            Dim PoolID As Integer
            Dim prams(1) As Data.SqlClient.SqlParameter
            prams(0) = New Data.SqlClient.SqlParameter("@AUTOID", Data.SqlDbType.Int)
            prams(0).Value = Convert.ToInt32(GridView1.SelectedRow.Cells(3).Text.Trim)
            ds = Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteDataset(CTPA.Common.Config.ConnectionString, Data.CommandType.StoredProcedure, "dbo.DRIVER_Select", prams)
            ds.Tables(0).Columns.Add(New Data.DataColumn("AutoID"))
            ds.Tables(0).Rows(0)("AutoID") = d.AUTOID
            CTPA.Common.ModeratedDVUpdater.UpdateDataTable(ds.Tables(0), "Employee")
            PoolID = ds.Tables(0).Rows(0)("RNDGRPID")
            If wsu.ChangeDesc.Contains(AddString) Then
                ' This is a driver add, display the pulldown menu and the number of points, etc.
                Dim nvc As Collections.Specialized.NameValueCollection = CTPA.Common.Config.poolNames
                Dim li As System.Web.UI.WebControls.ListItem
                DropDownList1.Items.Clear()
                For Each key As String In nvc.Keys
                    li = New System.Web.UI.WebControls.ListItem(key)
                    DropDownList1.Items.Add(li)
                    If nvc(key) = PoolID Then
                        li.Selected = True
                    End If
                Next
                Label3.Text = "Driver Add - Company Stats:  Replace Points = " & d.company.REPLACEPOINTS _
                & ", YTD Driver Adds = " & d.company.statsYTDAdds & ", YTD Driver Drops = " _
                & d.company.statsYTDDrops & "<br/>" & "Verify driver testing pool:"
                Label3.Visible = True
                DropDownList1.Visible = True
            End If
        End If
        Label1.Text = "Approve or deny the change to " & GridView1.SelectedRow.Cells(2).Text.Trim & " " & GridView1.SelectedRow.Cells(3).Text.Trim & "?<br/><br/>DESCRIPTION:<br/>" & wsu.ChangeDesc
        Label1.Visible = True
        ApproveButton.Visible = True
        DenyButton.Visible = True
        Label2.Visible = False
        GridView1.Visible = False
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Label1.Visible = False
            Label3.Visible = False
            ApproveButton.Visible = False
            DenyButton.Visible = False
        End If
        If Membership.GetUser.UserName.ToUpper <> "Administrator".ToUpper And Membership.GetUser.UserName.ToUpper <> "Admin".ToUpper Then
            Dim prams(1) As Data.SqlClient.SqlParameter
            prams(0) = New Data.SqlClient.SqlParameter("@RepID", Data.SqlDbType.Int)
            prams(0).Value = Convert.ToInt32(Profile.RepID)
            GridView1.DataSource = Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteDataset(CTPA.Common.Config.ConnectionString, Data.CommandType.StoredProcedure, "GET_PENDING_WS_UPDATES_BY_REP", prams)
            GridView1.DataSourceID = Nothing
        End If

        loadGrid()
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles DenyButton.Click
        ' In this function we have to delete blank driver records for those drivers who were added but denied by AADT Admin
        Dim wsu As New CTPA.Entities.WSUpdate(Convert.ToInt32(GridView1.SelectedRow.Cells(6).Text.Trim))
        wsu.Pending = False
        wsu.Approved = False
        wsu.TimeCommitted = DateTime.Now
        wsu.ApprovedBy = Profile.FullName
        wsu.Update()
        Label1.Text = "Change denied for " & GridView1.SelectedRow.Cells(2).Text.Trim & " " & GridView1.SelectedRow.Cells(3).Text.Trim & "."
        CTPA.Common.Emailer.ApprovalStatusNotifyByEmail(wsu, "Denied", Membership.GetUser(wsu.username).Email, Profile.FullName)
        loadGrid()
    End Sub

    Private Sub loadGrid()
        ApproveButton.Visible = False
        DenyButton.Visible = False
        Label1.Visible = False
        Label2.Visible = True
        Label3.Visible = False
        DropDownList1.Visible = False
        GridView1.Visible = True
        GridView1.DataBind()
        If GridView1.Rows.Count <= 0 Then
            Response.Redirect("Default.aspx")
        End If
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ApproveButton.Click
        Dim wsu As CTPA.Entities.WSUpdate
        Dim d As CTPA.Entities.Driver
        ' First perform the update specified in the WSU record (WSUpdates.UpdateCmd)
        Try
            wsu = New CTPA.Entities.WSUpdate(Convert.ToInt32(GridView1.SelectedRow.Cells(6).Text.Trim))
            'Execute the main update
            Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(CTPA.Common.Config.ConnectionString, Data.CommandType.Text, wsu.UpdateCmd)


            ' Check whether this is a driver add, if so activate driver as of today and put them in the correct pool
            If wsu.ChangeType = "Employee" Then
                d = New CTPA.Entities.Driver(wsu.ChangeRecordKey)
                If wsu.ChangeDesc.Contains(AddString) Then
                    d.ACTIVE = Date.Today
                    d.INACTIVE = Nothing
                    d.RNDGRPID = CTPA.Common.Config.poolNames(DropDownList1.Text)
                    Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(CTPA.Common.Config.ConnectionString, Data.CommandType.Text, d.updateCommand)
                End If
            End If


            ' Now update the WS_Updates table
            wsu.Pending = False
            wsu.Approved = True
            wsu.TimeCommitted = DateTime.Now
            wsu.ApprovedBy = Profile.FullName
            wsu.Update()

        Catch ex As Exception
            Label1.Text = "Alert administrator - error committing change: " & ex.Message
            Label1.Visible = True
            CDataFunctions.CatchError(ex.Message, ex.Source, ex.StackTrace, ex.TargetSite, ex.HelpLink, ex.InnerException, ex.GetBaseException())
            Exit Sub
        End Try
        Try

            ' Now write the change to the company log
            Dim logEntry As New CTPA.Entities.Log()

            logEntry.ACTIVITY_LOG = wsu.getFriendlyDesc()
            logEntry.COMP_ID = wsu.ChangeRecordKey
            If Not (d Is Nothing) Then
                logEntry.COMP_ID = d.COMP_ID
            End If
            If Not (d Is Nothing) And _
            (wsu.ChangeDesc.Contains(AddString) OrElse wsu.ChangeDesc.Contains(ReActString) OrElse wsu.ChangeDesc.Contains(DeActString)) Then
                logEntry.LOG_TYPE = CTPA.Entities.Log.LogTypes.Billing Or CTPA.Entities.Log.LogTypes.Company
            Else
                logEntry.LOG_TYPE = CTPA.Entities.Log.LogTypes.Company
            End If
            logEntry.USERNAME = Membership.GetUser.UserName()
            logEntry.Insert()
        Catch ex As Exception
            Label1.Text = "Alert administrator - error writing log (change was committed): " & ex.Message
            Label1.Visible = True
            CDataFunctions.CatchError(ex.Message, ex.Source, ex.StackTrace, ex.TargetSite, ex.HelpLink, ex.InnerException, ex.GetBaseException())
            Exit Sub
        End Try


        Label1.Text = "Change committed for " & GridView1.SelectedRow.Cells(2).Text.Trim & " " & GridView1.SelectedRow.Cells(3).Text.Trim & "."
        Label1.Visible = True
        Try
            CTPA.Common.Emailer.ApprovalStatusNotifyByEmail(wsu, "Approved", Membership.GetUser(wsu.username).Email, Profile.FullName)
        Catch ex As Exception
            CDataFunctions.CatchError(ex.Message, ex.Source, ex.StackTrace, ex.TargetSite, ex.HelpLink, ex.InnerException, ex.GetBaseException())
        End Try
        loadGrid()
        Response.Redirect("ApproveChanges.aspx")
        If GridView1.Rows.Count <= 0 Then
            Response.Redirect("Default.aspx")
        End If

    End Sub

  
End Class
