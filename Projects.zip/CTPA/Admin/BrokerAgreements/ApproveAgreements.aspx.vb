Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data
Partial Class Admin_ApproveAgreement
    Inherits System.Web.UI.Page
    Public Shared AgreementID As String
    Public Shared DriverID As String
    Public Shared CompID As String


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            lblLname.Visible = False
            GridView2.Visible = False
            Button1.Visible = False
            Button2.Visible = False
            lblMessage.Visible = False
            lblDeny.Visible = False
            btnDenyYes.Visible = False
            btnDenyNo.Visible = False
            btnDeny.Visible = False
            Label1.Visible = False
            Label2.Visible = False
            Label3.Visible = False
            Label4.Visible = False
            Label5.Visible = True
            Label6.Visible = False
            txtFind.Visible = False
            btnFind.Visible = False
            Label7.Visible = False
        End If
    End Sub

    Protected Sub AgreementSelect(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName = "ChooseAgreement" Then
            Dim index As Integer = Convert.ToInt32(e.CommandArgument)

            ' Get the last name of the selected author from the appropriate
            ' cell in the GridView control
            Dim selectedRow As GridViewRow = GridView1.Rows(index)
            Dim LastName As TableCell = selectedRow.Cells(2)
            Dim SSN As TableCell = selectedRow.Cells(5)
            Dim CDL As TableCell = selectedRow.Cells(4)
            Dim Agreement As TableCell = selectedRow.Cells(8)
            AgreementID = Agreement.Text
            lblLname.Text = LastName.Text
            lblSSN.Text = SSN.Text
            lblCDL.Text = CDL.Text
            lblLname.Visible = True
            GridView1.Visible = False
            GridView2.Visible = True
            'GridView2.DataBind()
            Label5.Visible = False
            Label6.Visible = True
            Label7.Visible = True
            btnFind.Visible = True
            txtFind.Visible = True

        End If
    End Sub
    Protected Sub SelectEmployee(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName = "ChooseEmployee" Then
            Dim index As Integer = Convert.ToInt32(e.CommandArgument)

            ' Get the last name of the selected author from the appropriate
            ' cell in the GridView control
            Dim selectedRow As GridViewRow = GridView2.Rows(index)
            Dim DriverIDCell As TableCell = selectedRow.Cells(2)
            Dim CompIDCell As TableCell = selectedRow.Cells(1)
            Dim Lname As TableCell = selectedRow.Cells(5)
            Dim Fname As TableCell = selectedRow.Cells(3)
            DriverID = DriverIDCell.Text
            CompID = CompIDCell.Text
            lblFirst.Text = Fname.Text
            lblLast.Text = Lname.Text
            lblCompID.Text = CompIDCell.Text
            lblDriverID.Text = DriverIDCell.Text
            Label1.Visible = True
            Label2.Visible = True
            Label3.Visible = True
            Label4.Visible = True
            lblMessage.Visible = True
            Button1.Visible = True
            Button2.Visible = True
            btnDeny.Visible = True
            lblSSN.Visible = False
            lblCDL.Visible = False
        End If
    End Sub
    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim prams(2) As Data.SqlClient.SqlParameter
        prams(0) = New Data.SqlClient.SqlParameter("@AgreementID", Data.SqlDbType.NVarChar)
        prams(0).Value = AgreementID
        prams(1) = New Data.SqlClient.SqlParameter("@CompID", Data.SqlDbType.Int)
        prams(1).Value = Convert.ToInt32(CompID)
        prams(2) = New Data.SqlClient.SqlParameter("@DriverID", Data.SqlDbType.Int)
        prams(2).Value = DriverID
        SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, Data.CommandType.StoredProcedure, "ApproveDAA", prams)
        Response.Redirect("ApproveAgreements.aspx")
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Response.Redirect("ApproveAgreements.aspx")
    End Sub

    Protected Sub btnDeny_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDeny.Click
        lblDeny.Visible = True
        btnDenyYes.Visible = True
        btnDenyNo.Visible = True
    End Sub

    Protected Sub btnDenyYes_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDenyYes.Click
        Dim prams(0) As Data.SqlClient.SqlParameter
        prams(0) = New Data.SqlClient.SqlParameter("@AgreementID", Data.SqlDbType.NVarChar)
        prams(0).Value = AgreementID
        SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, Data.CommandType.StoredProcedure, "DenyDAA", prams)
        Response.Redirect("ApproveAgreements.aspx")
    End Sub

    Protected Sub btnDenyNo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDenyNo.Click
        Response.Redirect("ApproveAgreements.aspx")
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFind.Click
        lblLname.Text = txtFind.Text
        lblCDL.Text = txtFind.Text
        lblSSN.Text = txtFind.Text
        GridView2.DataBind()
    End Sub
End Class
