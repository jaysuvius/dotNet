Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data
Partial Class Admin_ApproveBroker
    Inherits System.Web.UI.Page

    Public BrokerName As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label1.Visible = False
        Button1.Visible = False
        Button2.Visible = False
        btnCompLink.Visible = False
        btnNoComp.Visible = False
        Label2.Visible = False
    End Sub

    Protected Sub LinkBroker(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        ' Get the last name of the selected author from the appropriate
        ' cell in the GridView control
        If e.CommandName = "ChooseBroker" Then
            Dim index As Integer = Convert.ToInt32(e.CommandArgument)
            Dim selectedRow As GridViewRow = GridView1.Rows(index)
            Dim IDCell As TableCell = selectedRow.Cells(3)
            Dim BrokerCell As TableCell = selectedRow.Cells(1)
            Session("BrokerID") = IDCell.Text.ToString
            BrokerName = BrokerCell.Text
            Label1.Text = "Are you sure you wish to link " & Session("UserID") & " To Broker " & BrokerName
            Label1.Visible = True
            Button1.Visible = True
            Button2.Visible = True
        End If
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim username As String
        Dim memUser As MembershipUser
        Dim updateProfile As ProfileCommon
        username = Session("UserID")
        memUser = Membership.GetUser(username)
        updateProfile = Profile.GetProfile(username)
        updateProfile.BrokerID = Session("BrokerID")
        updateProfile.Save()
        If Not Roles.IsUserInRole(username, "Broker") Then
            Roles.AddUserToRole(username, "Broker")
        End If
        Dim prams(1) As SqlParameter
        prams(0) = New SqlParameter("@UserName", SqlDbType.NVarChar)
        prams(0).Value = Profile.UserName
        prams(1) = New SqlParameter("@BrokerID", SqlDbType.NVarChar)
        prams(1).Value = Profile.BrokerID
        SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.UserToBroker", prams)
        Label2.Text = "Do you want to link this user to a company account?"
        btnCompLink.Visible = True
        btnNoComp.Visible = True
        Label2.Visible = True
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Response.Redirect("NewUsers.aspx")
    End Sub

    Protected Sub btnCompLink_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCompLink.Click
        Response.Redirect("~/Admin/NewUsers.aspx")
    End Sub

    Protected Sub btnNoComp_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNoComp.Click
        Dim username As String
        Dim memUser As MembershipUser
        Dim updateProfile As ProfileCommon
        username = Session("UserID")
        memUser = Membership.GetUser(username)
        updateProfile = Profile.GetProfile(username)
        updateProfile.CompID = "99999"
        updateProfile.Save()
        If Not Roles.IsUserInRole(username, "Verified") Then
            Roles.AddUserToRole(username, "Verified")
        End If
        If Roles.IsUserInRole(username, "unverified") Then
            Roles.RemoveUserFromRole(username, "Unverified")
        End If
        Response.Redirect("~/Admin/NewUsers.aspx")
    End Sub
End Class
