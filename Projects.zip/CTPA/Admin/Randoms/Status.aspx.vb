Imports System.Security.Cryptography
Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data
Partial Class AADTOnline_Randoms_Status
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Label1.Text = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.BatchID")
            GridView1.DataBind()
        End If
    End Sub

    Protected Sub ShowBatch(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        Dim index As Integer = Convert.ToInt32(e.CommandArgument)

        ' Get the last name of the selected author from the appropriate
        ' cell in the GridView control
        Dim selectedRow As GridViewRow = GridView2.Rows(index)
        Dim Cell As TableCell = selectedRow.Cells(1)
        Label1.Text = Cell.Text
        GridView1.DataBind()
    End Sub
End Class
