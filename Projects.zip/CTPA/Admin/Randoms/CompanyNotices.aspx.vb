
Partial Class AADTOnline_Randoms_CompanyNotices
    Inherits System.Web.UI.Page

End Class
