Imports System.Security.Cryptography
Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data
Imports RenewalStatementWebSvc.ReportingService2005
Imports microsoft.reporting.webforms

Partial Class Default2
    Inherits System.Web.UI.Page
    

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("Notices.aspx")
    End Sub


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            btnYes.Visible = False
            btnNo.Visible = False
            ReportViewer1.Visible = False
            Dim grv As GridViewRow
            Dim rndid As Integer
            Dim Pulled As Boolean
            Dim sqlStatement As String
            For Each grv In GridView1.Rows
                rndid = grv.Cells(3).Text
                sqlStatement = "SELECT BATCHID FROM dbo.BATCH_DATE_TBL WHERE (RNDGRPID = " & rndid & ") AND (BATCHDATE > DATEADD(d, - 60, GETDATE()))"
                Pulled = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sqlStatement)
                If Pulled Then
                    grv.Cells(0).Enabled = False
                    grv.Cells(1).Enabled = True
                    grv.Cells(2).Enabled = False
                Else
                    grv.Cells(0).Enabled = True
                    grv.Cells(1).Enabled = False
                    grv.Cells(2).Enabled = True
                End If
            Next
        End If
    End Sub

    Protected Sub btnViewReport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnViewReport.Click
        If btnViewReport.Text = "View Report" Then
            ReportViewer1.Visible = True
            btnViewReport.Text = "Hide Report"
        Else
            ReportViewer1.Visible = False
            btnViewReport.Text = "View Report"
        End If
    End Sub

    Sub GridClick(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        Dim index As Integer = Convert.ToInt32(e.CommandArgument)
        Dim selectedRow As GridViewRow = GridView1.Rows(index)
        Dim QtyNeeded As Integer
        Dim Group As String

        Group = selectedRow.Cells(3).Text
        'QtyNeeded = Convert.ToInt32(selectedRow.Cells(12).Text)
        Dim txtQty As TextBox
        txtQty = selectedRow.Cells(2).Controls(1)
        QtyNeeded = Convert.ToInt32(txtQty.Text)
        If e.CommandName = "Pull" Then
            Try
                Dim DriversNeeded As Integer
                Dim PullID As Integer
                Dim BatchID As Integer
                Dim txtQtyNeedeed As TextBox = selectedRow.Cells(2).Controls(1)
                DriversNeeded = Convert.ToInt32(txtQtyNeedeed.Text)
                Dim prams(1) As SqlParameter
                prams(0) = New SqlParameter("@DriversNeeded", SqlDbType.Int)
                prams(0).Value = DriversNeeded
                prams(1) = New SqlParameter("@RNDGRPID", SqlDbType.Int)
                prams(1).Value = Convert.ToInt32(selectedRow.Cells(3).Text)
                Group = Convert.ToInt32(selectedRow.Cells(3).Text)
                PullID = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.PullRandoms", prams)
                Dim prams2(1) As SqlParameter
                prams2(0) = New SqlParameter("@PullID", SqlDbType.BigInt)
                prams2(0).Value = PullID
                SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.NextBatch", prams2)
                BatchID = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.WriteHistory", prams2)
                Dim prams3(1) As SqlParameter
                prams3(0) = New SqlParameter("@PullID", SqlDbType.BigInt)
                prams3(0).Value = PullID
                prams3(1) = New SqlParameter("@BatchID", SqlDbType.BigInt)
                prams3(1).Value = BatchID
                SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.UpdateRandomBatch", prams3)
                Dim Sql As String = "Insert Into BatchLog (BatchID, DateCreated, FirstNotice, SecondNotice, FinalNotice, BackedOut) Values (" & BatchID & ", Getdate(), 'False', 'False', 'False', 'False')"
                SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, Sql)
                'msgLabel.Text = "SUCCESSFULLY PULLED " & DriversNeeded & " RANDOMS FROM POOL " & selectedRow.Cells(3).Text
                Response.Redirect("PullRandoms.aspx")
            Catch

            End Try
        ElseIf e.CommandName = "Backout" Then
            msgLabel.Text = "Are you sure you wish to back out the last batch for group: "
            btnYes.Visible = True
            btnNo.Visible = True
            lblRndid.Text = Group
        End If
    End Sub

    Protected Sub btnYes_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnYes.Click
        Dim Sql As String
        Dim BatchID As String
        Dim prams(1) As SqlParameter
        prams(0) = New SqlParameter("@GroupID", SqlDbType.Int)
        prams(0).Value = Convert.ToInt32(lblRndid.Text)
        BatchID = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.BackoutBatch", prams)
        Sql = "Update BatchLog Set BackedOut = 'True', BackOutReason = 'Batch Backed Out' Where BatchID = " & BatchID
        SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, Sql)
        'msgLabel.Text = "Successfully backed out Batch " & BatchID
        Response.Redirect("PullRandoms.aspx")
    End Sub

    Protected Sub btnNo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNo.Click
        Response.Redirect("PullRandoms.aspx")
    End Sub

    Protected Sub GridView1_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.DataBound
        Dim gvr As GridViewRow
        Dim txtQty As TextBox
        Dim lblQty As Label
        For Each gvr In GridView1.Rows
            lblQty = gvr.Cells(12).Controls(1)
            txtQty = gvr.Cells(2).Controls(1)
            txtQty.Text = lblQty.Text
        Next
    End Sub

End Class
