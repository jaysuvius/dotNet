Imports System.Security.Cryptography
Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data

Partial Class Admin_Randoms_Notices2
    Inherits System.Web.UI.Page
    Protected Sub PrintNotices(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        Dim BatchID As Integer
        Dim GroupID As Integer
        Dim Report As String
        Dim ReportLength As Integer
        Dim ReportName As String
        Dim CompID As String = Profile.CompID
        Dim UserID As String = Profile.UserName
        Dim Notice As String
        Dim Description As String
        Dim Reason As String
        Dim OutputFile As String
        Dim FileName As String
        Dim sql As String
        Dim Printed As Date
        Dim index As Integer = Convert.ToInt32(e.CommandArgument)

        ' cell in the GridView control
        Dim selectedRow As GridViewRow = GridView1.Rows(index)
        Dim BatchCell As TableCell = selectedRow.Cells(4)
        Dim GroupCell As TableCell = selectedRow.Cells(6)
        BatchID = BatchCell.Text
        GroupID = GroupCell.Text
        Dim FileList As List(Of String) = New List(Of String)
        Session("BatchID") = BatchID

        Select Case e.CommandName
            Case "first"
                'If reports have been not been generated for the batch, generate then redirect to pdf view page
                sql = "Select DATE_PRINTED from REPORT_TRACKER Where BatchID = " & BatchID & " And REASON_PRINT = 'First Notice'"
                Printed = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sql)
                sql = "Update BatchLog Set FirstNotice = 'True' Where BatchID  = " & BatchID
                SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sql)
                If Printed < "1/1/1900" Then
                    Notice = "1"
                    If GroupID = 1 Or GroupID = 2 Or GroupID = 3 Then
                        'Generate first third of batch
                        Report = CDataFunctions.SelectReport(GroupID, 1) & "1"
                        ReportLength = Len(Report)
                        ReportName = Right(Report, (ReportLength - 1))
                        Description = "Batch " & BatchID & " Notice1"
                        Reason = "First Notice Half"
                        Dim pdf As CTPA.Common.PDFWrapper
                        pdf = New CTPA.Common.PDFWrapper
                        pdf.RenderPdfNotice(CompID, UserID, Notice, Description, Reason, BatchID, Report, ReportName, False)

                        'generate 2nd third of batch
                        Report = CDataFunctions.SelectReport(GroupID, 1) & "2"
                        ReportLength = Len(Report)
                        ReportName = Right(Report, (ReportLength - 1))
                        Dim pdf2 As CTPA.Common.PDFWrapper
                        pdf2 = New CTPA.Common.PDFWrapper
                        Description = "Batch " & BatchID & " Notice2"
                        Reason = "First Notice Half"
                        pdf2.RenderPdfNotice(CompID, UserID, Notice, Description, Reason, BatchID, Report, ReportName, False)

                        'generate 3nd third of batch
                        Report = CDataFunctions.SelectReport(GroupID, 1) & "3"
                        ReportLength = Len(Report)
                        ReportName = Right(Report, (ReportLength - 1))
                        Dim pdf3 As CTPA.Common.PDFWrapper
                        pdf3 = New CTPA.Common.PDFWrapper
                        Description = "Batch " & BatchID & " Notice3"
                        Reason = "First Notice Half"
                        pdf3.RenderPdfNotice(CompID, UserID, Notice, Description, Reason, BatchID, Report, ReportName, False)


                        'Merge 3 files together
                        Dim sqlcon As New SqlClient.SqlConnection
                        sqlcon.ConnectionString = CTPA.Common.Config.ConnectionString

                        'Loop through dataset for filenames to merge
                        sql = "Select * from REPORT_TRACKER Where BatchID = " & BatchID & " And REASON_PRINT = 'First Notice Half'"

                        Dim da2 As New SqlClient.SqlDataAdapter(sql, sqlcon)
                        Dim CB As New SqlClient.SqlCommandBuilder(da2)

                        Dim ds As New Data.DataSet
                        Dim dr As DataRow
                        da2.Fill(ds, "Test")

                        For Each dr In ds.Tables(0).Rows
                            FileList.Add(dr("FILE_PATH"))
                        Next

                        'Merge PDF's and write history
                        Report = Right(Report, (Len(Report) - 1))
                        Report = Left(Report, (Len(Report) - 1))
                        FileName = BatchID & "_" & Report & "_" & Guid.NewGuid.ToString & ".pdf"
                        OutputFile = ConfigurationSettings.AppSettings("NoticePath") & FileName
                        CDataFunctions.MergePdfFiles(FileList, OutputFile)
                        Description = "Batch " & BatchID & " First Notice"
                        Reason = "First Notice"
                        sql = "Delete from REPORT_TRACKER Where BatchID = " & BatchID & " And REASON_PRINT = 'First Notice Half'"
                        WriteHistory(FileName, CompID, UserID, Description, Reason, OutputFile, Today(), BatchID, Notice)

                        'Delete partial notices
                        SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sql)
                        'da2.Update(ds, "Test")

                        'Generate Passports for Batch
                        Report = CDataFunctions.SelectPassport(1)
                        ReportLength = Len(Report)
                        ReportName = Right(Report, (ReportLength - 1))
                        Description = "Batch " & BatchID & " Passports"
                        Reason = "First Passports"
                        Dim pdf4 As CTPA.Common.PDFWrapper
                        pdf4 = New CTPA.Common.PDFWrapper
                        pdf4.RenderPdfNotice(CompID, UserID, Notice, Description, Reason, BatchID, Report, ReportName, True)

                    Else
                        'Generate full batch first notices
                        Report = CDataFunctions.SelectReport(GroupID, 1)
                        ReportLength = Len(Report)
                        ReportName = Right(Report, (ReportLength - 1))
                        Dim pdf As CTPA.Common.PDFWrapper
                        pdf = New CTPA.Common.PDFWrapper
                        Description = "Batch " & BatchID & " First Notice"
                        Reason = "First Notice"
                        pdf.RenderPdfNotice(CompID, UserID, Notice, Description, Reason, BatchID, Report, ReportName, False)

                        'Generate associated passports
                        Report = CDataFunctions.SelectPassport(1)
                        ReportLength = Len(Report)
                        ReportName = Right(Report, (ReportLength - 1))
                        Description = "Batch " & BatchID & " Passports"
                        Reason = "First Passports"
                        Dim pdf2 As CTPA.Common.PDFWrapper
                        pdf2 = New CTPA.Common.PDFWrapper
                        pdf2.RenderPdfNotice(CompID, UserID, Notice, Description, Reason, BatchID, Report, ReportName, True)
                        Session("BatchID") = BatchID
                        Response.Redirect("PrintNotices.aspx")
                    End If
                Else
                    'Redirect to notice printing page
                    Session("BatchID") = BatchID
                    Response.Redirect("PrintNotices.aspx")
                End If
            Case "second"
                Notice = "2"
                sql = "Update BatchLog Set SecondNotice = 'True' Where BatchID  = " & BatchID
                SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sql)
                sql = "Select DATE_PRINTED from REPORT_TRACKER Where BatchID = " & BatchID & " And NOTICE = 2"
                Printed = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sql)
                If Printed < "1/1/1900" Then
                    'Generate 2nd Notices half
                    Report = CDataFunctions.SelectReport(GroupID, 2) & "1"
                    ReportLength = Len(Report)
                    ReportName = Right(Report, (ReportLength - 1))
                    Description = "Batch " & BatchID & " Notice2"
                    Reason = "Second Notice Half"
                    Dim pdf As CTPA.Common.PDFWrapper
                    pdf = New CTPA.Common.PDFWrapper
                    pdf.RenderPdfNotice(CompID, UserID, Notice, Description, Reason, BatchID, Report, ReportName, False)

                    Report = CDataFunctions.SelectReport(GroupID, 2) & "2"
                    ReportLength = Len(Report)
                    ReportName = Right(Report, (ReportLength - 1))
                    Description = "Batch " & BatchID & " Notice2"
                    Reason = "Second Notice Half"
                    Dim pdf5 As CTPA.Common.PDFWrapper
                    pdf5 = New CTPA.Common.PDFWrapper
                    pdf5.RenderPdfNotice(CompID, UserID, Notice, Description, Reason, BatchID, Report, ReportName, False)

                    sql = "Select * from REPORT_TRACKER Where BatchID = " & BatchID & " And REASON_PRINT = 'Second Notice Half'"

                    Dim sqlcon As New SqlClient.SqlConnection
                    sqlcon.ConnectionString = CTPA.Common.Config.ConnectionString
                    Dim da2 As New SqlClient.SqlDataAdapter(sql, sqlcon)
                    Dim CB As New SqlClient.SqlCommandBuilder(da2)

                    Dim ds As New Data.DataSet
                    Dim dr As DataRow
                    da2.Fill(ds, "Test")

                    For Each dr In ds.Tables(0).Rows
                        FileList.Add(dr("FILE_PATH"))
                    Next

                    'Merge PDF's and write history
                    Report = Right(Report, (Len(Report) - 1))
                    Report = Left(Report, (Len(Report) - 1))
                    FileName = BatchID & "_" & Report & "_" & Guid.NewGuid.ToString & ".pdf"
                    OutputFile = ConfigurationSettings.AppSettings("NoticePath") & FileName
                    CDataFunctions.MergePdfFiles(FileList, OutputFile)
                    Description = "Batch " & BatchID & " Second Notice"
                    Reason = "Second Notice"
                    sql = "Delete from REPORT_TRACKER Where BatchID = " & BatchID & " And REASON_PRINT = 'Second Notice Half'"
                    WriteHistory(FileName, CompID, UserID, Description, Reason, OutputFile, Today(), BatchID, Notice)

                    'Delete partial notices
                    SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sql)
                    'da2.Update(ds, "Test")

                    'Generate 2nd alcohol notices
                    Report = CDataFunctions.SelectAlcReport(GroupID, 2)
                    ReportLength = Len(Report)
                    ReportName = Right(Report, (ReportLength - 1))
                    Description = "Batch " & BatchID & " Second Notice Alcohol"
                    Reason = "Second Notice Alcohol"
                    Dim pdf2 As CTPA.Common.PDFWrapper
                    pdf2 = New CTPA.Common.PDFWrapper
                    pdf.RenderPdfNotice(CompID, UserID, Notice, Description, Reason, BatchID, Report, ReportName, False)

                    'Generate 2nd Notice Passports
                    Report = CDataFunctions.SelectPassport(2)
                    ReportLength = Len(Report)
                    ReportName = Right(Report, (ReportLength - 1))
                    Description = "Batch " & BatchID & " Passports"
                    Reason = "Second Passports"
                    Dim pdf3 As CTPA.Common.PDFWrapper
                    pdf3 = New CTPA.Common.PDFWrapper
                    pdf.RenderPdfNotice(CompID, UserID, Notice, Description, Reason, BatchID, Report, ReportName, True)

                    'Generate 2nd Notice Alcohol Passports
                    Report = CDataFunctions.SelectAlcPassport(2)
                    ReportLength = Len(Report)
                    ReportName = Right(Report, (ReportLength - 1))
                    Description = "Batch " & BatchID & " Passports Alcohol"
                    Reason = "Second Passports Alcohol"
                    Dim pdf4 As CTPA.Common.PDFWrapper
                    pdf4 = New CTPA.Common.PDFWrapper
                    pdf.RenderPdfNotice(CompID, UserID, Notice, Description, Reason, BatchID, Report, ReportName, True)

                    'Tag 2nd notice batch and write date to BATCH_DATE_TBL
                    Dim prams(1) As SqlParameter
                    prams(0) = New SqlParameter("@BatchID", SqlDbType.Int)
                    prams(0).Value = Session("BatchID")
                    SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.SecondNoticeTag", prams)
                    'Session("ConfirmMessage") = "SUCCESSFULLY EXPORTED BATCH " & BatchID & " TO PDF"
                    'Response.Redirect("Confirm.aspx")
                    Session("BatchID") = BatchID
                    Response.Redirect("PrintSecondNotices.aspx")
                Else
                    Session("BatchID") = BatchID
                    Response.Redirect("PrintSecondNotices.aspx")
                End If
            Case "final"
                sql = "Update BatchLog Set FinalNotice = 'True' Where BatchID  = " & BatchID
                SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sql)
                sql = "Select DATE_PRINTED from REPORT_TRACKER Where BatchID = " & BatchID & " And NOTICE = 3"
                Printed = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sql)
                If Printed < "1/1/1900" Then
                    'Generate Final Notices
                    Notice = "3"
                    Report = CDataFunctions.SelectReport(GroupID, 3)
                    ReportLength = Len(Report)
                    ReportName = Right(Report, (ReportLength - 1))
                    Description = "Batch " & BatchID & " Final Notice"
                    Reason = "Final Notice"
                    Dim pdf As CTPA.Common.PDFWrapper
                    pdf = New CTPA.Common.PDFWrapper
                    pdf.RenderPdfNotice(CompID, UserID, Notice, Description, Reason, BatchID, Report, ReportName, False)

                    'Generate Final Alcohol Notices
                    Report = CDataFunctions.SelectAlcReport(GroupID, 3)
                    ReportLength = Len(Report)
                    ReportName = Right(Report, (ReportLength - 1))
                    Description = "Batch " & BatchID & " Final Notice Alcohol"
                    Reason = "Final Notice Alcohol"
                    Dim pdf2 As CTPA.Common.PDFWrapper
                    pdf2 = New CTPA.Common.PDFWrapper
                    pdf.RenderPdfNotice(CompID, UserID, Notice, Description, Reason, BatchID, Report, ReportName, False)

                    'Generate Final Passports
                    Report = CDataFunctions.SelectPassport(3)
                    ReportLength = Len(Report)
                    ReportName = Right(Report, (ReportLength - 1))
                    Description = "Batch " & BatchID & " Passports"
                    Reason = "Final Passports"
                    Dim pdf3 As CTPA.Common.PDFWrapper
                    pdf3 = New CTPA.Common.PDFWrapper
                    pdf.RenderPdfNotice(CompID, UserID, Notice, Description, Reason, BatchID, Report, ReportName, True)


                    Report = CDataFunctions.SelectAlcPassport(3)
                    ReportLength = Len(Report)
                    ReportName = Right(Report, (ReportLength - 1))
                    Description = "Batch " & BatchID & " Passports Alcohol"
                    Reason = "Final Passports Alcohol"
                    Dim pdf4 As CTPA.Common.PDFWrapper
                    pdf4 = New CTPA.Common.PDFWrapper
                    pdf.RenderPdfNotice(CompID, UserID, Notice, Description, Reason, BatchID, Report, ReportName, True)


                    Dim prams(1) As SqlParameter
                    prams(0) = New SqlParameter("@BatchID", SqlDbType.Int)
                    prams(0).Value = Session("BatchID")
                    SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.NRTag", prams)
                    Session("BatchID") = BatchID
                    Response.Redirect("PrintFinalNotices.aspx")
                Else
                    Session("BatchID") = BatchID
                    Response.Redirect("PrintFinalNotices.aspx")
                End If
            Case "BackOut"
                btnYes.Visible = True
                btnNo.Visible = True
                lblSure.Visible = True
        End Select
        'Session("BatchID") = BatchID
        'Response.Redirect("PrintNotices.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            If Month(Today) >= 1 And Month(Today) <= 3 Then
                rdoQuarters.Items(0).Selected = True
                ReportViewer1.ServerReport.ReportPath = "/BMSQ1"
            Else
                If Month(Today) >= 4 And Month(Today) <= 6 Then
                    rdoQuarters.Items(1).Selected = True
                    ReportViewer1.ServerReport.ReportPath = "/BMSQ2"
                Else
                    If Month(Today) >= 7 And Month(Today) <= 9 Then
                        rdoQuarters.Items(2).Selected = True
                        ReportViewer1.ServerReport.ReportPath = "/BMSQ3"
                    Else
                        If Month(Today) >= 10 And Month(Today) <= 12 Then
                            rdoQuarters.Items(3).Selected = True
                            ReportViewer1.ServerReport.ReportPath = "/BMSQ4"
                        Else
                            rdoQuarters.Items(4).Selected = True
                            ReportViewer1.ServerReport.ReportPath = "/BMSTotal"
                        End If
                    End If
                End If
            End If
        End If
        Dim grv As GridViewRow
        Dim BatchID As Integer
        Dim FirstNotice As Boolean
        Dim SecondNotice As Boolean
        Dim FinalNotice As Boolean
        Dim sqlStatement As String
        For Each grv In GridView1.Rows
            BatchID = Convert.ToInt32(grv.Cells(4).Text)
            sqlStatement = "SELECT FirstNotice FROM dbo.BatchLog WHERE (BatchID = " & BatchID & ")"
            FirstNotice = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sqlStatement)
            sqlStatement = "SELECT SecondNotice FROM dbo.BatchLog WHERE (BatchID = " & BatchID & ")"
            SecondNotice = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sqlStatement)
            sqlStatement = "SELECT FinalNotice FROM dbo.BatchLog WHERE (BatchID = " & BatchID & ")"
            FinalNotice = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sqlStatement)
            If FirstNotice Then
                grv.Cells(0).BackColor = Drawing.Color.OrangeRed
            Else
                grv.Cells(0).BackColor = Drawing.Color.Lime
            End If
            If SecondNotice Then
                grv.Cells(1).BackColor = Drawing.Color.OrangeRed
            Else
                grv.Cells(1).BackColor = Drawing.Color.Lime
            End If
            If FinalNotice Then
                grv.Cells(2).BackColor = Drawing.Color.OrangeRed
            Else
                grv.Cells(2).BackColor = Drawing.Color.Lime
            End If
            If Not FirstNotice Then
                grv.Cells(1).Enabled = False
                grv.Cells(2).Enabled = False
            Else
                If Not SecondNotice Then
                    grv.Cells(2).Enabled = False
                End If
            End If
        Next
        btnYes.Visible = False
        btnNo.Visible = False
        lblSure.Visible = False
    End Sub

    Protected Sub rdoQuarters_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdoQuarters.SelectedIndexChanged
        If rdoQuarters.Items(0).Selected Then
            ReportViewer1.ServerReport.ReportPath = "/BMSQ1"
        Else
            If rdoQuarters.Items(1).Selected Then
                ReportViewer1.ServerReport.ReportPath = "/BMSQ2"
            Else
                If rdoQuarters.Items(2).Selected Then
                    ReportViewer1.ServerReport.ReportPath = "/BMSQ3"
                Else
                    If rdoQuarters.Items(3).Selected Then
                        ReportViewer1.ServerReport.ReportPath = "/BMSQ4"
                    Else
                        ReportViewer1.ServerReport.ReportPath = "/BMSTotal"
                    End If
                End If
            End If
        End If
    End Sub

    Protected Sub WriteHistory(ByVal Filename, ByVal CompID, ByVal UserID, ByVal Desc, ByVal Reason, ByVal Path, ByVal DateRender, ByVal Batch, ByVal Notice)
        Dim rt As CTPA.Entities.ReportTracker = New CTPA.Entities.ReportTracker
        rt.FILENAME = Filename
        rt.COMP_ID = CompID
        rt.USER_ID = UserID
        rt.REPORT_DESCRIPTION = Desc
        rt.REASON_PRINT = Reason
        rt.FILE_PATH = Path
        rt.DATE_PRINTED = DateRender
        rt.BATCHID = Batch
        rt.NOTICE = Notice
        rt.V_PATH = "/CTPA/Notices/"
        rt.Save()
    End Sub

    Protected Sub btnNo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNo.Click
        Response.Redirect("notices.aspx")
    End Sub

    Protected Sub btnYes_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnYes.Click
        Dim BatchID As Integer
        Dim Notice As Integer
        BatchID = Session("BatchID")
        Dim sql As String
        sql = "select max(notice) from report_tracker where batchid = " & BatchID
        'Notice = Convert.ToInt32(SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sql))
        sql = "Delete from report_tracker where  batchID = " & BatchID & " and Notice = '" & Notice & "'"
        SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sql)
        Select Case Notice
            Case 1
                sql = "Update BatchLog Set FirstNotice = 'False' Where BatchID = " & BatchID
                SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sql)
            Case 2
                sql = "Update BatchLog Set SecondNotice = 'False' Where BatchID = " & BatchID
                SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sql)
                sql = "Update randomize_tbl set warningtag = 'False' where BatchID = " & BatchID
                SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sql)
            Case 3
                sql = "Update BatchLog Set FinalNotice = 'False' Where BatchID = " & BatchID
                SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sql)
                sql = "Update randomize_tbl set nrtag = 'False' where BatchID = " & BatchID
                SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sql)
        End Select
        Response.Redirect("notices.aspx")
    End Sub
End Class
