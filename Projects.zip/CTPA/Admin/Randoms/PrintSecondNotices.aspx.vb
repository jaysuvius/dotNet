Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data

Partial Class Admin_Randoms_PrintNotices
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Label1.Text = "Notices generated for batch: " & Session("BatchID")
            'Dim sourceFilePath As String = ConfigurationSettings.AppSettings("LocalDocumentPath")
            'Literal1.Text = "<EMBED src='" & sourceFilePath & "' width='500' height='500'></EMBED>"
            Dim ReportTitle As String
            'Dim FilePath As String
            Dim index As Integer
            Dim RowCount As Integer
            Dim sqlcon As New SqlClient.SqlConnection
            sqlcon.ConnectionString = CTPA.Common.Config.ConnectionString

            Dim sql As String
            sql = "Select * from REPORT_TRACKER Where BatchID = " & Session("BatchID") & "And Notice = '2'" & "Order By DATE_PRINTED"

            Dim da2 As New SqlClient.SqlDataAdapter(sql, sqlcon)
            Dim CB As New SqlClient.SqlCommandBuilder(da2)

            Dim ds As New Data.DataSet
            Dim dr As DataRow
            da2.Fill(ds, "Reports")

            tabNotices.Tabs.Clear()
            RowCount = ds.Tables(0).Rows.Count
            For Each dr In ds.Tables(0).Rows
                ReportTitle = dr("REASON_PRINT")
                tabNotices.Tabs.Add(New AjaxControlToolkit.TabPanel)
                tabNotices.Tabs(index).HeaderText = ReportTitle
                Dim literal As New LiteralControl()
                literal.ID = "Tab" & index
                literal.Text = "<EMBED src='" & dr("V_PATH") & dr("FILENAME") & "' width='500' height='500'></EMBED>"
                tabNotices.Tabs(index).Controls.Add(literal)
                index += 1
            Next
            If RowCount = 0 Then
                Label1.Text = "No Second Notices Exist for Batch: " & Session("BatchID")
            End If
        End If
    End Sub

  

    Protected Sub GetPDF(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        'Dim DocPath As String 'Local path to document
        'Dim sb As String 'String Builder variable for building the response.write statement to view document

        ''Set up table cell object to use the value of cell to collect path inormation to display document
        'Dim index As Integer = Convert.ToInt32(e.CommandArgument)
        'Dim selectedRow As GridViewRow = GridView1.Rows(index)
        'Dim FileNameCell As TableCell = selectedRow.Cells(6)
        'Dim VPathCell As TableCell = selectedRow.Cells(7)
        'DocPath = FileNameCell.Text & VPathCell.Text & ".pdf"
        'sb = "<script language=javascript>window.open('" & DocPath & "','new_Win');</script>"
        ''Display Document in _Blank target window
        'Response.Write(sb)
    End Sub
End Class
