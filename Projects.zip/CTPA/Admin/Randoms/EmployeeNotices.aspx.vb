
Partial Class AADTOnline_Randoms_EmployeeNotices
    Inherits System.Web.UI.Page

End Class
