
Partial Class Admin_ManageUsers
    Inherits System.Web.UI.Page

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        LoadUser()
        showGrid(False, True)
    End Sub

    Protected Sub TextBox1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Button1_Click(sender, e)
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim filterCompany As Integer
        If Integer.TryParse(TextBox1.Text, filterCompany) Then
            SqlDataSource1.FilterExpression = "COMP_ID=" & filterCompany.ToString
        Else
            SqlDataSource1.FilterExpression = Nothing
        End If
        TextBox1.Text = String.Empty
        showGrid(True, False)
    End Sub

    Private Sub showGrid(ByVal gridVisible As Boolean, ByVal fieldsVisible As Boolean)
        GridView1.Visible = gridVisible
        TextBox2.Visible = fieldsVisible
        TextBox3.Visible = fieldsVisible
        TextBox4.Visible = fieldsVisible
        TextBox5.Visible = fieldsVisible
        TextBox6.Visible = fieldsVisible
        TextBox7.Visible = fieldsVisible
        TextBox8.Visible = fieldsVisible
        TextBox9.Visible = fieldsVisible
        TextBox10.Visible = fieldsVisible
        TextBox11.Visible = fieldsVisible
        TextBox12.Visible = fieldsVisible
        TextBox13.Visible = fieldsVisible
        Label10.Visible = fieldsVisible
        Label11.Visible = fieldsVisible
        Label12.Visible = fieldsVisible
        Label13.Visible = fieldsVisible
        Label1.Visible = fieldsVisible
        Label2.Visible = fieldsVisible
        Label3.Visible = fieldsVisible
        Label4.Visible = fieldsVisible
        Label5.Visible = fieldsVisible
        Label6.Visible = fieldsVisible
        Label7.Visible = fieldsVisible
        Label8.Visible = fieldsVisible
        Button2.Visible = fieldsVisible
        Button3.Visible = fieldsVisible
        Button4.Visible = fieldsVisible
        Label9.visible = False
        button5.visible = False
        Button6.Visible = False
        If gridVisible Then
            GridView1.DataBind()
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not (Page.IsPostBack) Then
            Button2.Focus()
            showGrid(True, False)
        End If
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        'Perform Update
        Dim username As String
        Dim memUser As MembershipUser
        Dim updateProfile As ProfileCommon
        username = GridView1.SelectedRow.Cells(1).Text
        memUser = Membership.GetUser(username)
        updateProfile = Profile.GetProfile(username)
        updateProfile.FullName = TextBox4.Text
        updateProfile.Address1 = TextBox6.Text
        updateProfile.City = TextBox7.Text
        updateProfile.State = TextBox8.Text
        updateProfile.ZIP = TextBox9.Text
        updateProfile.ContactPhoneNum = TextBox10.Text
        updateProfile.ContactPhoneExt = TextBox11.Text
        updateProfile.ContactMobile = TextBox12.Text
        updateProfile.RepID = TextBox13.Text
        updateProfile.Save()
        memUser.Email = TextBox5.Text
        Try
            Membership.UpdateUser(memUser)
        Catch ex As Exception
            CDataFunctions.CatchError(ex.Message, ex.Source, ex.StackTrace, ex.TargetSite, ex.HelpLink, ex.InnerException, ex.GetBaseException())

        End Try
        Button3_Click(sender, e)
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        showGrid(True, False)
    End Sub

    Private Sub LoadUser()
        Dim username As String = GridView1.SelectedRow.Cells(1).Text
        Dim userProfile As ProfileCommon
        userProfile = Profile.GetProfile(username)
        TextBox2.Text = username
        TextBox3.Text = userProfile.CompanyName
        TextBox4.Text = userProfile.FullName
        TextBox5.Text = Membership.GetUser(username).Email
        TextBox6.Text = userProfile.Address1
        TextBox7.Text = userProfile.City
        TextBox8.Text = userProfile.State
        TextBox9.Text = userProfile.ZIP
        TextBox10.Text = userProfile.ContactPhoneNum
        TextBox11.Text = userProfile.ContactPhoneExt
        TextBox12.Text = userProfile.ContactMobile
        TextBox13.Text = userProfile.RepID
    End Sub

    Private Sub DeleteUser()
        Dim username As String = GridView1.SelectedRow.Cells(1).Text
        Dim userProfile As ProfileCommon
        userProfile = Profile.GetProfile(username)
        userProfile.CompanyName = String.Empty
        userProfile.CompID = 0
        userProfile.FullName = String.Empty
        userProfile.Address1 = String.Empty
        userProfile.City = String.Empty
        userProfile.State = String.Empty
        userProfile.ZIP = String.Empty
        userProfile.ContactPhoneNum = String.Empty
        userProfile.ContactPhoneExt = String.Empty
        userProfile.ContactMobile = String.Empty
        userProfile.RepID = String.Empty
        userProfile.Save()
        Membership.DeleteUser(username, True)
        If Roles.IsUserInRole(username, "Unverified") Then
            Roles.RemoveUserFromRole(username, "Unverified")
        End If
        If Roles.IsUserInRole(username, "Verified") Then
            Roles.RemoveUserFromRole(username, "Verified")
        End If
        If Roles.IsUserInRole(username, "WSAdmin") Then
            Roles.RemoveUserFromRole(username, "WSAdmin")
        End If
        If Roles.IsUserInRole(username, "Results") Then
            Roles.RemoveUserFromRole(username, "Results")
        End If
        If Roles.IsUserInRole(username, "Drivers") Then
            Roles.RemoveUserFromRole(username, "Drivers")
        End If
        If Roles.IsUserInRole(username, "Company") Then
            Roles.RemoveUserFromRole(username, "Company")
        End If
        If Roles.IsUserInRole(username, "CDATA") Then
            Roles.RemoveUserFromRole(username, "CDATA")
        End If
        If Roles.IsUserInRole(username, "Superadmin") Then
            Roles.RemoveUserFromRole(username, "Superadmin")
        End If
        CTPA.Common.MembershipTracking.DelWSUser(username)
    End Sub


    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        showGrid(False, False)
        Button5.Visible = True
        Button6.Visible = True
        Label9.Text = "Are you sure you wish to delete the account for " & GridView1.SelectedRow.Cells(1).Text & "?"
        Label9.visible = True
    End Sub


    Protected Sub Button5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button5.Click
        ' Delete the currently selected user
        DeleteUser()
        Button3_Click(sender, e)
    End Sub

    Protected Sub Button6_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button6.Click
        ' Cancel deletion
        Button3_Click(sender, e)
    End Sub

End Class
