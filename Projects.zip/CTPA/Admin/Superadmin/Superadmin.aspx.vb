
Partial Class Admin_Superadmin
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            If Roles.IsUserInRole("Superadmin") Then
            Else
                Try
                    If Not Roles.RoleExists("Superadmin") Then
                        Roles.CreateRole("Superadmin")
                    End If
                    If Not Roles.IsUserInRole("Administrator", "Superadmin") Then
                        Roles.AddUserToRole("Administrator", "Superadmin")
                    End If
                Catch ex As Exception
                    If Membership.GetUser().UserName <> "Administrator" Then
                    Else
                        Throw New Exception("Could not put administrator into necessary roles", ex)
                    End If
                    CDataFunctions.CatchError(ex.Message, ex.Source, ex.StackTrace, ex.TargetSite, ex.HelpLink, ex.InnerException, ex.GetBaseException())
                End Try
                Response.Redirect("~/Login.aspx")
            End If
            loadUsersAndRoles()
        End If
    End Sub

    Private Sub loadUsersAndRoles()
        Dim muc As System.Web.Security.MembershipUserCollection = Membership.GetAllUsers()
        Dim iter As System.Collections.IEnumerator = muc.GetEnumerator()
        iter.Reset()
        While iter.MoveNext()
            Dim username As String = CType(iter.Current, MembershipUser).UserName
            Dim userProfile As ProfileCommon
            userProfile = Profile.GetProfile(username)
            ListBox1.Items.Add(userProfile.CompID & "-" & CType(iter.Current, MembershipUser).UserName)
        End While
        For Each role As String In Roles.GetAllRoles()
            ListBox2.Items.Add(role)
        Next
        ListBox1.SelectedIndex = 0
        ListBox2.SelectedIndex = 0
    End Sub


    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim username As String
        username = Split(ListBox1.SelectedItem.Text, "-", 0)(1).ToString
        If Not Roles.IsUserInRole(username, ListBox2.SelectedItem.Text) Then
            Roles.AddUserToRole(username, ListBox2.Items(ListBox2.SelectedIndex).Text)
            Label1.Text = "User " & ListBox1.Items(ListBox1.SelectedIndex).Text & " added to role " & ListBox2.Items(ListBox2.SelectedIndex).Text
        Else
            Label1.Text = "User " & ListBox1.Items(ListBox1.SelectedIndex).Text & " already in role " & ListBox2.Items(ListBox2.SelectedIndex).Text
        End If
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim username As String
        username = Split(ListBox1.SelectedItem.Text, "-", 0)(1).ToString
        If Roles.IsUserInRole(username, ListBox2.SelectedItem.Text) Then
            Roles.RemoveUserFromRole(username, ListBox2.Items(ListBox2.SelectedIndex).Text)
            Label1.Text = "User " & ListBox1.Items(ListBox1.SelectedIndex).Text & " removed from role " & ListBox2.Items(ListBox2.SelectedIndex).Text
        Else
            Label1.Text = "User " & ListBox1.Items(ListBox1.SelectedIndex).Text & " not yet in role " & ListBox2.Items(ListBox2.SelectedIndex).Text & ", cannot remove"
        End If
    End Sub

    

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim username As String = ListBox1.Items(ListBox1.SelectedIndex).Text
        Dim userProfile As ProfileCommon
        userProfile = Profile.GetProfile(username)
        userProfile.CompanyName = String.Empty
        userProfile.CompID = 0
        userProfile.FullName = String.Empty
        userProfile.Address1 = String.Empty
        userProfile.City = String.Empty
        userProfile.State = String.Empty
        userProfile.ZIP = String.Empty
        userProfile.ContactPhoneNum = String.Empty
        userProfile.ContactPhoneExt = String.Empty
        userProfile.ContactMobile = String.Empty
        userProfile.RepID = String.Empty
        userProfile.Save()
        Membership.DeleteUser(username, True)
        If Roles.IsUserInRole(username, "Unverified") Then
            Roles.RemoveUserFromRole(username, "Unverified")
        End If
        If Roles.IsUserInRole(username, "Verified") Then
            Roles.RemoveUserFromRole(username, "Verified")
        End If
        If Roles.IsUserInRole(username, "WSAdmin") Then
            Roles.RemoveUserFromRole(username, "WSAdmin")
        End If
        If Roles.IsUserInRole(username, "Results") Then
            Roles.RemoveUserFromRole(username, "Results")
        End If
        If Roles.IsUserInRole(username, "Drivers") Then
            Roles.RemoveUserFromRole(username, "Drivers")
        End If
        If Roles.IsUserInRole(username, "Company") Then
            Roles.RemoveUserFromRole(username, "Company")
        End If
        If Roles.IsUserInRole(username, "CDATA") Then
            Roles.RemoveUserFromRole(username, "CDATA")
        End If
        If Roles.IsUserInRole(username, "Superadmin") Then
            Roles.RemoveUserFromRole(username, "Superadmin")
        End If
        CTPA.Common.MembershipTracking.DelWSUser(username)
    End Sub

    
   
    Protected Sub btnEnableRenew_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEnableRenew.Click
        Dim muc As System.Web.Security.MembershipUserCollection = Membership.GetAllUsers()
        Dim iter As System.Collections.IEnumerator = muc.GetEnumerator()
        iter.Reset()
        While iter.MoveNext()
            Dim username As String = CType(iter.Current, MembershipUser).UserName
            Dim userProfile As ProfileCommon
            userProfile = Profile.GetProfile(username)
            If Not Roles.IsUserInRole(username, "Renewal") Then
                Roles.AddUserToRole(username, "Renewal")
            End If

        End While

    End Sub
End Class
