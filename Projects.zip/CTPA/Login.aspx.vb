
''' <summary>
''' This form is the central access point for all web site members to log in, which includes the administrators
''' 
''' </summary>
''' <remarks></remarks>
Partial Class Login
    Inherits System.Web.UI.Page


    ''' <summary>
    ''' The page load event of the login form checks the set up of the application, redirects users who are already logged in,
    ''' and verifies that cookies are enabled for users who are not logged in.
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Login1.CreateUserText = "Don't have a login for " & CTPA.Common.Config.ProgramName & "?  Click Here!"    
        CTPA.Common.Config.checkRoles()
        redirectUser()
        checkJavaScript()
        checkCookies()    
    End Sub

    ''' <summary>
    ''' This function passes on the authentication to the membership provider of the .net framework.  On successful login, this function 
    ''' redirects the user back to the same page so that .
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Login1_Authenticate(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.AuthenticateEventArgs) Handles Login1.Authenticate
        ' Log the user in and redirect them to this same page, which will redirect them to the appropriate screen
        If Membership.ValidateUser(Login1.UserName, Login1.Password) Then
            FormsAuthentication.SetAuthCookie(Login1.UserName, False)
            Response.Redirect("Login.aspx")
        End If
    End Sub


    ''' <summary>
    ''' Redirects the user to the appropriate page if they are logged in
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub redirectUser()
        Dim currentUser As System.Web.Security.MembershipUser
        currentUser = Membership.GetUser(HttpContext.Current.User.Identity.Name)
        If Not (currentUser Is Nothing) Then
            If Request.QueryString("newLogin") = "True" Then
                Response.Redirect("Logout.aspx")
            ElseIf Roles.IsUserInRole(currentUser.UserName, "Unverified") Then
                Response.Redirect("~/Unverified/")
            ElseIf Roles.IsUserInRole(currentUser.UserName, "CDATA") Then
                Response.Redirect("~/Admin/")
            ElseIf Roles.IsUserInRole(currentUser.UserName, "Download") Then
                Response.Redirect("~/Forms/")
            ElseIf Roles.IsUserInRole(currentUser.UserName, "AccountRep") Then
                Response.Redirect("~/Dashboard/")
            ElseIf Roles.IsUserInRole(currentUser.UserName, "Broker") Then
                Response.Redirect("~/Broker/Default.aspx")
            ElseIf Roles.IsUserInRole(currentUser.UserName, "Verified") Then
                Response.Redirect("~/AADTOnline/")
            End If
        End If
    End Sub

    ''' <summary>
    ''' Checks that cookies are enabled and warns the user
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub checkCookies()
        If Not Page.IsPostBack Then
            'Check whether cookies are enabled
            If Request.QueryString("Trying") = "" Then
                ' this is the first time this page has been called
                ' set a cookie and redirect to this same page
                Response.SetCookie(New System.Web.HttpCookie("TryingCookie", "ON"))
                Response.Redirect(Request.ServerVariables("URL") & "?Trying=ON")
            Else
                ' we got here because of the redirection
                If (Request.Cookies("TryingCookie") Is Nothing) OrElse (Request.Cookies("TryingCookie").Value() = "") Then
                    ' cookies aren't supported - display an error message and exit
                    Label1.Text = "Cookies must be enabled for this website to work properly.<br/>Please check your browser settings.<br/>"
                    Label1.ForeColor = Drawing.Color.Red
                    Label1.Visible = True
                Else
                    Label1.Visible = False
                End If
                ' clear the trying cookie (optional)
                Response.SetCookie(New System.Web.HttpCookie("TryingCookie", ""))
            End If

            ' Cookies are enabled, so set the session timeout to 10 minutes
            If Session.IsNewSession Then
                Session.Timeout = 10
            End If
        End If
    End Sub
    ''' <summary>
    ''' Checks that javascript are enabled and warns the user
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub checkJavaScript()
        If Not Page.IsPostBack Then
            'Check whether Javascript is enabled
            If Not (Request.Browser.EcmaScriptVersion().Major >= 1) Then
                ' javascript isnt supported - display an error message and exit
                Label1.Text = "JavaScript and cookies must be enabled for this website to work properly.<br/>Please check your browser settings.<br/>"
                Label1.ForeColor = Drawing.Color.Red
                Label1.Visible = True
            Else
                Label1.Visible = False
            End If
        End If
    End Sub

End Class