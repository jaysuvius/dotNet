
Partial Class Account_ChangePassword
    Inherits System.Web.UI.Page

    Protected Sub ContinuePushButton_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Response.Redirect("/CTPA/Login.aspx")
    End Sub


End Class
