Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data

Partial Class AADTOnline_SuperDER_Default
    Inherits System.Web.UI.Page

    Public DERID As Integer
    Public SuperID As Integer
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            lblNotice.Visible = False
            btnAddRec.Visible = False
            ShowGrid(True)
        End If
    End Sub

    Protected Sub EditDER(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName = "GetRecord" Then
            Dim index As Integer = Convert.ToInt32(e.CommandArgument)

            ' Get the last name of the der from the appropriate
            ' cell in the GridView control
            Dim selectedRow As GridViewRow = DERGridView.Rows(index)
            Dim Cell As TableCell = selectedRow.Cells(6)
            ShowGrid(False)
            DERID = Cell.Text

            Dim da As New CTPADataSetTableAdapters.DER_TBLTableAdapter
            Dim ds As New CTPADataSet.DER_TBLDataTable

            da.FillByDER(ds, DERID)

            Dim dr As Data.DataRow
            dr = ds.Rows(0)

            lblDerID.Text = dr("DERAUTOID").ToString
            txtFirst.Text = dr("DERFIRSTNAME").ToString
            txtLast.Text = dr("DERLASTNAME").ToString
            txtMiddle.Text = dr("DERMIDNAME").ToString
            txtTitle.Text = dr("DERTITLENAME").ToString
            If dr("PRIMARYDER") = True Then
                chkPrimary.Checked = True
            Else
                chkPrimary.Checked = False
            End If
            Dim sql As String = "Select Pending from WS_UPDATES where ChangeRecordKey = '" & DERID & "' and Pending = 'True'"
            Dim pending As Boolean
            pending = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, sql)
            If pending Then
                lblUndo.Visible = True
                btnYes.Visible = True
                btnNo.Visible = True
                btnUpdate.Enabled = False
                btnCancel.Enabled = False
                txtFirst.Enabled = False
                txtLast.Enabled = False
                txtMiddle.Enabled = False
                txtTitle.Enabled = False
                chkPrimary.Enabled = False
                lblNotice.Text = "There is already a pending change for this DER"
                lblNotice.Visible = True
                btnDelete.Enabled = False
            Else
                lblUndo.Visible = False
                btnYes.Visible = False
                btnNo.Visible = False
                btnUpdate.Enabled = True
                btnCancel.Enabled = True
                txtFirst.Enabled = True
                txtLast.Enabled = True
                txtMiddle.Enabled = True
                txtTitle.Enabled = True
                chkPrimary.Enabled = True
                lblNotice.Visible = False
                btnDelete.Enabled = True
            End If
        End If
    End Sub

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        ShowGrid(False)
        lblNotice.Visible = False
        btnYes.Visible = False
        btnNo.Visible = False
        lblUndo.Visible = False
        txtFirst.Enabled = True
        txtLast.Enabled = True
        txtMiddle.Enabled = True
        txtTitle.Enabled = True
        chkPrimary.Checked = False
        chkPrimary.Enabled = True
        btnUpdate.Visible = False
        btnAddRec.Visible = True
        txtFirst.Text = ""
        txtLast.Text = ""
        txtMiddle.Text = ""
        txtTitle.Text = ""
        btnCancel.Enabled = True
        Label7.Visible = False
        lblDerID.Visible = False
        btnAddRec.Enabled = True
        btnDelete.Visible = False
    End Sub

    Protected Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Dim newFirst As String = ""
        Dim newLast As String = ""
        Dim newMid As String = ""
        Dim newTitle As String = ""
        Dim newPrimary As Boolean = False
        Dim Changed As Boolean = False
        Dim changeDesc As String = ""

        Dim UpdateCommand As String = ""

        Dim DERID As Integer = lblDerID.Text
        Dim da As New CTPADataSetTableAdapters.DER_TBLTableAdapter
        Dim ds As New CTPADataSet.DER_TBLDataTable

        da.FillByDER(ds, DERID)

        Dim dr As Data.DataRow
        dr = ds.Rows(0)

        If txtFirst.Text <> dr("DERFIRSTNAME").ToString Then
            newFirst = txtFirst.Text
            changeDesc = "=First Name Changed to " & newFirst
            Changed = True
        End If
        If txtLast.Text <> dr("DERLASTNAME").ToString Then
            newLast = txtLast.Text
            changeDesc += " =Last Name Changed to " & newLast
            Changed = True
        End If
        If txtMiddle.Text <> dr("DERMIDNAME").ToString Then
            newMid = txtMiddle.Text
            changeDesc += " =Middle Name Changed to " & newMid
            Changed = True
        End If
        If txtTitle.Text <> dr("DERTITLENAME").ToString Then
            newTitle = txtTitle.Text
            changeDesc += " =Title Name Changed to " & newTitle
            Changed = True
        End If
        If chkPrimary.Checked <> dr("PRIMARYDER") Then
            newPrimary = chkPrimary.Checked
            changeDesc += " =PRIMARYDER Changed to " & newPrimary
            Changed = True
        End If

        If Changed Then
            UpdateCommand = "Update DER_TBL Set DERFIRSTNAME = '" & txtFirst.Text & "', DERLASTNAME = '" & txtLast.Text & "', DERMIDNAME = '" & txtMiddle.Text & "', DERTITLENAME = '" & txtTitle.Text & "', PRIMARYDER = '" & newPrimary & "' where DERAUTOID = " & DERID
            Dim wsu As New CTPA.Entities.WSUpdate
            wsu.Approved = False
            wsu.ChangeDesc = changeDesc
            wsu.ChangeRecordKey = DERID
            wsu.ChangeType = "DER"
            wsu.Pending = True
            wsu.TimeRequested = DateTime.Now
            wsu.TimeCommitted = DateTime.Now
            wsu.UpdateCmd = UpdateCommand
            wsu.username = Profile.UserName
            wsu.Insert()
            txtFirst.Enabled = False
            txtLast.Enabled = False
            txtMiddle.Enabled = False
            txtTitle.Enabled = False
            chkPrimary.Enabled = False
            lblNotice.Visible = True
            btnUpdate.Enabled = False
            btnCancel.Enabled = False
            btnDelete.Enabled = False
            Dim RepID As Integer = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, Data.CommandType.Text, "Select SERVREPID From CALDATA_TBL Where COMP_ID = " & Profile.CompID)
            Dim prams(1) As SqlParameter
            prams(0) = New SqlParameter("@RepID", SqlDbType.Int)
            prams(0).Value = RepID
            prams(1) = New SqlParameter("@ChangeKey", SqlDbType.Int)
            prams(1).Value = DERID
            SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.SetChangeRepID", prams)
        End If

    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        ShowGrid(True)
        btnAddRec.Visible = False
    End Sub

    Protected Sub btnBack_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBack.Click
        ShowGrid(True)
        btnAddRec.Visible = False
    End Sub

    Protected Sub btnYes_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnYes.Click
        SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, "Delete from WS_UPDATES where ChangeRecordKey = " & lblDerID.Text & "AND Pending = 'True'")
        lblNotice.Text = "Pending Change Deleted"
        lblNotice.Visible = True
        ShowGrid(True)
        btnAddRec.Visible = False
    End Sub

    Protected Sub btnNo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNo.Click
        ShowGrid(True)
        btnAddRec.Visible = False
    End Sub

    Sub ShowGrid(ByVal switch As Boolean)
        DERGridView.Visible = switch
        Label1.Visible = switch
        lblTitle.Visible = switch
        lblInstructions.Visible = switch
        Label2.Visible = Not switch
        Label3.Visible = Not switch
        Label4.Visible = Not switch
        Label5.Visible = Not switch
        Label6.Visible = Not switch
        Label7.Visible = Not switch
        lblDerID.Visible = Not switch
        txtFirst.Visible = Not switch
        txtLast.Visible = Not switch
        txtMiddle.Visible = Not switch
        txtTitle.Visible = Not switch
        chkPrimary.Visible = Not switch
        btnUpdate.Visible = Not switch
        btnCancel.Visible = Not switch
        Label1.Text = Profile.CompID
        btnYes.Visible = Not switch
        btnNo.Visible = Not switch
        lblUndo.Visible = Not switch
        lblNotice.Visible = Not switch
        btnAdd.Visible = switch
        btnDelete.Visible = Not switch
    End Sub

    Protected Sub btnAddRec_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddRec.Click
        Dim newFirst As String = txtFirst.Text
        Dim newLast As String = txtLast.Text
        Dim newMid As String = txtMiddle.Text
        Dim newTitle As String = txtTitle.Text
        Dim newPrimary As Boolean = chkPrimary.Checked
        Dim changeDesc As String = "DER Add: By " & Profile.UserName & " On " & Format(Today, "D") & " COMPANY=" & Profile.CompanyName & " FIRSTNAME=" & txtFirst.Text & " LASTNAME=" & txtLast.Text & " MIDDLENAME=" & txtMiddle.Text & " TITLENAME=" & txtTitle.Text & " PRIMARYDER=" & chkPrimary.Checked.ToString


        Dim da As New CTPADataSetTableAdapters.DER_TBLTableAdapter
        Dim ds As New CTPADataSet.DER_TBLDataTable

        da.Fill(ds)
        Dim dr As Data.DataRow
        dr = ds.NewDER_TBLRow
        dr("DERCOMP_ID") = 0
        dr("Approved") = 0
        ds.Rows.Add(dr)
        da.Update(ds)
        Dim newDERID As Integer
        newDERID = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.Text, "Select max(DERAUTOID) FROM DER_TBL where DERCOMP_ID = 0")

        Dim UpdateCommand As String = ""

        UpdateCommand = "Update DER_TBL Set DERCOMP_ID =" & Profile.CompID & ", DERFIRSTNAME = '" & txtFirst.Text & "', DERLASTNAME = '" & txtLast.Text & "', DERMIDNAME = '" & txtMiddle.Text & "', DERTITLENAME = '" & txtTitle.Text & "', PRIMARYDER = '" & newPrimary & "', Approved = 'True' where DERAUTOID = " & newDERID
        Dim wsu As New CTPA.Entities.WSUpdate
        wsu.Approved = False
        wsu.ChangeDesc = changeDesc
        wsu.ChangeRecordKey = newDERID
        wsu.ChangeType = "DER"
        wsu.Pending = True
        wsu.TimeRequested = DateTime.Now
        wsu.TimeCommitted = DateTime.Now
        wsu.UpdateCmd = UpdateCommand
        wsu.username = Profile.UserName
        wsu.Insert()
        txtFirst.Enabled = False
        txtLast.Enabled = False
        txtMiddle.Enabled = False
        txtTitle.Enabled = False
        chkPrimary.Enabled = False
        lblNotice.Visible = True
        btnUpdate.Enabled = False
        btnCancel.Enabled = False
        btnAddRec.Enabled = False
        btnDelete.Enabled = False
        Dim RepID As Integer = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, Data.CommandType.Text, "Select SERVREPID From CALDATA_TBL Where COMP_ID = " & Profile.CompID)
        Dim prams(1) As SqlParameter
        prams(0) = New SqlParameter("@RepID", SqlDbType.Int)
        prams(0).Value = RepID
        prams(1) = New SqlParameter("@ChangeKey", SqlDbType.Int)
        prams(1).Value = newDERID
        SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.SetChangeRepID", prams)
    End Sub

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Dim changeDesc As String = "DER Deletion: By " & Profile.UserName & " On " & Format(Today, "D") & " COMPANY=" & Profile.CompanyName & " FIRSTNAME=" & txtFirst.Text & " LASTNAME=" & txtLast.Text & " MIDDLENAME=" & txtMiddle.Text & " TITLENAME=" & txtTitle.Text
        Dim UpdateCommand As String
        Dim DERID As Integer = lblDerID.Text


        UpdateCommand = "Delete from DER_TBL where DERAUTOID = " & DERID
        Dim wsu As New CTPA.Entities.WSUpdate
        wsu.Approved = False
        wsu.ChangeDesc = changeDesc
        wsu.ChangeRecordKey = DERID
        wsu.ChangeType = "DER"
        wsu.Pending = True
        wsu.TimeRequested = DateTime.Now
        wsu.TimeCommitted = DateTime.Now
        wsu.UpdateCmd = UpdateCommand
        wsu.username = Profile.UserName
        wsu.Insert()
        txtFirst.Enabled = False
        txtLast.Enabled = False
        txtMiddle.Enabled = False
        txtTitle.Enabled = False
        chkPrimary.Enabled = False
        lblNotice.Visible = True
        btnUpdate.Enabled = False
        btnCancel.Enabled = False
        btnAddRec.Enabled = False
        btnDelete.Enabled = False

    End Sub
End Class
