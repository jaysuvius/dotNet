
Partial Class CDATAOnline_drivers_wsadmin
    Inherits System.Web.UI.Page

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        LoadUser()
        showGrid(False, True)
    End Sub


    Private Sub showGrid(ByVal gridVisible As Boolean, ByVal fieldsVisible As Boolean)
        GridView1.Visible = gridVisible
        TextBox2.Visible = fieldsVisible
        TextBox4.Visible = fieldsVisible
        TextBox5.Visible = fieldsVisible
        Label1.Visible = fieldsVisible
        Label3.Visible = fieldsVisible
        Label4.Visible = fieldsVisible
        Button2.Visible = fieldsVisible
        Button3.Visible = fieldsVisible
        CheckBox1.Visible = fieldsVisible
        CheckBox2.Visible = fieldsVisible
        CheckBox3.Visible = fieldsVisible
        CheckBox4.Visible = fieldsVisible
        CheckBox4.Visible = fieldsVisible
        CheckBox5.Visible = fieldsVisible
        If gridVisible Then
            GridView1.DataBind()
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not (Page.IsPostBack) Then
            Button2.Focus()
            showGrid(True, False)
        End If
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        'Perform Update
        Dim username As String
        Dim memUser As MembershipUser
        Dim updateProfile As ProfileCommon
        username = GridView1.SelectedRow.Cells(1).Text
        memUser = Membership.GetUser(username)
        updateProfile = Profile.GetProfile(username)
        updateProfile.FullName = TextBox4.Text
        updateProfile.Save()
        memUser.Email = TextBox5.Text
        Try
            Membership.UpdateUser(memUser)
        Catch ex As Exception
            CDataFunctions.CatchError(ex.Message, ex.Source, ex.StackTrace, ex.TargetSite, ex.HelpLink, ex.InnerException, ex.GetBaseException())
        End Try
        If CheckBox1.Checked Then
            If Not Roles.IsUserInRole(username, "Drivers") Then
                Roles.AddUserToRole(username, "Drivers")
            End If
        Else
            If Roles.IsUserInRole(username, "Drivers") Then
                Roles.RemoveUserFromRole(username, "Drivers")
            End If
        End If
        If CheckBox2.Checked Then
            If Not Roles.IsUserInRole(username, "Company") Then
                Roles.AddUserToRole(username, "Company")
            End If
        Else
            If Roles.IsUserInRole(username, "Company") Then
                Roles.RemoveUserFromRole(username, "Company")
            End If
        End If
        If CheckBox3.Checked Then
            If Not Roles.IsUserInRole(username, "Results") Then
                Roles.AddUserToRole(username, "Results")
            End If
        Else
            If Roles.IsUserInRole(username, "Results") Then
                Roles.RemoveUserFromRole(username, "Results")
            End If
        End If
        If CheckBox4.Checked Then
            If Not Roles.IsUserInRole(username, "Forms") Then
                Roles.AddUserToRole(username, "Forms")
            End If
        Else
            If Roles.IsUserInRole(username, "Forms") Then
                Roles.RemoveUserFromRole(username, "Forms")
            End If
        End If
        If CheckBox5.Checked Then
            If Not Roles.IsUserInRole(username, "Renewal") Then
                Roles.AddUserToRole(username, "Renewal")
            End If
        Else
            If Roles.IsUserInRole(username, "Renewal") Then
                Roles.RemoveUserFromRole(username, "Renewal")
            End If
        End If
        Button3_Click(sender, e)
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        showGrid(True, False)
    End Sub

    Private Sub LoadUser()
        Dim username As String = GridView1.SelectedRow.Cells(1).Text
        Dim userProfile As ProfileCommon
        userProfile = Profile.GetProfile(username)
        TextBox2.Text = username
        TextBox4.Text = userProfile.FullName
        TextBox5.Text = Membership.GetUser(username).Email
        CheckBox1.Checked = Roles.IsUserInRole(username, "Drivers")
        CheckBox2.Checked = Roles.IsUserInRole(username, "Company")
        CheckBox3.Checked = Roles.IsUserInRole(username, "Results")
        CheckBox4.Checked = Roles.IsUserInRole(username, "Forms")
        CheckBox5.Checked = Roles.IsUserInRole(username, "Renewal")

    End Sub

    Private Sub hideUser()
        CheckBox1.Visible = False
        CheckBox2.Visible = False
        CheckBox3.Visible = False
        CheckBox4.Visible = False
        CheckBox5.Visible = False
        TextBox2.Visible = False
        TextBox4.Visible = False
        TextBox5.Visible = False    
        GridView1.Visible = True
        Button2.Visible = False
        Button3.Visible = False
    End Sub


    Private Sub showUser()
        CheckBox1.Visible = True
        CheckBox2.Visible = True
        CheckBox3.Visible = True
        CheckBox4.Visible = True
        CheckBox5.Visible = True
        TextBox2.Visible = True
        TextBox4.Visible = True
        TextBox5.Visible = True
        GridView1.Visible = False
        Button2.Visible = True
        Button3.Visible = True
    End Sub

    Protected Sub gridview1_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If (e.Row.DataItemIndex Mod 2) = 0 Then
                e.Row.BackColor = Drawing.Color.LightGray
            Else
                e.Row.BackColor = Drawing.Color.Gray
            End If
        Else
            If e.Row.RowType = DataControlRowType.Header Then
                e.Row.ForeColor = Drawing.Color.Black
            End If
            e.Row.BackColor = Drawing.Color.SlateGray
        End If
    End Sub

End Class
