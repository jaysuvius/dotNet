Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data

Partial Class ViewCompany
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack() Then
            Dim comp_pending As Integer
            Dim change_pending As String
            Dim prams(0) As SqlParameter
            prams(0) = New SqlParameter("@COMP_ID", SqlDbType.BigInt)
            prams(0).Value = Profile.CompID
            comp_pending = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.COMP_PENDING", prams)
            If comp_pending > 0 Then
                change_pending = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.PENDING_COMP_CHANGE", prams)
                Dim change() = Nothing
                change = Split(change_pending, "=", , CompareMethod.Text)
                Label6.Text = change(0)
                Label7.Text = change(1)
                Label5.Text = "Pending Change for Company: " & Profile.CompID
                Label5.Visible = True
                Label6.Visible = True
                Label7.Visible = True
                Button5.Visible = True
            Else
                Label5.Visible = False
                Label6.Visible = False
                Label7.Visible = False
            End If
            Button1.Focus()
            LoadFields()
            Label3.Text = ""
            If TextBox3.Text = TextBox4.Text AndAlso TextBox5.Text = TextBox8.Text AndAlso TextBox6.Text = TextBox9.Text AndAlso TextBox7.Text = TextBox10.Text Then
                CheckBox1.Checked = True
                CheckBox1_CheckedChanged(sender, e)
            End If
        End If
    End Sub

    Private Sub LoadFields()
        Dim c As New CTPA.Entities.Company(Profile.CompID)
        Label1.Text = Profile.CompID
        Label3.Visible = True
        Button2.Visible = False
        Button3.Visible = False

        If Not (c.COMPANY Is Nothing) Then
            Label2.Text = c.COMPANY
        End If
        TextBox1.Text = c.HOMEPHONE
        TextBox2.Text = c.WORKPHONE
        TextBox3.Text = c.ADDRESS1
        TextBox4.Text = c.ADDRESS2
        TextBox5.Text = c.CITY
        TextBox6.Text = c.STATE
        TextBox7.Text = c.ZIP
        TextBox8.Text = c.CITY2
        TextBox9.Text = c.STATE2
        TextBox10.Text = c.ZIP2
        TextBox11.Text = c.NAME
        'TextBox12.Text = c.CONTACT
        TextBox13.Text = c.FAX
        TextBox14.Text = c.EMERPHONE
        TextBox15.Text = c.CELLPHONE
        TextBox16.Text = c.EMAIL
    End Sub

    Private Function getCompany() As CTPA.Entities.Company
        ' Fill in a company entity based on the form
        Dim c As New CTPA.Entities.Company(Profile.CompID)
        c.HOMEPHONE = TextBox1.Text
        c.WORKPHONE = TextBox2.Text
        c.ADDRESS1 = TextBox3.Text
        c.ADDRESS2 = TextBox4.Text
        c.CITY = TextBox5.Text
        c.STATE = TextBox6.Text
        c.ZIP = TextBox7.Text
        c.CITY2 = TextBox8.Text
        c.STATE2 = TextBox9.Text
        c.ZIP2 = TextBox10.Text
        c.NAME = TextBox11.Text
        'c.CONTACT = TextBox12.Text
        c.FAX = TextBox13.Text
        c.EMERPHONE = TextBox14.Text
        c.CELLPHONE = TextBox15.Text
        c.EMAIL = TextBox16.Text
        Return c
    End Function


    Private Function getUpdateDescription() As String
        Return getCompany.updateDesc
    End Function


    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' First validate the input fields
        TextBox11.Text = CTPA.Common.Validator.capitalizeAllWords(TextBox11.Text)
        'TextBox12.Text = CTPA.Common.Validator.capitalizeAllWords(TextBox12.Text)
        CTPA.Common.Validator.ValidateAddress(TextBox3)
        CTPA.Common.Validator.ValidateCity(TextBox5)
        CTPA.Common.Validator.ValidateState(TextBox6)
        CTPA.Common.Validator.ValidateZIP(TextBox7)
        CTPA.Common.Validator.ValidateAddress(TextBox4)
        CTPA.Common.Validator.ValidateCity(TextBox8)
        CTPA.Common.Validator.ValidateState(TextBox9)
        CTPA.Common.Validator.ValidateZIP(TextBox10)
        CTPA.Common.Validator.ValidatePhone(TextBox1)
        CTPA.Common.Validator.ValidatePhone(TextBox2)
        CTPA.Common.Validator.ValidatePhone(TextBox13)
        CTPA.Common.Validator.ValidatePhone(TextBox14)
        CTPA.Common.Validator.ValidatePhone(TextBox15)

        If TextBox1.Text.Contains(CTPA.Common.Validator.InvalidFieldMarker) OrElse _
                  TextBox2.Text.Contains(CTPA.Common.Validator.InvalidFieldMarker) OrElse _
                  TextBox3.Text.Contains(CTPA.Common.Validator.InvalidFieldMarker) OrElse _
                  TextBox4.Text.Contains(CTPA.Common.Validator.InvalidFieldMarker) OrElse _
                  TextBox5.Text.Contains(CTPA.Common.Validator.InvalidFieldMarker) OrElse _
                  TextBox6.Text.Contains(CTPA.Common.Validator.InvalidFieldMarker) OrElse _
                  TextBox7.Text.Contains(CTPA.Common.Validator.InvalidFieldMarker) OrElse _
                  TextBox8.Text.Contains(CTPA.Common.Validator.InvalidFieldMarker) OrElse _
                  TextBox9.Text.Contains(CTPA.Common.Validator.InvalidFieldMarker) OrElse _
                  TextBox10.Text.Contains(CTPA.Common.Validator.InvalidFieldMarker) OrElse _
                  TextBox13.Text.Contains(CTPA.Common.Validator.InvalidFieldMarker) OrElse _
                  TextBox14.Text.Contains(CTPA.Common.Validator.InvalidFieldMarker) OrElse _
                  TextBox15.Text.Contains(CTPA.Common.Validator.InvalidFieldMarker) Then
            Label3.Text = "Please check input fields for invalid data"
            Label3.Visible = True
            Exit Sub
        End If

        'Save changes button - Build query for company update and save it in a table (WS_Updates) for admin to approve
        Dim c As CTPA.Entities.Company
        c = getCompany()
        ' Check if anything changed
        If c.updateCommand = "" Then
            If c.hasPendingChange() Then
                ' Delete the current change
                Label3.Text = "There is already a change for this company waiting to be approved by " & CTPA.Common.Config.CompanyName & ".  Do you wish to delete this pending change?"
                Button1.Visible = False
                Button2.Visible = True
                Button3.Visible = True
            Else
                Label3.Text = "No changes made to current data."
            End If
        Else
            ' Verify that there are no outstanding changes
            If c.hasPendingChange() Then
                ' There is an outstanding change not yet made
                Label3.Text = "There is already a change for this company waiting to be approved by " & CTPA.Common.Config.ProgramName & ".  Do you wish to overwrite this change?"
                Button1.Visible = False
                Button2.Visible = True
                Button3.Visible = True
            Else
                ' Write a row to WS_Updates indicating what to change
                Dim wsu As New CTPA.Entities.WSUpdate
                wsu.ChangeType = "Company"
                wsu.Approved = False
                wsu.username = Membership.GetUser.UserName
                wsu.ChangeRecordKey = Profile.CompID
                wsu.ChangeDesc = c.updateDesc
                wsu.UpdateCmd = c.updateCommand
                wsu.Pending = True
                wsu.TimeRequested = DateTime.Now()
                'Dim SQLStatement As String
                Try
                    wsu.Insert()
                    Dim RepID As Integer = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, Data.CommandType.Text, "Select SERVREPID From CALDATA_TBL Where COMP_ID = " & Profile.CompID)
                    Dim prams(1) As SqlParameter
                    prams(0) = New SqlParameter("@RepID", SqlDbType.Int)
                    prams(0).Value = RepID
                    prams(1) = New SqlParameter("@ChangeKey", SqlDbType.Int)
                    prams(1).Value = Profile.CompID
                    SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.SetChangeRepID", prams)
                    Label3.Text = "Changes Submitted and are Pending Approval."
                Catch ex As Exception
                    Label3.Text = CTPA.Common.Config.SaveError
                    CDataFunctions.CatchError(ex.Message, ex.Source, ex.StackTrace, ex.TargetSite, ex.HelpLink, ex.InnerException, ex.GetBaseException())
                End Try
            End If
        End If
        If Session("Renewal") = True Then
            Response.Redirect("~/AADTOnline/renewals/default.aspx")
        End If
        Button1.Enabled = False
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Button1.Visible = True
        Button2.Visible = False
        Button3.Visible = False
        Label3.Text = "This change was not saved."
        LoadFields()
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim c As CTPA.Entities.Company = getCompany()
        Try
            Dim wsc As CTPA.Entities.WSUpdate
            wsc = New CTPA.Entities.WSUpdate(Profile.CompID, "Company")
            If c.updateCommand = "" Then
                wsc.Delete()
                Label3.Text = "Pending change deleted."
            Else
                wsc.username = Membership.GetUser.UserName
                wsc.ChangeRecordKey = Profile.CompID
                wsc.Pending = True
                wsc.ChangeDesc = c.updateDesc
                wsc.UpdateCmd = c.updateCommand
                wsc.TimeRequested = DateTime.Now()
                wsc.ChangeType = "Company"
                wsc.Approved = False
                wsc.Update()
                Label3.Text = "Update saved."
            End If
        Catch ex As Exception
            Label3.Text = CTPA.Common.Config.SaveError
            Button1.Visible = True
            Button2.Visible = False
            Button3.Visible = False
            CDataFunctions.CatchError(ex.Message, ex.Source, ex.StackTrace, ex.TargetSite, ex.HelpLink, ex.InnerException, ex.GetBaseException())
            Exit Sub
        End Try
        Button1.Visible = True
        Button2.Visible = False
        Button3.Visible = False
    End Sub




    Protected Sub CheckBox1_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        If CheckBox1.Checked Then
            TextBox4.Text = TextBox3.Text
            TextBox4.Enabled = False
            TextBox8.Text = TextBox5.Text
            TextBox8.Enabled = False
            TextBox9.Text = TextBox6.Text
            TextBox9.Enabled = False
            TextBox10.Text = TextBox7.Text
            TextBox10.Enabled = False
        Else
            TextBox4.Enabled = True
            TextBox8.Enabled = True
            TextBox9.Enabled = True
            TextBox10.Enabled = True
        End If        
    End Sub

    Private Sub capitalize(ByRef tb As TextBox)
        tb.Text = tb.Text.ToUpper.ToCharArray()(0) & tb.Text.Substring(1)
    End Sub


    
    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        If Session("Renewal") = "true" Then
            Response.Redirect("~/AADTOnline/Renewals/Default.aspx")
        Else
            Response.Redirect("~/AADTOnline/Default.aspx")
        End If
    End Sub

    Protected Sub Button5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim prams(0) As SqlParameter
        prams(0) = New SqlParameter("@COMP_ID", SqlDbType.BigInt)
        prams(0).Value = Profile.CompID
        SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.WS_UPDATES_COMP_Delete", prams)
        Button5.Visible = False
        'DataList1.Visible = False
        Label5.Visible = False
        Label6.Visible = False
        Label7.Visible = False
        Label3.Text = "Pending Change Deleted!"
    End Sub
End Class
