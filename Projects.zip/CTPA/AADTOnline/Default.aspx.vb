Imports RenewalStatementWebSvc.ReportingService2005
Imports microsoft.reporting.webforms

Partial Class Verified_Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Label1.Text = "Welcome to " & CTPA.Common.Config.ProgramName & ", " & Profile.FullName()
            'Set up report parameters to send to reporting services for report viewer
            Dim parm1(0) As ReportParameter
            Dim compid As Integer
            compid = Profile.CompID
            parm1(0) = New Microsoft.Reporting.WebForms.ReportParameter("COMP_ID", compid)
            ReportViewer1.ServerReport.SetParameters(parm1)
            ReportViewer1.ShowParameterPrompts = False
            'buildTable()
        End If
    End Sub



    'Private Sub buildTable()
    '    Dim tr As New Web.UI.WebControls.TableRow()
    '    Dim tc As WebControls.TableCell
    '    Dim c As New CTPA.Entities.Company(Profile.CompID)
    '    Dim poolNames As Collections.Specialized.NameValueCollection = CTPA.Common.Config.poolNames
    '    Dim loopCounter As Integer = 0
    '    Dim numTableColumns As Integer = 2
    '    For Each pool As String In poolNames.Keys
    '        Dim poolID As Integer = CTPA.Common.Config.poolNames(pool)
    '        Dim custPools() As Integer = {9, 10, 11, 13, 14, 17, 20}
    '        If Array.BinarySearch(custPools, poolID) < 0 Or pool.Split(" ")(pool.Split(" ").Length - 1).Contains(Profile.CompID.ToString) Then
    '            tc = New WebControls.TableCell()
    '            tc.Text = pool
    '            tc.BorderColor = Drawing.Color.Black
    '            tc.BorderWidth = New System.Web.UI.WebControls.Unit(1)
    '            tc.Width = New System.Web.UI.WebControls.Unit(250)
    '            tr.Cells.Add(tc)
    '            tc = New WebControls.TableCell()
    '            tc.Text = c.getPoolCount(poolNames(pool))
    '            tc.BorderColor = Drawing.Color.Black
    '            tc.BorderWidth = New System.Web.UI.WebControls.Unit(1)
    '            tc.Width = New System.Web.UI.WebControls.Unit(25)
    '            tr.Cells.Add(tc)
    '            loopCounter = loopCounter + 1
    '            If loopCounter Mod numTableColumns <> 0 And loopCounter <> poolNames.Count Then
    '                tc = New WebControls.TableCell()
    '                tc.Text = String.Empty
    '                tc.Width = New System.Web.UI.WebControls.Unit(15)
    '                tr.Cells.Add(tc)
    '            End If
    '            If loopCounter Mod numTableColumns = 0 And loopCounter <> poolNames.Count Then
    '                Table1.Rows.Add(tr)
    '                tr = New Web.UI.WebControls.TableRow()
    '            End If
    '        End If
    '    Next
    '    Table1.Rows.Add(tr)
    'End Sub
End Class
