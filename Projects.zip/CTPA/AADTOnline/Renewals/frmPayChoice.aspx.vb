'***************************************************************
'* PAYMENT CHOICE FORM FOR CTPA COMPANY RENEWAL PROCESSING     *
'* BY JEREMY MAY AND RCS                                       *
'* 1/2008                                                      *
'***************************************************************
Partial Class AADTOnline_Renewals_frmPayChoice
    Inherits System.Web.UI.Page

    ''' <summary>
    ''' This link directs the user to the check payment page.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        'Redirect user to Check Payment Page
        Response.Redirect("PayByCheck.aspx")
    End Sub
    ''' <summary>
    ''' This link directs the user to the credit card payment page
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Redirect user to Credit Card Payment page
        Response.Redirect("PaymentRenewal.aspx")
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Response.Redirect("Default.aspx")
    End Sub
End Class
