'***************************************************************
'* AGREEMENT FORM FOR CTPA COMPANY RENEWAL PROCESSING          *
'* BY JEREMY MAY AND RCS                                       *
'* 1/2008                                                      *
'***************************************************************
Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data
Partial Class AADTOnline_Renewals_frmAgreement
    Inherits System.Web.UI.Page
    Public CommandName As String = Nothing
    Public RowIndex As Integer
    ''' <summary>
    ''' This is cancel button for the form, which sends you back to the renewal default page
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        'Send to Default Renewal Page
        Response.Redirect("default.aspx")
    End Sub

    ''' <summary>
    ''' This is the onrowcommand for the view agreement documents to selece the proper agreement for a pool_id
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub GetForm(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        'Define table cell object to capture value of pool ID
        Dim index As Integer = Convert.ToInt32(e.CommandArgument)
        Dim selectedRow As GridViewRow = GridView2.Rows(index)
        Dim SigID As TableCell = selectedRow.Cells(2)
        Dim Cell As TableCell = selectedRow.Cells(0)
        Dim commandcell As TableCell = selectedRow.Cells(6)
        Dim PoolID As Integer 'Variable to store captured pool ID
        PoolID = Cell.Text
        Select Case e.CommandName
            Case "Edit"
                CommandName = "Edit"
                Select Case PoolID
                    Case "1"
                        Response.Write("<script language=javascript>window.open('http://www.aadrugtesting.com/pdf_doc/serviceAgreement/DOT/Service_Agreement_CD.pdf','new_Win');</script>")
                    Case "2"
                        Response.Write("<script language=javascript>window.open('http://www.aadrugtesting.com/pdf_doc/serviceAgreement/DOT/Service_Agreement_OO.pdf','new_Win');</script>")
                    Case "3"
                        Response.Write("<script language=javascript>window.open('http://www.aadrugtesting.com/pdf_doc/serviceAgreement/DrugFree/Service_Agreement_DrugFree_CE.pdf','new_Win');</script>")
                    Case "4"
                        Response.Write("<script language=javascript>window.open('http://www.aadrugtesting.com/pdf_doc/serviceAgreement/PUC/Service_Agreement_PUC_CD.pdf','new_Win');</script>")
                    Case "5"
                        Response.Write("<script language=javascript>window.open('http://www.aadrugtesting.com/pdf_doc/serviceAgreement/PUC/Service_Agreement_PUC_OO.pdf','new_Win');</script>")
                End Select
                If PoolID = 2 Then
                    ASPNET_MsgBox("By Clicking Save You Are Verifying You Are the Owner Operator")
                End If
            Case "Update"
                If PoolID = 2 Then
                    ASPNET_MsgBox("By Clicking Save You Are Verifying You Are the Owner Operator")
                End If
                CommandName = "Update"
                '    Case "View"
                '        CommandName = "View"
                '        selectedRow.Cells(7).Enabled = True
                '        'Display PDF in new window based on the value of the poolID variable
                '        Select Case PoolID
                '            Case "1"
                '                Response.Write("<script language=javascript>window.open('/CTPA/AADTOnline/Forms/CD.pdf','new_Win');</script>")
                '            Case "2"
                '                Response.Write("<script language=javascript>window.open('/CTPA/AADTOnline/Forms/OO.pdf','new_Win');</script>")
                '            Case "3"
                '                Response.Write("<script language=javascript>window.open('/CTPA/AADTOnline/Forms/CE.pdf','new_Win');</script>")
                '            Case "4"
                '                Response.Write("<script language=javascript>window.open('/CTPA/AADTOnline/Forms/PUCCD.pdf','new_Win');</script>")
                '            Case "5"
                '                Response.Write("<script language=javascript>window.open('/CTPA/AADTOnline/Forms/PUCOO.pdf','new_Win');</script>")
                '        End Select
        End Select
    End Sub

    ''' <summary>
    ''' This is the page load for this page.  It will set label3 and 4 to profile name and comp ID respectively to be used as params
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Set label 4 to be used as company ID parameter
        If Not IsPostBack Then
            Label4.Text = Profile.CompID
            Label3.Text = Profile.FullName
            Dim prams(2) As SqlParameter
            prams(0) = New SqlParameter("@COMP_ID", SqlDbType.BigInt)
            prams(0).Value = Profile.CompID
            prams(1) = New SqlParameter("@DER", SqlDbType.NVarChar)
            prams(1).Value = Profile.FullName
            SqlHelper.ExecuteNonQuery(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.AGREE_POOLS", prams)
            SqlHelper.ExecuteNonQuery(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.SetDer", prams)
        End If
    End Sub

    ''' <summary>
    ''' This button finishes the agreement processing by executing the agree_pools procedure one final time to write the record in the
    ''' renewals table.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim prams(2) As SqlParameter
        prams(0) = New SqlParameter("@COMP_ID", SqlDbType.BigInt)
        prams(0).Value = Profile.CompID
        prams(1) = New SqlParameter("@DER", SqlDbType.NVarChar)
        prams(1).Value = Profile.FullName
        SqlHelper.ExecuteNonQuery(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.AGREE_POOLS", prams)
        Response.Redirect("default.aspx")
    End Sub
    ''' <summary>
    ''' This will disable all the edit buttons in the gridview on databound event
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub SetGrid(ByVal sender As Object, ByVal e As System.EventArgs)
        'If Not Page.IsPostBack Then
        '    Dim r As GridViewRow
        '    For Each r In GridView2.Rows
        '        r.Cells(7).Enabled = False
        '    Next
        'End If
    End Sub
    ''' <summary>
    ''' This will disable all but the selected row on row databound event
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub DisableEdits(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs)
        Dim r As GridViewRow
        If CommandName = "Edit" Then
            RowIndex = GridView2.EditIndex
            For Each r In GridView2.Rows
                If r.RowIndex = RowIndex Then
                    r.Cells(6).Enabled = True
                Else
                    r.Cells(6).Enabled = False
                End If
            Next
        Else
            'For Each r In GridView2.Rows
            '    r.Cells(7).Enabled = False
            'Next
        End If
    End Sub

    Public Sub ASPNET_MsgBox(ByVal Message As String)

        System.Web.HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=""JavaScript"">" & vbCrLf)

        System.Web.HttpContext.Current.Response.Write("alert(""" & Message & """)" & vbCrLf)

        System.Web.HttpContext.Current.Response.Write("</SCRIPT>")

    End Sub
End Class
