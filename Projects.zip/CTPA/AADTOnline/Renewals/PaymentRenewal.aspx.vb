'***************************************************************
'* CREDIT CARD FORM FOR CTPA COMPANY RENEWAL PROCESSING        *
'* BY JEREMY MAY AND RCS                                       *
'* 1/2008                                                      *
'***************************************************************
Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data
Imports RenewalStatementWebSvc.ReportingService2005
Imports microsoft.reporting.webforms

Partial Class AADTOnline_Renewals_PaymentRenewal
    Inherits System.Web.UI.Page
    Public amount_due As Double

    ''' <summary>
    ''' This page load will capture and save a copy of the rendered report to the local machine and timestamp the report tracker table
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim prams(0) As SqlParameter
        prams(0) = New SqlParameter("@COMP_ID", SqlDbType.BigInt)
        prams(0).Value = Profile.CompID
        amount_due = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.GET_TOTAL_FEE_PROC_CC", prams)
        Label2.Text = Format(amount_due, "currency")
        Label11.Text = Profile.CompID
        If Not IsPostBack() Then
            TextBox2.Focus()
            Label5.Visible = False
            Dim strFileName As String = Profile.CompID.ToString() & "_" & Guid.NewGuid.ToString() & ".pdf"
            Dim strFilePath As String = ConfigurationSettings.AppSettings("AppDocumentPath")
            Dim strVPath As String = ConfigurationSettings.AppSettings("AppDocumentViewPath")
            Dim strCompID As String = Profile.CompID.ToString()
            Dim strReportName As String = "/RenewalStatementCC"
            Dim strFullFilePath As String = strFilePath & strFileName
            Dim parm1(0) As ReportParameter
            Dim compid As String
            compid = Profile.CompID.ToString()
            parm1(0) = New Microsoft.Reporting.WebForms.ReportParameter("COMP_ID", compid)
            ReportViewer1.ServerReport.SetParameters(parm1)
            ReportViewer1.ShowParameterPrompts = False
            Dim rt As CTPA.Entities.ReportTracker
            rt = New CTPA.Entities.ReportTracker
            rt.COMP_ID = compid
            rt.USER_ID = Profile.UserName
            rt.DATE_PRINTED = Now()
            rt.REASON_PRINT = "Accessed Credit Card Payment Renewal Statement"
            rt.REPORT_DESCRIPTION = "Renewal Statement"
            rt.FILENAME = strFileName
            rt.FILE_PATH = strFullFilePath
            rt.V_PATH = strVPath
            rt.Save()
            Dim pdf As CTPA.Common.PDFWrapper
            pdf = New CTPA.Common.PDFWrapper
            pdf.RenderPdf(strCompID, strReportName, strFullFilePath)
        End If
    End Sub

    ''' <summary>
    ''' This will direct the user back to the renewal default page
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("default.aspx")
    End Sub

    ''' <summary>
    ''' This button will write the payment information to the renewals table
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If CheckBox1.Checked = False Then
            Label5.Visible = True
        Else
            Label5.Visible = False
            Dim r As CTPA.Entities.Renewal
            r = New CTPA.Entities.Renewal(Profile.CompID)
            r.CC_TYPE = DropDownList1.Text
            r.CC_NUMBER = TextBox2.Text
            r.CC_EXP = CType(TextBox3.Text, Date)
            r.CC_CCV = TextBox8.Text
            r.CC_NAME = TextBox1.Text
            r.CC_ADDRESS = TextBox4.Text
            r.CC_CITY = TextBox5.Text
            r.CC_STATE = TextBox6.Text
            r.CC_ZIP = TextBox7.Text
            r.PAYMENT_RECEIVED_PENDING = DateTime.Now
            r.PAID_ONLINE = True
            r.TOTAL_FEE = amount_due
            r.Save()
            Response.Redirect("default.aspx")
        End If
    End Sub
End Class
