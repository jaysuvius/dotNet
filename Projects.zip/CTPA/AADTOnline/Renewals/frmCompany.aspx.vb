'***************************************************************
'* COMPANY FORM FOR CTPA COMPANY RENEWAL PROCESSING            *
'* BY JEREMY MAY AND RCS                                       *
'* 1/2008                                                      *
'***************************************************************

Imports RenewalStatementWebSvc.ReportingService2005
Imports microsoft.reporting.webforms

Partial Class ViewCompany
    Inherits System.Web.UI.Page

    ''' <summary>
    ''' This is the button that writes the timestamp to the renewals table if the user has verified the company information
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnVerify_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnVerify.Click

        'Define new renewal entity object
        Dim r As CTPA.Entities.Renewal
        r = New CTPA.Entities.Renewal

        'Write timestamp to renewal table
        r.COMP_ID = Profile.CompID
        r.COMP_INFO_CONFIRMED = Today
        r.COMP_INFO_CONFIRMED_by = CTPA.Common.Config.getWSUser().UserName
        r.INFO_APPROVED = False
        r.Save()
        Response.Redirect("default.aspx")
    End Sub

    ''' <summary>
    ''' This is the cancel button that returns the user to the renewals default page
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        'Send back to default page
        Response.Redirect("default.aspx")
    End Sub

    ''' <summary>
    ''' This button sends the user to the edit employee page
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        'Redirect user to ViewCompany Page
        Session("Renewal") = "true"
        Response.Redirect("~/AADTOnline/company/ViewCompany.aspx")
    End Sub

    ''' <summary>
    ''' This is the page load sets the label to be used as the SQL parameter for the report render
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Set up report parameters to send to reporting services for report viewer
        Dim parm1(0) As ReportParameter
        Dim compid As Integer
        compid = Profile.CompID
        parm1(0) = New Microsoft.Reporting.WebForms.ReportParameter("COMP_ID", compid)
        ReportViewer1.ServerReport.SetParameters(parm1)
        ReportViewer1.ShowParameterPrompts = False
    End Sub
End Class
