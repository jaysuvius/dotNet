'***************************************************************
'* RENEWAL DEFAULT FORM FOR CTPA COMPANY RENEWAL PROCESSING    *
'* BY JEREMY MAY AND RCS                                       *
'* 1/2008                                                      *
'***************************************************************
Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data
Imports RenewalStatementWebSvc.ReportingService2005
Imports microsoft.reporting.webforms

Partial Class AADTOnline_Renewals_PayByCheck
    Inherits System.Web.UI.Page
    Public Amount_Due As Decimal
    ''' <summary>
    ''' This module writes the values of the check payment to the renewals table
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If chkAgree.Checked = True Then
            Dim r As CTPA.Entities.Renewal
            r = New CTPA.Entities.Renewal(Profile.CompID)
            r.PAID_ONLINE = False
            r.PAYMENT_RECEIVED_PENDING = Today
            r.CC_TYPE = "Check"
            r.TOTAL_FEE = Amount_Due
            r.CC_TYPE = "Check"
            r.CC_NUMBER = TextBox1.Text
            r.Save()
            Response.Redirect("default.aspx")
        Else
            Label3.Visible = True
        End If
        Dim rt As CTPA.Entities.ReportTracker
        rt = New CTPA.Entities.ReportTracker(Profile.CompID)
        rt.COMP_ID = Profile.CompID
        rt.Update()
    End Sub

    ''' <summary>
    ''' This cancels the current action and redirects the user back to the renewals default page
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("Default.aspx")
    End Sub

    ''' <summary>
    ''' This page load sets saves a copy of the rendered report to the local machine and timestamps the report tracker
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim prams(0) As SqlParameter
        prams(0) = New SqlParameter("@COMP_ID", SqlDbType.BigInt)
        prams(0).Value = Profile.CompID
        Amount_Due = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.GET_TOTAL_FEE_PROC", prams)
        Label5.Text = Format(Amount_Due, "currency")
        'This module captures rendered report and saves it to the appropriate file on web server
        Label1.Text = Profile.CompID
        If Not IsPostBack() Then
            Dim strFileName As String = Profile.CompID.ToString() & "_" & Guid.NewGuid.ToString() & ".pdf" 'Generate unique filename
            Dim strFilePath As String = ConfigurationSettings.AppSettings("AppDocumentPath") 'Get path from webconfig
            Dim strVPath As String = ConfigurationSettings.AppSettings("AppDocumentViewPath")
            Dim strCompID As String = Profile.CompID.ToString() 'Get account number from asp profile
            Dim strReportName As String = "/RenewalStatement" 'Name of Report
            Dim strFullFilePath As String = strFilePath & strFileName 'Full path to stored file
            Label3.Visible = False

            'Define Report Parameters for render generation, render report as pdf, and send to location from webconfig
            Dim parm1(0) As ReportParameter
            Dim compid As Integer
            compid = Convert.ToInt64(Profile.CompID)
            parm1(0) = New Microsoft.Reporting.WebForms.ReportParameter("COMP_ID", compid)
            ReportViewer1.ServerReport.SetParameters(parm1)
            ReportViewer1.ShowParameterPrompts = False
            Dim pdf As CTPA.Common.PDFWrapper
            pdf = New CTPA.Common.PDFWrapper
            pdf.RenderPdf(strCompID, strReportName, strFullFilePath)

            'Define entity object and write values to SQL
            Dim rt As CTPA.Entities.ReportTracker 'Report Tracker Entity Object
            rt = New CTPA.Entities.ReportTracker
            rt.COMP_ID = compid
            rt.DATE_PRINTED = Now()
            rt.REASON_PRINT = "Accessed Check Payment Renewal Statement"
            rt.REPORT_DESCRIPTION = "Renewal Statement"
            rt.FILENAME = strFileName
            rt.FILE_PATH = strFullFilePath
            rt.USER_ID = Profile.UserName
            rt.V_PATH = strVPath
            rt.Save()
        End If
    End Sub
End Class
