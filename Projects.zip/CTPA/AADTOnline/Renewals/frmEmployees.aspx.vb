'***************************************************************
'* ROSTER REVIEW FORM FOR CTPA COMPANY RENEWAL PROCESSING      *
'* BY JEREMY MAY AND RCS                                       *
'* 1/2008                                                      *
'***************************************************************
Imports RenewalStatementWebSvc.ReportingService2005
Imports microsoft.reporting.webforms


Partial Class CDATAOnline_Drivers
    Inherits System.Web.UI.Page

    ''' <summary>
    ''' This will write the employee verification timestamps to the renewals table for the employee roster
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnVerify_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnVerify.Click
        'Define renewal entity object and write timestamp values
        Dim r As CTPA.Entities.Renewal
        r = New CTPA.Entities.Renewal(Profile.CompID)
        r.EMP_INFO_CONFIRMED = Today
        r.EMP_INFO_CONFIRMED_BY = CTPA.Common.Config.getWSUser().UserName
        r.INFO_APPROVED = False
        r.Save()
        Response.Redirect("default.aspx")
    End Sub

    ''' <summary>
    ''' This button cancels the current action and sends the user back to the renewals default page
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnCancelV_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancelV.Click
        'Redirect user back to default renewal page
        Response.Redirect("default.aspx")
    End Sub

    ''' <summary>
    ''' This button sends the user to the employee roster edit page
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Button7_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button7.Click
        'Redirect user to employee roster page
        Session("Renewal") = "true"
        Response.Redirect("~/AADTOnline/employees/Employees.aspx")
    End Sub

    ''' <summary>
    ''' This page load module sets the label for the parameter to be used in the SQL report
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Establish report parameter for report viewer
        Dim parm1(0) As ReportParameter
        Dim compid As Integer
        compid = Profile.CompID
        parm1(0) = New Microsoft.Reporting.WebForms.ReportParameter("COMP_ID", compid)
        ReportViewer1.ServerReport.SetParameters(parm1)
        ReportViewer1.ShowParameterPrompts = False
    End Sub
End Class
