'***************************************************************
'* RENEWAL DEFAULT FORM FOR CTPA COMPANY RENEWAL PROCESSING    *
'* BY JEREMY MAY AND RCS                                       *
'* 1/2008                                                      *
'***************************************************************
Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data
Partial Class AADTOnline_Renewals_Default
    Inherits System.Web.UI.Page

    ''' <summary>
    ''' This is the page load module for the renewals process.  This process checks the fields in the renewals table and enables
    ''' or disables the links depending on how far along in the renewal process they are
    ''' </summary>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        lblComplete.Visible = False 'Notification label for complete renewal process
        Label1.Text = (Year(Now()) + 1) 'Display Current Date

        'Define object for renewal entity class
        Dim r As CTPA.Entities.Renewal
        r = New CTPA.Entities.Renewal(Profile.CompID)
        Dim Comp As CTPA.Entities.Company
        Comp = New CTPA.Entities.Company(Profile.CompID)
        Dim changed As Boolean
        changed = Comp.hasPendingChange
        Dim emp_pending As Integer
        Dim prams(0) As SqlParameter
        prams(0) = New SqlParameter("@COMP_ID", SqlDbType.BigInt)
        prams(0).Value = Profile.CompID
        emp_pending = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.COMP_EMP_PENDING", prams)

        'Has the company information been confirmed?
        If Not (r.COMP_INFO_CONFIRMED_by = Nothing) Then
            LinkButton1.Enabled = False
            lblComp.Text = "Company Confirmed by " & r.COMP_INFO_CONFIRMED_by & " on " & r.COMP_INFO_CONFIRMED
            lblComp.Visible = True
            Image1.ImageUrl = "~/images/Checkmark.jpg"
            Image1.ToolTip = "This item has been completed!"
            LinkButton5.Enabled = True
        Else
            lblComp.Visible = False
            LinkButton1.Enabled = True
            LinkButton5.Enabled = False
            Image1.ImageUrl = "~/images/expoint.jpg"
            Image1.ToolTip = "This item needs your attention!"
        End If

        'Has the Employee Roster been confirmed?
        If Not (r.EMP_INFO_CONFIRMED = CTPA.Common.Config.InitialDateTime) Then
            LinkButton2.Enabled = False
            LinkButton6.Enabled = True
            lblEmp.Text = "Roster Confirmed by " & r.EMP_INFO_CONFIRMED_BY & " on " & r.EMP_INFO_CONFIRMED
            Image2.ImageUrl = "~/images/Checkmark.jpg"
            Image2.ToolTip = "This item has been completed!"
        Else
            lblEmp.Visible = False
            LinkButton6.Enabled = False
            LinkButton2.Enabled = True
            Image2.ImageUrl = "~/images/expoint.jpg"
            Image2.ToolTip = "This item needs your attention!"
        End If

        'Have the agreements been viewed and agreed to?
        If changed = False And emp_pending < 1 Then
            If Not (r.AGREEMENTS_SIGNED_RECEIVED = CTPA.Common.Config.InitialDateTime) Then
                LinkButton3.Enabled = False
                lblAgree.Text = "Agreements have been signed online by " & r.AGREEMENTS_SIGNED_ONLINE_BY & " On " & r.AGREEMENTS_SIGNED_ONLINE
                lblAgree.Visible = True
                Image3.ImageUrl = "~/images/Checkmark.jpg"
                Image3.ToolTip = "This item has been completed!"
            Else
                lblAgree.Visible = False
                LinkButton3.Enabled = True
                Image3.ImageUrl = "~/images/expoint.jpg"
                Image3.ToolTip = "This item needs your attention!"
            End If

            'Has payment information been recieved, if so has payment been approved?

            If Not (r.PAYMENT_RECEIVED_PENDING = CTPA.Common.Config.InitialDateTime) Then
                LinkButton4.Enabled = False
                If Not (r.PAYMENT_RECEIVED_PROCESSED = CTPA.Common.Config.InitialDateTime) Then
                    lblPay.Text = "Payment information recieved and Processed on: " & r.PAYMENT_RECEIVED_PROCESSED
                    lblPay.Visible = True
                Else
                    LinkButton4.Enabled = False
                    lblPay.Text = "Payment information has been received by AADT on: " & r.PAYMENT_RECEIVED_PENDING
                    lblPay.Visible = True
                    Image4.ImageUrl = "~/images/Checkmark.jpg"
                    Image4.ToolTip = "This item has been completed!"
                End If
            Else
                lblPay.Visible = False
                LinkButton4.Enabled = True
                Image4.ImageUrl = "~/images/expoint.jpg"
                Image4.ToolTip = "This item needs your attention!"
            End If
            'Have all parts of the process been completed?
            If Not (r.COMP_INFO_CONFIRMED = CTPA.Common.Config.InitialDateTime) And Not (r.EMP_INFO_CONFIRMED = CTPA.Common.Config.InitialDateTime) And Not (r.AGREEMENTS_SIGNED_ONLINE = CTPA.Common.Config.InitialDateTime) And Not (r.PAYMENT_RECEIVED_PENDING = CTPA.Common.Config.InitialDateTime) And Not (r.PAYMENT_RECEIVED_PROCESSED = CTPA.Common.Config.InitialDateTime) And (r.REP_APPROVED = True) And (r.FINANCE_APPROVED = True) Then
                lblComplete.Text = "Renewal Process Complete!"
                lblComplete.Visible = True
            Else
                If Not (r.COMP_INFO_CONFIRMED = CTPA.Common.Config.InitialDateTime) And Not (r.EMP_INFO_CONFIRMED = CTPA.Common.Config.InitialDateTime) And Not (r.AGREEMENTS_SIGNED_ONLINE = CTPA.Common.Config.InitialDateTime) And Not (r.PAYMENT_RECEIVED_PENDING = CTPA.Common.Config.InitialDateTime) Then
                    lblComplete.Text = "Payment pending!  Your payment information has been recieved and is pending approval by AADT.  Once approved you will be notified."
                    lblComplete.Visible = True
                Else
                    lblComplete.Visible = False
                End If
            End If
        Else
            lblComplete.Text = "You cannot continue the renewal process until all pending changes have been approved by AADT"
            lblComplete.Visible = True
            'LinkButton1.Enabled = False
            'LinkButton1.ToolTip = "Company and Employee Changes Must be Approved Before You Can Continue Your Online Renewal"
            'LinkButton2.Enabled = False
            'LinkButton2.ToolTip = "Company and Employee Changes Must be Approved Before You Can Continue Your Online Renewal"
            LinkButton3.Enabled = False
            LinkButton3.ToolTip = "Company and Employee Changes Must be Approved Before You Can Continue Your Online Renewal"
            LinkButton4.Enabled = False
            LinkButton4.ToolTip = "Company and Employee Changes Must be Approved Before You Can Continue Your Online Renewal"
            lblPay.Visible = False
            'Image1.ImageUrl = "~/images/expoint.jpg"
            'Image1.ToolTip = "This item needs your attention!"
            'Image2.ImageUrl = "~/images/expoint.jpg"
            'Image2.ToolTip = "This item needs your attention!"
            Image3.ImageUrl = "~/images/expoint.jpg"
            Image3.ToolTip = "This item needs your attention!"
            Image4.ImageUrl = "~/images/expoint.jpg"
            Image4.ToolTip = "This item needs your attention!"
        End If
        If (r.COMP_INFO_CONFIRMED = CTPA.Common.Config.InitialDateTime) Or (r.EMP_INFO_CONFIRMED = CTPA.Common.Config.InitialDateTime) Or (r.AGREEMENTS_SIGNED_ONLINE = CTPA.Common.Config.InitialDateTime) Then
            LinkButton4.Enabled = False
            LinkButton4.ToolTip = "You cannot submit payment until all other three renewal processes have been completed"
        End If
    End Sub

    ''' <summary>
    ''' This is the link that will take the user to the company report viewer
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub LinkButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        'Go to view company page
        Session("Renewals") = True
        Response.Redirect("frmCompany.aspx")
    End Sub

    ''' <summary>
    ''' This link will take the user to the employee report viewer
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub LinkButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton2.Click
        'Go to View Roster page
        Session("Renewals") = True
        Response.Redirect("frmEmployees.aspx")
    End Sub

    ''' <summary>
    ''' This link will take the user to the Agreement page
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub LinkButton3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton3.Click
        'Go to view agreements page
        Session("Renewals") = True
        Response.Redirect("frmAgreement.aspx")
    End Sub

    ''' <summary>
    ''' This link will take the user to the payment choice page.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub LinkButton4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton4.Click
        'Go to Payment Choice page
        Session("Renewals") = True
        Response.Redirect("frmPayChoice.aspx")
    End Sub

    ''' <summary>
    ''' This is the undo button for undoing the company information verification for a renewal
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub LinkButton5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton5.Click
        'Define new renewal entity class object
        Dim r1 As CTPA.Entities.Renewal
        r1 = New CTPA.Entities.Renewal(Profile.CompID)

        'Has payment been recieved, if so undo is disabled
        If Not (r1.PAYMENT_RECEIVED_PENDING = CTPA.Common.Config.InitialDateTime) Then
            Label2.Text = "Cannot Undo Once Payment Has Been Submitted"
            Label2.Visible = True
        Else
            r1.COMP_ID = Profile.CompID
            r1.COMP_INFO_CONFIRMED = CTPA.Common.Config.InitialDateTime
            r1.COMP_INFO_CONFIRMED_by = Nothing
            r1.Save()
            Label2.Visible = False
            Response.Redirect("default.aspx")
        End If
    End Sub

    ''' <summary>
    ''' This is the undo button for undoing the employee information verification for a renewal
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub LinkButton6_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton6.Click
        'Define new renewal entity class object
        Dim r1 As CTPA.Entities.Renewal
        r1 = New CTPA.Entities.Renewal(Profile.CompID)

        'Has payment been recieved, if so undo is disabled
        If r1.PAYMENT_RECEIVED_PENDING <> CTPA.Common.Config.InitialDateTime Then
            Label3.Text = "Cannot Undo Once Payment Has Been Submitted"
            Label3.Visible = True
        Else
            r1.COMP_ID = Profile.CompID
            r1.EMP_INFO_CONFIRMED = CTPA.Common.Config.InitialDateTime
            r1.EMP_INFO_CONFIRMED_BY = Nothing
            r1.Save()
            Label3.Visible = False
            Response.Redirect("default.aspx")
        End If
    End Sub
End Class
