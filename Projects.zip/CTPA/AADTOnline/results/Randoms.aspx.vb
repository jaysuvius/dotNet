
Partial Class CDATAOnline_Randoms
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Label5.Visible = False
            btnRndHist.Visible = False
        End If
    End Sub

  

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        Dim rt As New CTPA.Entities.Random(Convert.ToInt32(GridView1.SelectedRow.Cells(12).Text), CTPA.Entities.Random.LoadType.Test)
        GridView1.Visible = False
        btnRndHist.Visible = True
        Button1.Visible = True
        Label1.Visible = True
        TextBox1.Visible = True
        Session("DriverID") = rt.RNDID
        Label1.Text = "Employee Name:"
        TextBox1.Text = rt.driver.FIRSTNAME & " " & rt.driver.LASTNAME
        Label2.Visible = True
        TextBox2.Visible = True
        Label2.Text = "SSN:"
        TextBox2.Text = rt.driver.SS_NUM
        Label3.Visible = True
        TextBox3.Visible = True
        Label3.Text = "Test Date:"
        Dim space(1) As Char
        space(0) = " "
        If rt.DATETESTED = "" Then
            TextBox3.Text = "Result Not In"
        Else
            TextBox3.Text = rt.DATETESTED.Split(space)(0)
        End If
        'TextBox3.Text = Format(rt.DATETESTED.Split(space)(0), "date")
        Label4.Visible = True
        TextBox4.Visible = True
        Label4.Text = "Drug Test Result:"
        TextBox4.Text = rt.DTDRG()
        Label5.Visible = True
        Label6.Text = "Alcohol Test Result:"
        TextBox5.Text = rt.DTALC
        Label6.Visible = True
        TextBox5.Visible = True
        Label7.Visible = False


        ' Make all the textboxes readonly to prevent issues where a users thinks they can edit
        ' test results. 

        TextBox1.Enabled = False
        TextBox2.Enabled = False
        TextBox3.Enabled = False
        TextBox4.Enabled = False
        TextBox5.Enabled = False

        ' Display Legend. 
        Label5.Text = "<b>Test Result Code:</b><br/><br/>NEG: Negative<br/>REF: Refusal<br/>CAN: Cancelled<br/>INV: Invalid<br/>SUB: Substituted<br/>ADU: Adulterated<br/>DNR: Drug Test No Response <br/>DTV: Drug Test Voided<br/>POS: Result is positive<br/>REJ: Rejected<br/>REQ: Required<br/>PEN: Pending"


    End Sub

    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If (e.Row.RowType = DataControlRowType.DataRow) Then
            If (e.Row.DataItemIndex Mod 2) = 1 Then
                e.Row.BackColor = Drawing.Color.LightGray
            Else
                e.Row.BackColor = Drawing.Color.FloralWhite
            End If
        Else
            If e.Row.RowType = DataControlRowType.Header Then
                e.Row.ForeColor = Drawing.Color.Black
            End If
            e.Row.BackColor = Drawing.Color.Black
            e.Row.ForeColor = Drawing.Color.White
        End If
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        GridView1.Visible = True
        TextBox1.Visible = False
        Button1.Visible = False
        Label1.Visible = False
        TextBox2.Visible = False
        Label2.Visible = False
        TextBox3.Visible = False
        Label3.Visible = False
        TextBox4.Visible = False
        Label4.Visible = False
        Label5.Visible = False
        Label6.Visible = False
        TextBox5.Visible = False
        Label7.Visible = True
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("~/AADTOnline/default.aspx")
    End Sub

    Protected Sub btnRndHist_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRndHist.Click
        Response.Redirect("EmployeeHistory.aspx")
    End Sub
End Class
