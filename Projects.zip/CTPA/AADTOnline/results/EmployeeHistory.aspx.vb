Imports Microsoft.ApplicationBlocks.Data
Partial Class AADTOnline_results_EmployeeHistory
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim strLName As String
        Dim strFName As String
        Dim strTName As String
        Dim sqlStatement As String
        sqlStatement = "Select LASTNAME FROM dbo.DRIVERUP_Primary Where AUTOID = " & Session("DriverID")
        strLName = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, Data.CommandType.Text, sqlStatement).ToString
        sqlStatement = "Select FIRSTNAME FROM dbo.DRIVERUP_Primary Where AUTOID = " & Session("DriverID")
        strFName = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, Data.CommandType.Text, sqlStatement).ToString
        sqlStatement = "Select TITLENAME FROM dbo.DRIVERUP_Primary Where AUTOID = " & Session("DriverID")
        strTName = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, Data.CommandType.Text, sqlStatement).ToString
        Label1.Text = "Random History for " & strLName & ", " & strFName & " " & strTName
    End Sub

    Protected Sub btnBack_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBack.Click
        Response.Redirect("Randoms.aspx")
    End Sub
End Class
