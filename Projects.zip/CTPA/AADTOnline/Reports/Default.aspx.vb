
Partial Class AADTOnline_Reports_Default
    Inherits System.Web.UI.Page
    ''' <summary>
    ''' This is the page load event for the default page of the forms folder.  Here we set label2.text to the comp_id
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Set label to value of the company account ID to use as stored procedure parameter
        Label2.Text = Profile.CompID
    End Sub
    ''' <summary>
    ''' This is the onrowcommand module for gridview2 which displays the list of reports rendered by that company
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub ViewDocument(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        Dim DocPath As String 'Local path to document
        Dim VPath As String   'Virtual path to document
        Dim FileName As String 'Name of Document File
        Dim sb As String 'String Builder variable for building the response.write statement to view document

        'Set up table cell object to use the value of cell to collect path inormation to display document
        Dim index As Integer = Convert.ToInt32(e.CommandArgument)
        Dim selectedRow As GridViewRow = GridView1.Rows(index)
        Dim Cell As TableCell = selectedRow.Cells(4)
        Dim Cell2 As TableCell = selectedRow.Cells(5)
        FileName = Cell.Text
        VPath = Cell2.Text
        DocPath = VPath & FileName
        sb = "<script language=javascript>window.open('" & DocPath & "','new_Win');</script>"
        'Display Document in _Blank target window
        Response.Write(sb)
    End Sub
End Class
