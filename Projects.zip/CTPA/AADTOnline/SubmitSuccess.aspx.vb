
Partial Class AADTOnline_drivers_SubmitSuccess
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Request.QueryString("Success").ToUpper.Equals("Yes".ToUpper) Then
            Label1.Text = CTPA.Common.Config.SaveSuccess
        ElseIf Request.QueryString("Success").ToUpper.Equals("No".ToUpper) Then
            Label1.Text = CTPA.Common.Config.SaveError
        Else
            Label1.Text = "You have reached this page in error."
        End If
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Response.Redirect("~/AADTOnline/employees/employees.aspx")
    End Sub
End Class
