Imports CTPA.Common
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data
Partial Class AADTOnline_drivers_NewDriver
    Inherits System.Web.UI.Page



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            TextBox1.Focus()
            buildPoolListBox()
            showCommits(False)
        End If

    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        ' The commit button is pressed.
        ' Create a new driver record (blank) and then create a web site update record with the driver information in it for approval
        Dim d As New CTPA.Entities.Driver(Profile.CompID, True)
        Dim wsu As CTPA.Entities.WSUpdate
        d.COMP_ID = Profile.CompID
        Select Case ListBox1.Text
            Case "1-GENERAL CD POOL"
                d.POOLID = 3
            Case "2-GENERAL OWNER OPERATOR POOL"
                d.POOLID = 2
            Case "3-GENERAL DRUG FREE POOL"
                d.POOLID = 1
            Case "4-GENERAL PUC POOL"
                d.POOLID = 4
            Case "5-GENERAL PUC OO"
                d.POOLID = 5
            Case "9-CD POOL - 9970"
                d.POOLID = 3
            Case "10-DF POOL - 9970"
                d.POOLID = 1
            Case "11-DF POOL - 2710"
                d.POOLID = 1
            Case "12-DF Pool PUC"
                d.POOLID = 1
            Case "13-CD POOL - 1035"
                d.POOLID = 3
            Case "14-DF POOL - 1294"
                d.POOLID = 1
            Case "15-CD POOL 878"
                d.POOLID = 3
            Case "16-DF POOL 8125"
                d.POOLID = 1
            Case "17-DF POOL - 2662"
                d.POOLID = 1
            Case "18-DF POOL - TOW POOL CD"
                d.POOLID = 1
            Case "19-DF POOL - TOW POOL O-O"
                d.POOLID = 1
            Case "20-DF Pool - 2254"
                d.POOLID = 1
            Case "21-TEXAS TDLR CE"
                d.POOLID = 6
            Case "22-TEXAS TDLR O-O"
                d.POOLID = 7
            Case "23-DF 50"
                d.POOLID = 1
            Case Else
                d.POOLID = 1
        End Select
        d.FIRSTNAME = Validator.ValidateName(TextBox1.Text, 4)
        'd.MIDDLENAME = Validator.ValidateName(TextBox2.Text, 4)
        d.LASTNAME = Validator.ValidateName(TextBox3.Text, 4)
        d.ADDRESS1 = Validator.ValidateAddress(TextBox4.Text)
        d.CITY = Validator.ValidateCity(CityTextBox.Text)
        d.STATE = Validator.ValidateState(StateTextBox.Text)
        d.WORKPHONE = Validator.ValidatePhone(TextBox5.Text)
        d.EMERPHONE = Validator.ValidatePhone(TextBox13.Text)
        d.ZIP = Validator.ValidateZIP(ZIPTextBox.Text)
        d.BIRTH_DATE = Date.Parse(TextBox14.Text)
        d.HOMEPHONE = Validator.ValidatePhone(TextBox9.Text)
        d.CDL_NUM = Validator.ValidateDL(TextBox10.Text)
        d.TITLENAME = Validator.ValidateTitleName(TextBox11.Text)
        d.SS_NUM = Validator.ValidateSSN(TextBox12.Text)
        d.RNDGRPID = CTPA.Common.Config.poolNames(ListBox1.Text)
        d.ACTIVE = Date.Today
        d.INACTIVE = Nothing
        d.TAG_IDCARD = True

        If TextBox8.Text Is Nothing Then
            d.PreEmpTstDate = Date.Parse(TextBox8.Text)
        Else
            d.PreEmpTstComplete = Nothing
        End If

        If Radio1.Text = "English" Then
            d.SpanMan = "False"
        Else
            d.SpanMan = "True"
        End If
        If CheckBox1.Checked = True Then
            d.ReHire = "True"
        Else
            d.ReHire = "False"
        End If
        d.SpecimenID = TextBox15.Text
        If Radio2.Text = "Completed" Then
            d.PreEmpTstComplete = "True"
            TextBox8.Enabled = "True"
        Else
            d.PreEmpTstComplete = "False"
            TextBox8.Enabled = "False"
        End If
        d.HIREDT = Date.Parse(TextBox6.Text)

        ' create moderated update
        wsu = New CTPA.Entities.WSUpdate(d.AUTOID, "Employee")
        wsu.ChangeDesc = d.updateDesc
        wsu.Pending = True
        wsu.Approved = False
        wsu.TimeRequested = DateTime.Now
        wsu.UpdateCmd = d.updateCommand
        wsu.username = Membership.GetUser.UserName
        wsu.Insert()
        'Dim SQLStatement As String
        Dim RepID As Integer = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, Data.CommandType.Text, "Select SERVREPID From CALDATA_TBL Where COMP_ID = " & Profile.CompID)
        Dim prams(1) As SqlParameter
        prams(0) = New SqlParameter("@RepID", SqlDbType.Int)
        prams(0).Value = RepID
        prams(1) = New SqlParameter("@ChangeKey", SqlDbType.Int)
        prams(1).Value = d.AUTOID
        SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.SetChangeRepID", prams)
        'SQLStatement = "Update dbo.WS_UPDATES set RepID = " & RepID & " Where ChangeRecordKey = " & d.AUTOID
        'SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, Data.CommandType.Text, SQLStatement)
        Response.Redirect("DriverAddPending.aspx?Confirm=yes")

    End Sub


    Private Sub showCommits(ByVal show As Boolean)
        Button1.Visible = Not show
        Button2.Visible = show
        Button3.Visible = show
        Button4.Visible = Not show

        LabelConfirm.Text = "Add new employee: " & TextBox1.Text & " " _
        & IIf(TextBox2.Text <> String.Empty, TextBox2.Text & " ", "") _
        & TextBox3.Text & IIf(TextBox11.Text = String.Empty, "", ", " _
        & TextBox11.Text) & "<br/><br/>Test Pool: " & ListBox1.Text _
        & "<br/>SSN: " & TextBox12.Text _
        & "<br/>DL#: " & TextBox10.Text & "<br/><br/>Address 1: " & TextBox4.Text _
        & "<br/>City: " & CityTextBox.Text _
        & "<br/>State: " & StateTextBox.Text _
        & "<br/>ZIP: " & ZIPTextBox.Text _
        & "<br/><br/>Home Phone: " & TextBox9.Text _
        & "<br/>Work Phone: " & TextBox5.Text _
        & "<br/>Emergency Phone: " & TextBox13.Text _
        & "<br/><br/>Click OK to confirm this change and submit it to " _
        & CTPA.Common.Config.CompanyName & "."
        LabelConfirm.Visible = show
        Label1.Visible = Not show
        Label2.Visible = Not show
        Label3.Visible = Not show
        Label4.Visible = Not show
        Label5.Visible = Not show
        Label6.Visible = Not show
        Label7.Visible = Not show
        Label8.Visible = Not show
        Label9.Visible = Not show
        Label10.Visible = Not show
        Label11.Visible = Not show
        Label12.Visible = Not show
        Label13.Visible = Not show
        Label14.Visible = Not show
        Label15.Visible = Not show
        TextBox13.Visible = Not show
        TextBox1.Visible = Not show
        TextBox2.Visible = Not show
        TextBox3.Visible = Not show
        TextBox4.Visible = Not show
        TextBox5.Visible = Not show
        TextBox6.Visible = Not show
        CityTextBox.Visible = Not show
        StateTextBox.Visible = Not show
        ZIPTextBox.Visible = Not show
        TextBox9.Visible = Not show
        TextBox10.Visible = Not show
        TextBox11.Visible = Not show
        TextBox12.Visible = Not show
        TextBox14.Visible = Not show
        Label16.Visible = Not show
        ListBox1.Visible = Not show
        labelFail.Visible = False
        Label18.Visible = Not show
        Label19.Visible = Not show
        Label20.Visible = Not show
        Label21.Visible = Not show
        Radio1.Visible = Not show
        CheckBox1.Visible = Not show
        TextBox8.Visible = Not show
        TextBox15.Visible = Not show
        Label22.Visible = Not show
        Label23.Visible = Not show
        Radio2.Visible = Not show
        LabelPoolLegend.Visible = Not show
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Validator.ValidateName(TextBox1, 4)
        Validator.ValidateName(TextBox2, 4)
        Validator.ValidateName(TextBox3, 4)
        Validator.ValidateAddress(TextBox4)
        Validator.ValidateCity(CityTextBox)
        Validator.ValidateState(StateTextBox)
        Validator.ValidatePhone(TextBox5)
        Validator.ValidatePhone(TextBox13)
        Validator.ValidateZIP(ZIPTextBox)
        Validator.ValidatePhone(TextBox9)
        Validator.ValidateTitleName(TextBox11)
        Validator.ValidateSSN(TextBox12)
        Validator.ValidateDL(TextBox10)
        If TextBox1.Text.Contains(Validator.InvalidFieldMarker) OrElse TextBox2.Text.Contains(Validator.InvalidFieldMarker) OrElse _
                TextBox3.Text.Contains(Validator.InvalidFieldMarker) OrElse TextBox4.Text.Contains(Validator.InvalidFieldMarker) _
                OrElse CityTextBox.Text.Contains(Validator.InvalidFieldMarker) OrElse StateTextBox.Text.Contains(Validator.InvalidFieldMarker) _
                OrElse TextBox5.Text.Contains(Validator.InvalidFieldMarker) OrElse TextBox13.Text.Contains(Validator.InvalidFieldMarker) _
                OrElse ZIPTextBox.Text.Contains(Validator.InvalidFieldMarker) OrElse TextBox9.Text.Contains(Validator.InvalidFieldMarker) _
                OrElse TextBox10.Text.Contains(Validator.InvalidFieldMarker) OrElse TextBox11.Text.Contains(Validator.InvalidFieldMarker) _
                OrElse TextBox12.Text.Contains(Validator.InvalidFieldMarker) Then
            labelFail.Text = "Please check the entry fields, one or more may need corrections"
            labelFail.Visible = True
        Else
            showCommits(True)
            labelFail.Visible = False
        End If
    End Sub


    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        showCommits(False)
        LabelConfirm.Visible = False
        Button1.Visible = True
        Button4.Visible = True
    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        Response.Redirect("Employees.aspx")
    End Sub

    Private Sub buildPoolListBox()
        For Each poolName As String In CTPA.Common.Config.poolNames.Keys
            Dim poolID As Integer = CTPA.Common.Config.poolNames(poolName)
            Dim custPools() As Integer = {9, 10, 11, 13, 14, 17, 20}
            If Array.BinarySearch(custPools, poolID) >= 0 Then
                ' If this is one of the custom pools, check that the poolname has this company ID before adding it to the listbox
                If poolName.Split(" ")(poolName.Split(" ").Length - 1).Contains(Profile.CompID.ToString) Then
                    ListBox1.Items.Add(poolName)
                End If
            Else
                ListBox1.Items.Add(poolName)
            End If
        Next
    End Sub
End Class