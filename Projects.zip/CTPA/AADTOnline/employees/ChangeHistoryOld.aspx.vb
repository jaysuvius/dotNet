
Partial Class AADTOnline_drivers_ChangeHistory
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        SqlDataSource1.SelectCommand = "SELECT [ChangeDesc], [TimeRequested], [Approved] FROM [WS_UPDATES]"

        If Session("CompanyHistoryFilter") Then
            SqlDataSource1.SelectCommand = "SELECT dbo.WS_UPDATES.username, dbo.WS_UPDATES.ChangeRecordKey, dbo.WS_UPDATES.ChangeType, dbo.WS_UPDATES.Pending, dbo.WS_UPDATES.ChangeDesc, " & _
            "dbo.WS_UPDATES.UpdateCmd, dbo.WS_UPDATES.TimeRequested, dbo.WS_UPDATES.TimeCommitted, dbo.WS_UPDATES.TimeStamp, dbo.WS_UPDATES.Approved, " & _
            "dbo.WS_UPDATES.ChangeID, dbo.WS_UPDATES.ApprovedBy, dbo.DRIVERUP_primary.COMP_ID FROM dbo.WS_UPDATES INNER JOIN " & _
            "dbo.DRIVERUP_primary ON dbo.WS_UPDATES.ChangeRecordKey = dbo.DRIVERUP_primary.AUTOID WHERE     (ChangeType = 'Driver') and (COMP_ID = " & Session("CompanyHistoryFilter") & " )"
        End If
    End Sub

    ''' <summary>
    ''' This function updates each datagrid row with a friendlier update string.  Uses the same splitting technique as wsupdate.getfriendlydescription()
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub gridview1_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim dr As Data.DataRow
            Dim strDescription As String
            dr = CType(e.Row.DataItem, Data.DataRowView).Row
            strDescription = dr("ChangeDesc").ToString()
            If strDescription.Contains("Full Update:") Then
                Dim FullUpdate() As String = {", Full Update:"}
                strDescription = strDescription.Split(FullUpdate, System.StringSplitOptions.RemoveEmptyEntries)(0)
                e.Row.Cells(0).Text = strDescription
            End If
            e.Row.Cells(1).Text = CType(dr("TimeRequested"), DateTime).Date.ToString
        End If
    End Sub
End Class
