
Partial Class AADTOnline_drivers_DriverAddPending
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Request.QueryString("Confirm") = "yes" Then
            Response.Redirect("Employees.aspx")
        End If
        Label1.Text = "Your request to add a new employee has been submitted. Upon approval by " & CTPA.Common.Config.CompanyName & ", you will receive notification when the employee has been added to your company program and random testing pool."
        If Session("Renewal") = "true" Then
            HyperLink1.Text = "Return to renewals page"
            HyperLink1.NavigateUrl = "~Renewals/Default.aspx"
        Else
            HyperLink1.Text = "Return to employees page"
            HyperLink1.NavigateUrl = "Employees.aspx"
        End If
    End Sub
End Class
