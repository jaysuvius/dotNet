Imports CTPA.Common
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data

Partial Class AADTOnline_drivers_OOS
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        CalendarExtender1.OnClientDateSelectionChanged = "EndDateFocus"
        If Not Page.IsPostBack Then
            SaveButton.Focus()
            Dim d As CTPA.Entities.Driver
            DriverAutoID.Text = Session("OOSDriver")
            d = New CTPA.Entities.Driver(Convert.ToInt32(DriverAutoID.Text))
            DriverName.Text = d.FIRSTNAME & " " & d.LASTNAME
            Startdate.Text = Date.Today
            EndDate.Text = DateAdd(DateInterval.Day, 14, Date.Today)

            loadDropDown()
            If (d.hasPendingChange = 0) Then
                Label1.Visible = False
                DriverAutoID.Visible = True
                DriverAutoIDLabel.Visible = True
                DriverName.Visible = True
                DriverNameLabel.Visible = True
                OutOfServiceStartDateLabel.Visible = True
                OutOfServiceEndDateLabel.Visible = True
                Startdate.Visible = True
                EndDate.Visible = True
                Image1.Visible = True
                Image2.Visible = True
                DropDownLabel.Visible = True
                DropDownList1.Visible = True
                SaveButton.Visible = True
                CancelButton.Visible = True
            Else
                Label1.Visible = True
                Label1.Text = "There is a change pending for this employee.  You cannot have more than one action pending."
                DriverAutoID.Visible = False
                DriverAutoIDLabel.Visible = False
                DriverName.Visible = False
                DriverNameLabel.Visible = False
                OutOfServiceStartDateLabel.Visible = False
                OutOfServiceEndDateLabel.Visible = False
                Startdate.Visible = False
                EndDate.Visible = False
                Image1.Visible = False
                Image2.Visible = False
                DropDownLabel.Visible = False
                DropDownList1.Visible = False
                SaveButton.Visible = False
                CancelButton.Visible = True
                CancelButton.Text = "Back"
            End If
        End If
    End Sub

    Private Sub loadDropDown()
        Dim statusIDs As System.Collections.Specialized.NameValueCollection = CTPA.Common.Config.OOSStatusIDs
        For Each OOS_ID As String In statusIDs
            DropDownList1.Items.Add(statusIDs(OOS_ID))
        Next
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancelButton.Click
        Response.Redirect("Employees.aspx")
    End Sub

    Protected Sub SaveButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveButton.Click
        'Try
        Dim d As New CTPA.Entities.Driver(Convert.ToInt32(DriverAutoID.Text))
        Dim wsu As New CTPA.Entities.WSUpdate(d.AUTOID, "Employee")
        d.OOSDATE = Startdate.Text
        d.OOSEXPDATE = EndDate.Text
        d.OOSEXPACTION = 1
        d.OOSID = CTPA.Common.Config.OOSReasonNames(DropDownList1.Text)
        wsu.UpdateCmd = d.updateCommand
        wsu.ChangeDesc = d.updateDesc
        wsu.username = Membership.GetUser.UserName
        wsu.TimeRequested = DateTime.Now
        wsu.Pending = True
        wsu.Approved = False
        wsu.Insert()
        Dim RepID As Integer = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, Data.CommandType.Text, "Select SERVREPID From CALDATA_TBL Where COMP_ID = " & Profile.CompID)
        Dim prams(1) As SqlParameter
        prams(0) = New SqlParameter("@RepID", SqlDbType.Int)
        prams(0).Value = RepID
        prams(1) = New SqlParameter("@ChangeKey", SqlDbType.Int)
        prams(1).Value = d.AUTOID
        SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.SetChangeRepID", prams)

        Response.Redirect("../SubmitSuccess.aspx?Success=Yes")
        'Catch ex As Exception
        '    Response.Redirect("../SubmitSuccess.aspx?Success=No")
        'End Try

    End Sub

    Protected Sub Startdate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Startdate.TextChanged
        EndDate.Text = DateAdd(DateInterval.Day, 14, Date.Parse(Startdate.Text))
    End Sub

    Protected Sub TextBox1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        EndDate.Text = "TEST"
    End Sub
End Class
