Imports CTPA.Common
Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data

Partial Class CDATAOnline_Drivers
    Inherits System.Web.UI.Page
    Public Pools(25, 1) As String
    Public empID As Integer
    Private dv As Data.DataView
    Public Active As Boolean = True
    Public InactiveSelect As String = "SELECT *, 'XXX-XX-' + RIGHT(SS_NUM,4) AS SSN_MASK  FROM [DRIVERUP_primary] WHERE ([COMP_ID] = @COMP_ID) AND not [inactive] is NULL"
    Public ActiveSelect As String = "SELECT *, 'XXX-XX-' + RIGHT(SS_NUM,4) AS SSN_MASK  FROM [DRIVERUP_primary] WHERE ([COMP_ID] = @COMP_ID) AND [inactive] is NULL"
    Private ReadOnly Property getDataView() As Data.DataView
        Get
            dv = SqlDataSource1.Select(DataSourceSelectArguments.Empty)
            CTPA.Common.ModeratedDVUpdater.UpdateDataview(dv, "Employee")
            Return dv
        End Get
    End Property

    Private ldSortExpression As ListDictionary
    Private Property SortExpression() As ListDictionary
        Get
            ldSortExpression = CType(ViewState("SortExpressions"), ListDictionary)
            If ldSortExpression Is Nothing Then
                ldSortExpression = New ListDictionary
            End If
            Return ldSortExpression
        End Get
        Set(ByVal value As ListDictionary)
            ViewState("SortExpressions") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If LinkButton1.Text = "Show Inactive Employees" Then
            SqlDataSource1.SelectCommand = ActiveSelect
            btnOOS.Enabled = True
            Button1.Enabled = True
        Else
            SqlDataSource1.SelectCommand = InactiveSelect
            btnOOS.Enabled = False
            Button1.Enabled = False
        End If
        If Not (Page.IsPostBack) Then
            Active = True
            Pools = buildPoolListBox()
            showGrid(True)
            GridView1.Columns(7).Visible = False
            showButtons(False, False)
            btnUpdate.Visible = False
        End If
        'Dim test As New DriverAPI.Service1
        'TextBox1.Text = test.HelloWorld
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        DriverID.Text = GridView1.SelectedRow.Cells(8).Text
        Session("DriverID") = GridView1.SelectedRow.Cells(8).Text
        Dim d As New CTPA.Entities.Driver(Convert.ToInt32(DriverID.Text))
        Dim datelength As Integer
        If LinkButton1.Text = "Show Inactive Employees" Then
            btnDeactivate.Text = "Deactivate Employee"
        Else
            Label1.Text = "Would you like to reactivate employee " & d.NAME & "?<br>(Pre-employment testing may be required after a 30-day lapse of enrollment.)"
            Label1.Visible = True
            LinkButton1.Visible = False
            btnDeactivate.Visible = True
            btnDeactivate.Text = "Reactivate Employee"
            GridView1.Visible = False
        End If
        empID = d.AUTOID
        Select Case d.POOLID
            Case 1
                ListBox1.SelectedValue = "1-GENERAL CD POOL"
            Case 2
                ListBox1.SelectedValue = "2-GENERAL OWNER OPERATOR POOL"
            Case 3
                ListBox1.SelectedValue = "3-GENERAL DRUG FREE POOL"
            Case 4
                ListBox1.SelectedValue = "4-GENERAL PUC POOL"
            Case 5
                ListBox1.SelectedValue = "5-GENERAL PUC OO"
            Case 9
                ListBox1.SelectedValue = "9-CD POOL - 9970"
            Case 10
                ListBox1.SelectedValue = "10-DF POOL - 9970"
            Case 11
                ListBox1.SelectedValue = "11-DF POOL - 2710"
            Case 12
                ListBox1.SelectedValue = "12-DF Pool PUC"
            Case 13
                ListBox1.SelectedValue = "13-CD POOL - 1035"
            Case 14
                ListBox1.SelectedValue = "14-DF POOL - 1294"
            Case 15
                ListBox1.SelectedValue = "15-CD POOL 878"
            Case 16
                ListBox1.SelectedValue = "16-DF POOL 8125"
            Case 17
                ListBox1.SelectedValue = "17-DF POOL - 2662"
            Case 18
                ListBox1.SelectedValue = "18-DF POOL - TOW POOL CD"
            Case 19
                ListBox1.SelectedValue = "19-DF POOL - TOW POOL O-O"
            Case 20
                ListBox1.SelectedValue = "20-DF Pool - 2254"
            Case 21
                ListBox1.SelectedValue = "21-TEXAS TDLR CE"
            Case 22
                ListBox1.SelectedValue = "22-TEXAS TDLR O-O"
            Case 23
                ListBox1.SelectedValue = "23-DF 50"
            Case Else
                ListBox1.SelectedValue = "1-GENERAL CD POOL"
        End Select
        txtFirstName.Text = d.FIRSTNAME
        txtMidName.Text = d.MIDDLENAME
        txtLastName.Text = d.LASTNAME
        txtJrSr.Text = d.TITLENAME
        txtHomePhone.Text = d.HOMEPHONE
        txtCellPhone.Text = d.CELLPHONE
        txtAddy1.Text = d.ADDRESS1
        txtAddy2.Text = d.ADDRESS2
        txtCity.Text = d.CITY
        txtState.Text = d.STATE
        txtZip.Text = d.ZIP
        txtEmerphone.Text = d.EMERPHONE
        txtSSN.Text = d.SS_NUM
        datelength = Len(d.BIRTH_DATE)
        If datelength = 20 Then
            txtDOB.Text = Left(d.BIRTH_DATE, 9)
        Else
            txtDOB.Text = Left(d.BIRTH_DATE, 10)
        End If
        txtCDL.Text = d.CDL_NUM
        txtTitle.Text = d.TITLENAME
        datelength = Len(d.HIREDT)
        If datelength = 20 Then
            txtHireDate.Text = Left(d.HIREDT, 9)
        Else
            txtHireDate.Text = Left(d.HIREDT, 10)
        End If
        If LinkButton1.Text = "Show Active Employees" Then
            Label24.Text = "Inactive Date"
            datelength = Len(d.INACTIVE)
            If datelength = 20 Then
                lblActiveDate.Text = Left(d.INACTIVE, 9)
            Else
                lblActiveDate.Text = Left(d.INACTIVE, 10)
            End If
        Else
            Label24.Text = "Active Date"
            datelength = Len(d.ACTIVE)
            If datelength = 20 Then
                lblActiveDate.Text = Left(d.ACTIVE, 9)
            Else
                lblActiveDate.Text = Left(d.ACTIVE, 10)
            End If
        End If
        Dim emp_pending As Integer
        Dim prams(0) As SqlParameter
        prams(0) = New SqlParameter("@EMP_ID", SqlDbType.BigInt)
        prams(0).Value = d.AUTOID
        lblEmpID.Text = DriverID.Text
        emp_pending = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.EMP_PENDING", prams)
        If emp_pending > 0 Then
            Dim change_pending As String
            change_pending = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.PENDING_EMP_CHANGE", prams)
            Dim change() = Nothing
            change = Split(change_pending, "=", , CompareMethod.Text)
            Label15.Text = change(0)
            Label16.Text = change(1)
            Label14.Text = "Pending Change for Employee: " & Profile.CompID
            Label14.Visible = True
            Label15.Visible = True
            Label16.Visible = True
            btnUndo.Visible = True
        Else
            Label14.Visible = False
            Label15.Visible = False
            Label16.Visible = False
        End If
        btnBack.Visible = False
        showGrid(False)
        showButtons(True, False)
        Label1.Text = "Please click update to send changes to " & CTPA.Common.Config.ProgramName & " when you are finished." & IIf(d.hasPendingChange, "  The information below does not reflect the requested change that is currently pending.  Click ""Update"" with no changes to delete the pending change.", "")
        Label1.Visible = True

        'Else
        'Label1.Text = "Would you like to reactivate employee " & d.NAME & "?<br>(Pre-employment testing may be required after a 30-day lapse of enrollment.)"
        'Label1.Visible = True
        'LinkButton1.Visible = False
        'btnDeactivate.Visible = True
        'btnDeactivate.Text = "Reactivate this employee"
        'GridView1.Visible = False
        'HyperLink1.Visible = False
        'End If
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        btnBack.Visible = True
        LabelCommit.Visible = False
        Validator.ValidateName(txtFirstName, 4)
        'Validator.ValidateName(txtMidName, 4)
        Validator.ValidateName(txtLastName, 4)
        Validator.ValidateTitleName(txtJrSr)
        Validator.ValidatePhone(txtHomePhone)
        Validator.ValidatePhone(txtCellPhone)
        Validator.ValidatePhone(txtEmerphone)
        Validator.ValidateAddress(txtAddy1)
        Validator.ValidateAddress(txtAddy2)
        Validator.ValidateCity(txtCity)
        Validator.ValidateState(txtState)
        Validator.ValidateZIP(txtZip)
        Validator.ValidateDL(txtCDL)
        Validator.ValidateDate(txtDOB)
        Validator.ValidateDate(txtHireDate)
        If txtFirstName.Text.Contains(Validator.InvalidFieldMarker) OrElse txtMidName.Text.Contains(Validator.InvalidFieldMarker) _
                OrElse txtLastName.Text.Contains(Validator.InvalidFieldMarker) OrElse txtJrSr.Text.Contains(Validator.InvalidFieldMarker) _
                OrElse txtHomePhone.Text.Contains(Validator.InvalidFieldMarker) OrElse txtCellPhone.Text.Contains(Validator.InvalidFieldMarker) _
                OrElse txtAddy1.Text.Contains(Validator.InvalidFieldMarker) OrElse txtAddy2.Text.Contains(Validator.InvalidFieldMarker) _
                OrElse txtCity.Text.Contains(Validator.InvalidFieldMarker) OrElse txtState.Text.Contains(Validator.InvalidFieldMarker) _
                OrElse txtZip.Text.Contains(Validator.InvalidFieldMarker) Then
            'LabelCommit.Text = "Some of your entry fields contain invalid data.  Please check them and try again"
            'LabelCommit.Visible = True
            Exit Sub
        End If

        Dim d As CTPA.Entities.Driver
        d = getDriver()
        If Not (d.isChanged) Then
            If d.hasPendingChange Then
                Label1.Text = "Do you wish to delete the pending change to the employee?"
                Label1.Visible = True
                showButtons(False, True)
                showGrid(False)
            Else
                Label1.Text = "No changes made to this employee"
                Label1.Visible = True
                showButtons(True, False)
                showGrid(False)
            End If
        Else
            If d.hasPendingChange Then
                Label1.Text = "There is already a change pending for this employee.  Would you like to override it?"
                Label1.Visible = True
                showButtons(False, True)
                showGrid(False)
            Else
                Dim update As New CTPA.Entities.WSUpdate()
                update.ChangeDesc = d.updateDesc
                update.UpdateCmd = d.updateCommand
                update.TimeRequested = DateTime.Now
                update.username = Membership.GetUser().UserName
                update.ChangeRecordKey = d.AUTOID
                update.ChangeType = "Employee"
                update.Insert()
                Label1.Text = "Update saved for approval by " & Config.CompanyName
                showGrid(True)
                showButtons(False, False)
            End If
        End If
        Response.Redirect("Employees.aspx")
    End Sub



    Protected Sub GridView1_PageIndexChanging(ByVal sender As Object, ByVal e As GridViewPageEventArgs) Handles GridView1.PageIndexChanging
        If LinkButton1.Text = "Show Inactive Employees" Then
            SqlDataSource1.SelectCommand = ActiveSelect
            Active = True
        Else
            SqlDataSource1.SelectCommand = InactiveSelect
            Active = False
        End If
        GridView1.PageIndex = e.NewPageIndex
        showGrid(True)
    End Sub


    Protected Sub gridview1_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles GridView1.RowDataBound
        Dim dr As Data.DataRowView
        If e.Row.RowType = DataControlRowType.DataRow Then
            If (e.Row.DataItemIndex Mod 2) = 0 Then
                e.Row.BackColor = Drawing.Color.LightGray
            Else
                e.Row.BackColor = System.Drawing.Color.FloralWhite
            End If
            dr = CType(e.Row.DataItem, Data.DataRowView)
            If dr.Row("Updated") Then
                e.Row.BackColor = Drawing.Color.HotPink
                e.Row.ForeColor = Drawing.Color.Black
            End If
        Else
            If e.Row.RowType = DataControlRowType.Header Then
                e.Row.ForeColor = Drawing.Color.Black
            End If
            e.Row.BackColor = Drawing.Color.Black
            e.Row.ForeColor = Drawing.Color.White
        End If
    End Sub


    Protected Sub gridview1_Sorting(ByVal sender As Object, ByVal e As GridViewSortEventArgs) Handles GridView1.Sorting
        ldSortExpression = SortExpression
        If Not ldSortExpression.Contains(e.SortExpression) Then
            ldSortExpression.Add(e.SortExpression, e.SortDirection.ToString.Replace("Ascending", "ASC").Replace("Descending", "DESC"))
        Else
            ' Get sort direction
            Dim strSortDirection As String = ldSortExpression.Item(e.SortExpression)
            ' Was it ascending?
            If strSortDirection = "ASC" Then
                ' Yes, so sort in desc
                ldSortExpression.Item(e.SortExpression) = "DESC"
            ElseIf strSortDirection = "DESC" Then
                ' it is descending
                ' remove the sort order
                ldSortExpression.Remove(e.SortExpression)
            End If
        End If
        SortExpression = ldSortExpression
        showGrid(True)
    End Sub


    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnYes.Click
        Dim d As CTPA.Entities.Driver
        d = getDriver()
        If Not (d.isChanged) Then
            If d.hasPendingChange Then
                Dim wsu As New CTPA.Entities.WSUpdate(d.AUTOID.ToString, "Employee")
                wsu.Delete()
            End If
        Else
            If d.hasPendingChange Then
                Dim wsu As New CTPA.Entities.WSUpdate(d.AUTOID.ToString(), "Employee")
                wsu.UpdateCmd = d.updateCommand
                wsu.ChangeDesc = d.updateDesc
                wsu.Update()
            End If
        End If

        showGrid(True)
        showButtons(False, False)
        Label1.Visible = False
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNo.Click
        Button4_Click(sender, e)
    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        btnBack.Visible = True
        If LinkButton1.Text = "Show Inactive Employees" Then
            SqlDataSource1.SelectCommand = ActiveSelect
        Else
            SqlDataSource1.SelectCommand = InactiveSelect
        End If
        showGrid(True)
        showButtons(False, False)
        Label1.Visible = False
        LabelCommit.Visible = False
        If Session("Renewal") = "true" Then
            Response.Redirect("~/AADTOnline/Renewals/default.aspx")
        End If
    End Sub

    Private Sub showGrid(ByVal gridOn As Boolean)
        If (gridOn) Then
            dv = getDataView
            Dim sbSortExpression As New StringBuilder
            If SortExpression.Count > 0 Then
                Dim myKeys(SortExpression.Count) As String
                SortExpression.Keys.CopyTo(myKeys, 0)
                For i As Integer = 0 To SortExpression.Count - 1
                    sbSortExpression.Append(myKeys(i))
                    sbSortExpression.Append(" ")
                    sbSortExpression.Append(SortExpression(myKeys(i)))
                    If i <> SortExpression.Count - 1 Then
                        sbSortExpression.Append(", ")
                    End If
                Next
                ' usually we would send that sort-expression now to SQL via some stored-procedure
                dv.Sort = sbSortExpression.ToString
            Else
                dv.Sort = String.Empty
            End If
            ' dv = SqlDataSource1.Select(DataSourceSelectArguments.Empty)
            'CTPA.Common.ModeratedDVUpdater.UpdateDataview(dv, "Employee")
            'dv.Sort = GridView1.SortExpression
            GridView1.DataSource = dv
            GridView1.DataBind()
        End If
        GridView1.Visible = gridOn
        LinkButton1.Visible = gridOn
        txtFirstName.Visible = Not (gridOn)
        txtMidName.Visible = Not (gridOn)
        txtLastName.Visible = Not (gridOn)
        txtJrSr.Visible = Not (gridOn)
        txtHomePhone.Visible = Not (gridOn)
        txtCellPhone.Visible = Not (gridOn)
        txtAddy1.Visible = Not (gridOn)
        txtAddy2.Visible = Not (gridOn)
        txtCity.Visible = Not (gridOn)
        txtState.Visible = Not (gridOn)
        txtZip.Visible = Not (gridOn)
        txtEmerphone.Visible = Not (gridOn)
        txtSSN.Visible = Not (gridOn)
        txtCDL.Visible = Not (gridOn)
        txtDOB.Visible = Not (gridOn)
        txtTitle.Visible = Not (gridOn)
        txtHireDate.Visible = Not (gridOn)
        lblActiveDate.Visible = Not (gridOn)
        Label24.Visible = Not (gridOn)
        Label25.Visible = Not (gridOn)
        Label18.Visible = Not (gridOn)
        Label19.Visible = Not (gridOn)
        Label20.Visible = Not (gridOn)
        Label21.Visible = Not (gridOn)
        Label22.Visible = Not (gridOn)
        Label2.Visible = Not (gridOn)
        Label3.Visible = Not (gridOn)
        Label4.Visible = Not (gridOn)
        Label5.Visible = Not (gridOn)
        Label6.Visible = Not (gridOn)
        Label7.Visible = Not (gridOn)
        Label8.Visible = Not (gridOn)
        Label9.Visible = Not (gridOn)
        Label10.Visible = Not (gridOn)
        Label11.Visible = Not (gridOn)
        Label12.Visible = Not (gridOn)
        Label17.Visible = Not (gridOn)
        ListBox1.Visible = Not (gridOn)
        Label23.Visible = Not (gridOn)
        Label13.Visible = gridOn
        Button1.Visible = gridOn
        LabelPoolLegend.Visible = Not (gridOn)
    End Sub

    Private Sub showButtons(ByVal UpdateButtons As Boolean, ByVal CommitButtons As Boolean)
        btnUpdate.Visible = UpdateButtons
        btnCancel.Visible = UpdateButtons
        btnYes.Visible = CommitButtons
        btnNo.Visible = CommitButtons
        btnOOS.Visible = UpdateButtons
        btnDeactivate.Visible = UpdateButtons
        txtFirstName.ReadOnly = CommitButtons
        txtMidName.ReadOnly = CommitButtons
        txtLastName.ReadOnly = CommitButtons
        txtJrSr.ReadOnly = CommitButtons
        txtHomePhone.ReadOnly = CommitButtons
        txtCellPhone.ReadOnly = CommitButtons
        txtAddy1.ReadOnly = CommitButtons
        txtAddy2.ReadOnly = CommitButtons
        txtCity.ReadOnly = CommitButtons
        txtState.ReadOnly = CommitButtons
        txtZip.ReadOnly = CommitButtons
        txtSSN.ReadOnly = CommitButtons
        txtDOB.ReadOnly = CommitButtons
        txtCDL.ReadOnly = CommitButtons
        txtTitle.ReadOnly = CommitButtons
        txtHireDate.ReadOnly = CommitButtons

    End Sub

    Private Function getDriver() As CTPA.Entities.Driver
        Dim d As New CTPA.Entities.Driver(Convert.ToInt32(DriverID.Text))
        Select Case ListBox1.Text
            Case "1-GENERAL CD POOL"
                d.POOLID = 1
            Case "2-GENERAL OWNER OPERATOR POOL"
                d.POOLID = 2
            Case "3-GENERAL DRUG FREE POOL"
                d.POOLID = 3
            Case "4-GENERAL PUC POOL"
                d.POOLID = 4
            Case "5-GENERAL PUC OO"
                d.POOLID = 5
            Case "9-CD POOL - 9970"
                d.POOLID = 9
            Case "10-DF POOL - 9970"
                d.POOLID = 10
            Case "11-DF POOL - 2710"
                d.POOLID = 11
            Case "12-DF Pool PUC"
                d.POOLID = 12
            Case "13-CD POOL - 1035"
                d.POOLID = 13
            Case "14-DF POOL - 1294"
                d.POOLID = 14
            Case "15-CD POOL 878"
                d.POOLID = 15
            Case "16-DF POOL 8125"
                d.POOLID = 16
            Case "17-DF POOL - 2662"
                d.POOLID = 17
            Case "18-DF POOL - TOW POOL CD"
                d.POOLID = 18
            Case "19-DF POOL - TOW POOL O-O"
                d.POOLID = 19
            Case "20-DF Pool - 2254"
                d.POOLID = 20
            Case "21-TEXAS TDLR CE"
                d.POOLID = 21
            Case "22-TEXAS TDLR O-O"
                d.POOLID = 22
            Case "23-DF 50"
                d.POOLID = 23
            Case Else
                d.POOLID = 1
        End Select
        d.FIRSTNAME = txtFirstName.Text
        d.MIDDLENAME = txtMidName.Text
        d.LASTNAME = txtLastName.Text
        d.TITLENAME = txtJrSr.Text
        d.HOMEPHONE = txtHomePhone.Text
        d.CELLPHONE = txtCellPhone.Text
        d.ADDRESS1 = txtAddy1.Text
        d.ADDRESS2 = txtAddy2.Text
        d.CITY = txtCity.Text
        d.STATE = txtState.Text
        d.ZIP = txtZip.Text
        d.TITLENAME = txtTitle.Text
        'd.SS_NUM = txtSSN.Text
        d.CDL_NUM = txtCDL.Text
        If d.BIRTH_DATE <> txtDOB.Text Then
            d.BIRTH_DATE = Date.Parse(txtDOB.Text)
        End If
        If d.HIREDT <> txtHireDate.Text Then
            d.HIREDT = Date.Parse(txtHireDate.Text)
        End If
        Return d
    End Function


    Protected Sub Button5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOOS.Click
        Session("OOSDriver") = DriverID.Text
        Response.Redirect("OOS.aspx")
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        If LinkButton1.Text = "Show Inactive Employees" Then
            LinkButton1.Text = "Show Active Employees"
            SqlDataSource1.SelectCommand = InactiveSelect
            Active = True
        Else
            LinkButton1.Text = "Show Inactive Employees"
            SqlDataSource1.SelectCommand = ActiveSelect
            Active = False
        End If
        GridView1.DataBind()
        showGrid(True)
        If Active = True Then
            GridView1.Columns(5).Visible = False
            GridView1.Columns(7).Visible = True
            GridView1.DataBind()
            Button1.Enabled = False

        Else
            GridView1.Columns(5).Visible = True
            GridView1.Columns(7).Visible = False
            GridView1.DataBind()
            Button1.Enabled = True
        End If
    End Sub

    Protected Sub Button6_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDeactivate.Click
        Dim d As New CTPA.Entities.Driver(Convert.ToInt32(DriverID.Text))
        If LinkButton1.Text = "Show Inactive Employees" Then
            If d.hasPendingChange() Then
                Label1.Text = "There is already a pending change for this employee.  Cannot request deactivation at this time."
            Else
                ' Must deactivate driver
                Dim wsu As New CTPA.Entities.WSUpdate
                d.INACTIVE = Date.Today()
                wsu.ChangeType = "Employee"
                wsu.ChangeRecordKey = d.AUTOID
                wsu.Pending = True
                wsu.TimeRequested = DateTime.Now()
                wsu.username = Membership.GetUser.UserName
                wsu.ChangeDesc = d.updateDesc
                wsu.UpdateCmd = d.updateCommand
                wsu.Insert()
                Dim RepID As Integer = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, Data.CommandType.Text, "Select SERVREPID From CALDATA_TBL Where COMP_ID = " & Profile.CompID)
                Dim prams(1) As SqlParameter
                prams(0) = New SqlParameter("@RepID", SqlDbType.Int)
                prams(0).Value = RepID
                prams(1) = New SqlParameter("@ChangeKey", SqlDbType.Int)
                prams(1).Value = d.AUTOID
                SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.SetChangeRepID", prams)
                Label1.Text = "Your request to deactivate this employee has been submitted."
            End If
        Else
            If d.hasPendingChange() Then
                Label1.Text = "There is already a pending change for this employee.  Cannot request reactivation at this time."
            Else
                ' Must reactivate driver
                Dim wsu As New CTPA.Entities.WSUpdate
                d.INACTIVE = ""
                wsu.ChangeType = "Employee"
                wsu.ChangeRecordKey = d.AUTOID
                wsu.Pending = True
                wsu.TimeRequested = DateTime.Now()
                wsu.username = Membership.GetUser.UserName
                wsu.ChangeDesc = d.updateDesc
                wsu.UpdateCmd = d.updateCommand
                wsu.Insert()
                Dim RepID As Integer = SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, Data.CommandType.Text, "Select SERVREPID From CALDATA_TBL Where COMP_ID = " & Profile.CompID)
                Dim prams(1) As SqlParameter
                prams(0) = New SqlParameter("@RepID", SqlDbType.Int)
                prams(0).Value = RepID
                prams(1) = New SqlParameter("@ChangeKey", SqlDbType.Int)
                prams(1).Value = d.AUTOID
                SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.SetChangeRepID", prams)
                Label1.Text = "Your request to reactivate this employee has been submitted."
            End If
        End If
        showGrid(True)
        showButtons(False, False)
    End Sub

    Protected Sub Button7_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBack.Click
        If Session("Renewal") = "true" Then
            Response.Redirect("~/AADTOnline/renewals/frmEmployees.aspx")
        End If
        Response.Redirect("~/AADTOnline/Default.aspx")
    End Sub

    Protected Sub Button8_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUndo.Click
        DriverID.Text = GridView1.SelectedRow.Cells(8).Text
        Dim d As New CTPA.Entities.Driver(Convert.ToInt32(DriverID.Text))
        Dim prams(0) As SqlParameter
        prams(0) = New SqlParameter("@EMP_ID", SqlDbType.BigInt)
        prams(0).Value = DriverID.Text
        SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.WS_UPDATES_EMP_Delete", prams)
        btnUndo.Visible = False
        Response.Redirect("employees.aspx")
    End Sub

    Private Function buildPoolListBox()
        Dim PoolArray(25, 1) As String
        Dim index As Integer = -1
        For Each poolName As String In CTPA.Common.Config.poolNames.Keys
            index += 1
            Dim poolID As Integer = CTPA.Common.Config.poolNames(poolName)
            Dim custPools() As Integer = {9, 10, 11, 13, 14, 17, 20}
            If Array.BinarySearch(custPools, poolID) >= 0 Then
                ' If this is one of the custom pools, check that the poolname has this company ID before adding it to the listbox
                If poolName.Split(" ")(poolName.Split(" ").Length - 1).Contains(Profile.CompID.ToString) Then
                    ListBox1.Items.Add(poolName)
                    PoolArray(index, 0) = poolID
                    PoolArray(index, 1) = poolName
                End If
            Else
                ListBox1.Items.Add(poolName)
                PoolArray(index, 0) = poolID
                PoolArray(index, 1) = poolName
            End If
        Next
        Return PoolArray
    End Function

    Protected Sub Button1_Click1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Response.Redirect("NewDriver.aspx")
    End Sub
End Class
