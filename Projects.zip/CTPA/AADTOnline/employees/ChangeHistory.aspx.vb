
Partial Class AADTOnline_employees_ChangeHistory
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label2.Text = Profile.CompID
    End Sub
End Class
