﻿// JScript File


///This function simply sets the end date to two weeks after the start date when the start date is entered
function EndDateFocus()
{
    var StartField =  document.getElementById("ctl00$ContentPlaceHolder1$Startdate");
    var EndField = document.getElementById("ctl00$ContentPlaceHolder1$EndDate");
    var endDate = new Date(1970,0,1);
   
    if( StartField && EndField )
    {
        var endMonth = StartField.value.toString().split('/')[0] - 1;
        var endDay = StartField.value.toString().split('/')[1];
        var endYear = StartField.value.toString().split('/')[2];
        var addDate = new Date();
        addDate.setFullYear(1970, 0, 15);
        if ( endMonth && endDate && endYear )
        {
            endDate.setMilliseconds( Date.UTC(1970,0,15) + Date.UTC(endYear,endMonth, endDay ));
            EndField.value = (endDate.getMonth() + 1).toString() + '/' + endDate.getDate().toString() + '/' + endDate.getFullYear().toString();
        }
    }
}