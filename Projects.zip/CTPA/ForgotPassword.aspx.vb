
Partial Class ForgotPassword
    Inherits System.Web.UI.Page

End Class
