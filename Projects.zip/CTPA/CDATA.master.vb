
Partial Class CDATA
    Inherits System.Web.UI.MasterPage
End Class

