Imports Microsoft.VisualBasic
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System
Imports System.Security.Cryptography
Imports System.IO
Imports System.Collections.Generic
Imports org.pdfbox.pdmodel
Imports org.pdfbox.util
Imports org.pdfbox.pdmodel.interactive.documentnavigation.destination
Imports org.pdfbox.pdmodel.interactive.documentnavigation.outline
Imports java.util

Public Class CDataFunctions

    Public Shared Spaces As String() = {" "}

    Public Shared Function emailNewUser(ByVal userid As String) As Boolean
        Return False
    End Function

    Public Shared Function getFieldUpdateQuery(ByRef tb As TextBox, ByVal fieldName As String, ByVal queryString As String, ByRef dv As System.Data.DataView) As String
        Dim newQueryString As String
        newQueryString = queryString
        If (Not (dv.Table.Rows(0).Item(fieldName) Is System.DBNull.Value) AndAlso dv.Table.Rows(0).Item(fieldName) <> tb.Text) OrElse _
          (dv.Table.Rows(0).Item(fieldName) Is System.DBNull.Value) And tb.Text <> "" Then
            newQueryString = newQueryString & IIf(newQueryString <> "", ", ", "") & "[" & fieldName & "] = '" & tb.Text & "'"
        End If
        Return newQueryString
    End Function

    Public Shared Function getFieldUpdateDescription(ByRef tb As TextBox, ByVal fieldName As String, ByVal updateString As String, ByRef dv As System.Data.DataView) As String
        Dim newUpdateString As String
        newUpdateString = updateString
        If (Not (dv.Table.Rows(0).Item(fieldName) Is System.DBNull.Value) AndAlso dv.Table.Rows(0).Item(fieldName) <> tb.Text) OrElse _
          (dv.Table.Rows(0).Item(fieldName) Is System.DBNull.Value) And tb.Text <> "" Then
            newUpdateString = newUpdateString & fieldName & " changed from """ & dv.Table.Rows(0).Item(fieldName) & """ to """ & tb.Text & """;"
        End If
        Return newUpdateString
    End Function

    Public Shared Sub populateField(ByVal dbFieldName As String, ByRef pageField As TextBox, ByRef dv As System.Data.DataView)
        If Not (dv.Table.Rows(0).Item(dbFieldName) Is System.DBNull.Value) Then
            pageField.Text = dv.Table.Rows(0).Item(dbFieldName)
        Else
            pageField.Text = ""
        End If
    End Sub


    Public Shared Function SelectReport(ByVal GroupID, ByVal Notice)
        Dim strReportName As String = Nothing
        If Notice = 1 Then
            Select Case GroupID
                Case 1
                    strReportName = "/FirstNoticeCD"
                Case 2
                    strReportName = "/FirstNoticeOO"
                Case 3
                    strReportName = "/FirstNoticeDF"
                Case 4
                    strReportName = "/FirstNoticePUC"
                Case 5
                    strReportName = "/FirstNoticePUCOO"
                Case 9
                    strReportName = "/FirstNoticeCD"
                Case 10
                    strReportName = "/FirstNoticeDF"
                Case 13
                    strReportName = "/FirstNoticeCD"
                Case 14
                    strReportName = "/FirstNoticeDF"
                Case 16
                    strReportName = "/FirstNoticeDF"
                Case 17
                    strReportName = "/FirstNoticeDF"
                Case 18
                    strReportName = "/FirstNoticeDF"
                Case 19
                    strReportName = "/FirstNoticeDF"
                Case 20
                    strReportName = "/FirstNoticeDF"
                Case 21
                    strReportName = "/FirstNoticeTDLR"
                Case 22
                    strReportName = "/FirstNoticeTDLROO"
                Case 23
                    strReportName = "/FirstNoticeDF"
                Case 24
                    strReportName = "/FirstNoticeDF"
            End Select
        ElseIf Notice = 2 Then
            Select Case GroupID
                Case 1
                    strReportName = "/SecondNoticeCDDF"
                Case 2
                    strReportName = "/SecondNoticeOO"
                Case 3
                    strReportName = "/SecondNoticeCDDF"
                Case 4
                    strReportName = "/SecondNoticeOO"
                Case 5
                    strReportName = "/SecondNoticeCDDF"
                Case 9
                    strReportName = "/SecondNoticeCDDF"
                Case 10
                    strReportName = "/SecondNoticeCDDF"
                Case 13
                    strReportName = "/SecondNoticeCDDF"
                Case 14
                    strReportName = "/SecondNoticeCDDF"
                Case 16
                    strReportName = "/SecondNoticeCDDF"
                Case 17
                    strReportName = "/SecondNoticeCDDF"
                Case 18
                    strReportName = "/SecondNoticeCDDF"
                Case 19
                    strReportName = "/SecondNoticeCDDF"
                Case 21
                    strReportName = "/SecondNoticeCDDF"
                Case 22
                    strReportName = "/SecondNoticeTDLROO"
                Case 23
                    strReportName = "/SecondNoticeCDDF"
                Case 20
                    strReportName = "/SecondNoticeCDDF"
                Case 24
                    strReportName = "/SecondNoticeCDDF"
            End Select
        Else
            Select Case GroupID
                Case 1
                    strReportName = "/FinalNoticeCD"
                Case 2
                    strReportName = "/FinalNoticeOO"
                Case 3
                    strReportName = "/FinalNoticeDF"
                Case 4
                    strReportName = "/FinalNoticePUC"
                Case 5
                    strReportName = "/FinalNoticePUCOO"
                Case 9
                    strReportName = "/FinalNoticeCD"
                Case 10
                    strReportName = "/FinalNoticeDF"
                Case 13
                    strReportName = "/FinalNoticeCD"
                Case 14
                    strReportName = "/FinalNoticeDF"
                Case 16
                    strReportName = "/FinalNoticeDF"
                Case 17
                    strReportName = "/FinalNoticeDF"
                Case 18
                    strReportName = "/FinalNoticeDF"
                Case 19
                    strReportName = "/FinalNoticeDF"
                Case 21
                    strReportName = "/FinalNoticeTDLR"
                Case 22
                    strReportName = "/FinalNoticeTDLROO"
                Case 23
                    strReportName = "/FinalNoticeDF"
                Case 20
                    strReportName = "/FinalNoticeDF"
                Case 24
                    strReportName = "/FinalNoticeDF"

            End Select
        End If
        Return strReportName
    End Function

    Public Shared Function SelectAlcReport(ByVal GroupID, ByVal Notice)
        Dim strReportName As String = Nothing
        If Notice = 2 Then
            Select Case GroupID
                Case 1
                    strReportName = "/SecondNoticeCDDFAlc"
                Case 2
                    strReportName = "/SecondNoticeOOAlc"
                Case 3
                    strReportName = "/SecondNoticeCDDFAlc"
                Case 4
                    strReportName = "/SecondNoticeCDDFAlc"
                Case 5
                    strReportName = "/SecondNoticeOOAlc"
                Case 9
                    strReportName = "/SecondNoticeCDDFAlc"
                Case 10
                    strReportName = "/SecondNoticeCDDFAlc"
                Case 13
                    strReportName = "/SecondNoticeCDDFAlc"
                Case 14
                    strReportName = "/SecondNoticeCDDFAlc"
                Case 16
                    strReportName = "/SecondNoticeCDDFAlc"
                Case 17
                    strReportName = "/SecondNoticeCDDFAlc"
                Case 18
                    strReportName = "/SecondNoticeCDDFAlc"
                Case 19
                    strReportName = "/SecondNoticeCDDFAlc"
                Case 20
                    strReportName = "/SecondNoticeCDDFAlc"
                Case 21
                    strReportName = "/SecondNoticeCDDFAlc"
                Case 22
                    strReportName = "/SecondNoticeTDLROOAlc"
                Case 23
                    strReportName = "/SecondNoticeCDDFAlc"
                Case 24
                    strReportName = "/SecondNoticeCDDFAlc"
            End Select
        Else
            Select Case GroupID
                Case 1
                    strReportName = "/FinalNoticeCDAlc"
                Case 2
                    strReportName = "/FinalNoticeOOAlc"
                Case 3
                    strReportName = "/FinalNoticeDFAlc"
                Case 4
                    strReportName = "/FinalNoticePUCAlc"
                Case 5
                    strReportName = "/FinalNoticePUCOOAlc"
                Case 9
                    strReportName = "/FinalNoticeCDAlc"
                Case 10
                    strReportName = "/FinalNoticeDFAlc"
                Case 13
                    strReportName = "/FinalNoticeCDAlc"
                Case 14
                    strReportName = "/FinalNoticeDFAlc"
                Case 16
                    strReportName = "/FinalNoticeDFAlc"
                Case 17
                    strReportName = "/FinalNoticeDFAlc"
                Case 18
                    strReportName = "/FinalNoticeDFAlc"
                Case 19
                    strReportName = "/FinalNoticeDFAlc"
                Case 20
                    strReportName = "/FinalNoticeDFAlc"
                Case 21
                    strReportName = "/FinalNoticeTDLRAlc"
                Case 22
                    strReportName = "/FinalNoticeTDLROOAlc"
                Case 23
                    strReportName = "/FinalNoticeDFAlc"
                Case 24
                    strReportName = "/FinalNoticeDFAlc"
            End Select
        End If
        Return strReportName
    End Function
    Public Shared Function SelectPassport(ByVal Notice)
        Dim strReportName As String = Nothing
        Select Case Notice
            Case 1
                strReportName = "/Passport"
            Case 2
                strReportName = "/Passport2ndNotice"
            Case 3
                strReportName = "/PassportFinalNotice"
        End Select
        Return strReportName
    End Function
    Public Shared Function SelectAlcPassport(ByVal Notice)
        Dim strReportName As String = Nothing
        Select Case Notice
            Case 2
                strReportName = "/Passport2ndNoticeAlc"
            Case 3
                strReportName = "/PassportFinalNoticeAlc"
        End Select
        Return strReportName
    End Function

    Public Shared Function CatchError(ByVal Message, ByVal Source, ByVal StackTrace, ByVal TargetSite, ByVal HelpLink, ByVal InnerException, ByVal BaseException)
        Dim ds As New ErLog.ErrorLogDataTable
        Dim da As New ErLogTableAdapters.ErrorLogTableAdapter
        Dim ErFlag As Boolean

        da.Fill(ds)
        Dim dr As Data.DataRow
        dr = ds.NewRow
        dr("ErrorID") = Guid.NewGuid()
        dr("ErrorDate") = Now()
        dr("Source") = Source
        dr("Message") = Message
        dr("StackTrace") = StackTrace
        dr("TargetSite") = TargetSite
        dr("HelpLink") = HelpLink
        dr("InnerException") = InnerException
        dr("BaseException") = BaseException
        ds.Rows.Add(dr)
        da.Update(ds)
        CTPA.Common.Emailer.ErLogEmail(True)
        Return ErFlag
    End Function

    Public Shared Function MergePdfFiles(ByVal pdfFileList As List(Of String), ByVal outputFileFullName As String) As Boolean
        Dim result As Boolean = False
        Dim pdfMerger As PDFMergerUtility = Nothing
        Dim fileCount As Integer = pdfFileList.Count
        If fileCount > 1 Then
            Try
                pdfMerger = New PDFMergerUtility()
                With pdfMerger
                    .setDestinationFileName(outputFileFullName)
                    For i As Integer = 0 To fileCount - 1 Step 1
                        .addSource(pdfFileList(i))
                    Next
                    pdfMerger.mergeDocuments()
                    result = True

                End With
            Catch
                Return False
            End Try
        End If
        Return result
    End Function
End Class




'Public Shared Function GetTicket(ByVal TotalDrivers As Integer) As Integer
'    ' Create a byte array to hold the random value.
'    Dim Ticket As Int32
'    Dim randomNumber(4) As Byte

'    ' Create a new instance of the RNGCryptoServiceProvider. 
'    Dim Gen As New RNGCryptoServiceProvider()

'    ' Fill the array with a random value.
'    Gen.GetBytes(randomNumber)

'    ' Convert the byte to an integer value to make the modulus operation easier.
'    Dim rand As Long
'    rand = System.BitConverter.ToInt32(randomNumber, 0)
'    ' Return the random number mod the number
'    ' of sides.  The possible values are zero-
'    ' based, so we add one.
'    Ticket = rand Mod TotalDrivers
'    Ticket = Math.Abs(Ticket)
'    Return Ticket
'End Function

'Public Class UsersTableDataSource
'    Inherits DataSourceControl
'    Private myTable As System.Data.DataTable

'    Public Property table() As System.Data.DataTable
'        Get
'            Return myTable
'        End Get
'        Set(ByVal value As System.Data.DataTable)
'            myTable = value
'        End Set
'    End Property

'    Protected Overrides Function GetView(ByVal viewName As String) As System.Web.UI.DataSourceView
'        Return New UsersTableDataSourceView(Me, viewName)
'    End Function
'End Class


'Public Class UsersTableDataSourceView
'    Inherits DataSourceView


'    Public Sub New(ByVal owner As System.Web.UI.DataSourceControl, ByVal viewName As String)
'        MyBase.New(owner, viewName)
'    End Sub

'    Protected Overrides Function ExecuteSelect(ByVal arguments As System.Web.UI.DataSourceSelectArguments) As System.Collections.IEnumerable
'        Dim dt As New System.Data.DataTable("Unverified")
'        Dim dv As New System.Data.DataView(dt)
'        dt.Columns.Add("Company")
'        dt.Columns.Add("FullName")
'        dt.Columns.Add("Email")
'        dt.Columns.Add("UserName")
'        Dim dr As Data.DataRow
'        For Each accountName As String In Roles.GetUsersInRole("Unverified")
'            dr = dt.NewRow()
'            dr("UserName") = accountName
'            dr("Company") = IIf(Profile.GetProfile(accountName).CompanyName Is Nothing, "", Profile.GetProfile(accountName).CompanyName)
'            dr("FullName") = IIf(Profile.GetProfile(accountName).FullName Is Nothing, "", Profile.GetProfile(accountName).FullName)
'            dr("Email") = IIf(Membership.GetUser(accountName).Email Is Nothing, "", Membership.GetUser(accountName).Email)
'            dt.Rows.Add(dr)
'        Next
'    End Function
'End Class