
Partial Class Unverified_Default
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim memUser As MembershipUser
        Dim compIDNum As Int32
        memUser = Membership.GetUser()
        Profile.CompanyName = TextBox1.Text
        Profile.FullName = TextBox2.Text
        Profile.Address1 = TextBox3.Text
        Profile.City = TextBox5.Text
        Profile.State = TextBox6.Text
        Profile.ZIP = TextBox7.Text
        Profile.ContactPhoneNum = TextBox9.Text
        Profile.ContactPhoneExt = TextBox10.Text
        Profile.ContactMobile = TextBox11.Text
        If chkInvoices.Checked = True Then
            Profile.EmailInvoice = "true"
        Else
            Profile.EmailInvoice = "false"
        End If
        If chkRenewals.Checked = True Then
            Profile.EmailRenewal = "true"
        Else
            Profile.EmailRenewal = "false"
        End If
        If chkRandoms.Checked = True Then
            Profile.EmailRandom = "true"
        Else
            Profile.EmailRandom = "false"
        End If

        If Int32.TryParse(TextBox4.Text, compIDNum) Then
            Profile.CompID = compIDNum
        End If
        memUser.Email = TextBox8.Text
        Membership.UpdateUser(memUser)
        Profile.Save()
        TextBox1.Enabled = False
        TextBox2.Enabled = False
        TextBox3.Enabled = False
        TextBox4.Enabled = False
        TextBox5.Enabled = False
        TextBox6.Enabled = False
        TextBox7.Enabled = False
        TextBox8.Enabled = False
        TextBox9.Enabled = False
        TextBox10.Enabled = False
        TextBox11.Enabled = False
        chkInvoices.Enabled = False
        chkRenewals.Enabled = False
        chkRandoms.Enabled = False

        Label1.Text = "Account information saved.  Once your information is processed, you will be able to log in and use " & CTPA.Common.Config.ProgramName & ".  Please wait 24-48 hours."
        Label1.Visible = True
        OKButton.Visible = True
        Button1.Visible = False
        CTPA.Common.Emailer.PendingStatusNotifyByEmail(Membership.GetUser(Profile.UserName), True, Membership.GetUser.UserName)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Roles.IsUserInRole(Membership.GetUser.UserName, "Verified") Then
            Response.Redirect("~/AADTOnline/")
        End If
        If Not Page.IsPostBack() Then
            Button1.Focus()
            Label1.Visible = False
            OKButton.Visible = False
            TextBox1.Text = IIf(Profile.CompanyName Is Nothing, "Nothing", Profile.CompanyName)
            TextBox2.Text = IIf(Profile.FullName Is Nothing, "", Profile.FullName)
            TextBox3.Text = IIf(Profile.Address1 Is Nothing, "", Profile.Address1)
            TextBox4.Text = IIf(Profile.CompID = Nothing, "", Profile.CompID)
            TextBox5.Text = IIf(Profile.City Is Nothing, "", Profile.City)
            TextBox6.Text = IIf(Profile.State Is Nothing, "", Profile.State)
            TextBox7.Text = IIf(Profile.ZIP Is Nothing, "", Profile.ZIP)
            TextBox8.Text = IIf(Membership.GetUser().Email Is Nothing, "", Membership.GetUser().Email)
            TextBox9.Text = IIf(Profile.ContactPhoneNum Is Nothing, "", Profile.ContactPhoneNum)
            TextBox10.Text = IIf(Profile.ContactPhoneExt Is Nothing, "", Profile.ContactPhoneExt)
            TextBox11.Text = IIf(Profile.ContactMobile Is Nothing, "", Profile.ContactMobile)
            If (Profile.EmailInvoice = Nothing Or Profile.EmailInvoice = "false") Then
                chkInvoices.Checked = True
            Else
                chkInvoices.Checked = False
            End If
            If (Profile.EmailRenewal = Nothing Or Profile.EmailRenewal = "false") Then
                chkRenewals.Checked = True
            Else
                chkRenewals.Checked = False
            End If
            If (Profile.EmailRandom = Nothing Or Profile.EmailRandom = "false") Then
                chkRandoms.Checked = True
            Else
                chkRandoms.Checked = False
            End If
        End If
    End Sub

    Protected Sub OKButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles OKButton.Click
        FormsAuthentication.SignOut()
        Response.Redirect("Login.aspx")
    End Sub
End Class
