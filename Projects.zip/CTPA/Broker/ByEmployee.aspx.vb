Imports RenewalStatementWebSvc.ReportingService2005
Imports microsoft.reporting.webforms
Imports System.Security.Cryptography
Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data
Partial Class AADTOnline_Broker_Default
    Inherits System.Web.UI.Page
    Public Shared AgreementID As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label2.Text = Profile.BrokerID
        GridView2.Visible = False
        Label3.Visible = False
        Button2.Visible = False
        Button3.Visible = False
    End Sub
    'Public Sub GridView1_OnRowCreated(ByVal sender As Object, ByVal e As Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowCreated

    '    'Those columns you don't want to display you config here,

    '    'you could use a for statement if you have many :)
    '    If e.Row.RowType = DataControlRowType.DataRow Then
    '        e.Row.Cells(8).Visible = False
    '    End If


    'End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Button1.Text = "Inactive" Then
            Label1.Text = "Inactive Agreements"
            Button1.Text = "Active"
            GridView1.Visible = False
            GridView2.Visible = True
            Label4.Text = "Click the Active button below to view active agreements"
        Else
            Label1.Text = "Active Agreements"
            Button1.Text = "Inactive"
            GridView1.Visible = True
            GridView2.Visible = False
            Label4.Text = "Click the Inactive button below to view inactive agreements<br>Click Revoke to Revoke an Agreement"
        End If
    End Sub
    Protected Sub RevokeAgreement(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName = "Revoke" Then
            ' Get the last name of the selected author from the appropriate
            ' cell in the GridView control
            Dim index As Integer = Convert.ToInt32(e.CommandArgument)
            Dim selectedRow As GridViewRow = GridView1.Rows(index)
            Dim Agreement As TableCell = selectedRow.Cells(8)
            AgreementID = Agreement.Text
            Label3.Visible = True
            Button2.Visible = True
            Button3.Visible = True
            Button2.Focus()
        End If
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim prams(0) As SqlParameter
        prams(0) = New SqlParameter("@AgreementID", SqlDbType.NVarChar)
        prams(0).Value = AgreementID
        SqlHelper.ExecuteScalar(CTPA.Common.Config.ConnectionString, CommandType.StoredProcedure, "dbo.RevokeAgreement", prams)
        Response.Redirect("ByEmployee.aspx")
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Response.Redirect("Default.aspx")
    End Sub

    Protected Sub gridview1_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If (e.Row.DataItemIndex Mod 2) = 0 Then
                e.Row.BackColor = Drawing.Color.LightGray
            Else
                e.Row.BackColor = Drawing.Color.Gray
            End If
            If e.Row.RowType = DataControlRowType.DataRow Then
                Dim txtInactive As Label
                txtInactive = e.Row.Cells(7).Controls(1)
                If txtInactive.Text <> "" Then
                    e.Row.BackColor = Drawing.Color.HotPink
                End If
            End If
        Else
            If e.Row.RowType = DataControlRowType.Header Then
                e.Row.ForeColor = Drawing.Color.Black
            End If
            e.Row.BackColor = Drawing.Color.SlateGray
        End If

    End Sub

End Class
