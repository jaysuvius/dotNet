Imports RenewalStatementWebSvc.ReportingService2005
Imports microsoft.reporting.webforms
Imports System.Security.Cryptography
Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data
Partial Class Broker_BrokerForms
    Inherits System.Web.UI.Page
    Public Shared AgreementID As String
    Public Shared BrokerID As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label1.Text = Profile.BrokerID
        'Dim parm1(0) As ReportParameter
        'parm1(0) = New Microsoft.Reporting.WebForms.ReportParameter("AgreementID", AgreementID)
        'ReportViewer1.ServerReport.SetParameters(parm1)
        'ReportViewer1.ShowParameterPrompts = False
    End Sub
    Protected Sub SelectAgreement(ByVal sender As Object, ByVal e As GridViewCommandEventArgs)
        If e.CommandName = "SelectAgreement" Then
            ' Select the correct Agreement based on logged in Broker
            Dim index As Integer = Convert.ToInt32(e.CommandArgument)
            Dim selectedRow As GridViewRow = GridView1.Rows(index)
            Dim Agreement As TableCell = selectedRow.Cells(6)
            AgreementID = Agreement.Text
            BrokerID = Profile.BrokerID
            'Dim prams(0) As SqlParameter
            'prams(0) = New SqlParameter("@AgreementID", SqlDbType.NVarChar)
            'prams(0).Value = AgreementID
            Session("AgreementID") = AgreementID
            Session("BrokerID") = BrokerID
            Response.Redirect("ShowBrokerForms.aspx")
        End If
    End Sub

    'Protected Sub rbtnliChooseForm_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtnliChooseForm.SelectedIndexChanged
    '    AgreementID = Session("AgreementID")
    '    'Dim prams(0) As SqlParameter
    '    'prams(0) = New SqlParameter("@AgreementID", SqlDbType.NVarChar)
    '    'prams(0).Value = AgreementID

    '    ReportViewer1.Visible = True

    '    If rbtnliChooseForm.Items(0).Selected Then
    '        ReportViewer1.ServerReport.ReportPath = "/Form500"
    '        Dim pInfo As ReportParameterInfoCollection
    '        Dim paramList As New Generic.List(Of ReportParameter)
    '        paramList.Add(New ReportParameter("AgreementID", AgreementID, False))
    '        ReportViewer1.ServerReport.SetParameters(paramList)
    '        pInfo = ReportViewer1.ServerReport.GetParameters()
    '        ' Process and render the report
    '        ReportViewer1.ServerReport.Refresh()

    '    Else
    '        If rbtnliChooseForm.Items(1).Selected Then
    '            ReportViewer1.ServerReport.ReportPath = "/Form501"
    '        Else
    '            If rbtnliChooseForm.Items(2).Selected Then
    '                ReportViewer1.ServerReport.ReportPath = "/Form502"
    '            Else
    '                If rbtnliChooseForm.Items(3).Selected Then
    '                    ReportViewer1.ServerReport.ReportPath = "/Form503"
    '                Else
    '                    'If rbtnliChooseForm.Items(4) Then
    '                    ReportViewer1.ServerReport.ReportPath = "/Form504"
    '                End If
    '            End If
    '        End If
    '    End If
    'End Sub
    Public Sub GridView1_OnRowCreated(ByVal sender As Object, ByVal e As Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowCreated

        'Those columns you don't want to display you config here,

        'you could use a for statement if you have many :)

        e.Row.Cells(6).Visible = False

    End Sub

End Class
