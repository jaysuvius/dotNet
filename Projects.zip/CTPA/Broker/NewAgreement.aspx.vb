
Partial Class Broker_NewAgreement
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label1.Visible = False
        Button3.Visible = False
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim ds As New DAAgreements.NewDAAgreementsDataTable
        Dim da As New DAAgreementsTableAdapters.NewDAAgreementsTableAdapter

        da.Fill(ds)
        Dim dr As Data.DataRow
        dr = ds.NewRow
        dr("AgreementID") = Guid.NewGuid()
        Session("AgreementID") = dr("AgreementID")
        dr("Company") = txtCompany.Text
        dr("DriverFirst") = txtFname.Text
        dr("DriverLast") = txtLname.Text
        dr("SSNum") = txtEin.Text
        dr("BrokerID") = Profile.BrokerID
        Session("BrokerID") = dr("BrokerID")
        dr("DriverAddress") = txbxDriverAddress.Text
        dr("DriverCiStZip") = txbxCiStZi.Text
        dr("DriverContPhone") = txbxContPhone.Text
        dr("DriverCANum") = txbxCANum.Text
        dr("CDL") = txtCDL.Text
        ds.Rows.Add(dr)
        da.Update(ds)
        Session("Form") = "Form500"
        'txtCompany.Enabled = False
        'txtFname.Enabled = False
        'txtLname.Enabled = False
        'txtCDL.Enabled = False
        'txtEin.Enabled = False
        txtCompany.Text = ""
        txtFname.Text = ""
        txtLname.Text = ""
        txtCDL.Text = ""
        txtEin.Text = ""
        txbxDriverAddress.Text = ""
        txbxCiStZi.Text = ""
        txbxCANum.Text = ""
        txbxContPhone.Text = ""
        Label1.Text = "New agreement request for sent to AADT. <br> Once approved the agreement will appear in your list of active agreements."
        Label1.Visible = True
        Response.Redirect("ShowBrokerForms.aspx")
        'Button3.Visible = True
        'Button1.Enabled = False
        'Button2.Enabled = False
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("Default.aspx")
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Response.Redirect("Default.aspx")
    End Sub
End Class
