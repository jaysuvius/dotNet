
Partial Class Broker_Preferences
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            If Profile.EmailBroker = "True" Then
                CheckBox1.Checked = True
            Else
                CheckBox1.Checked = False
            End If
        End If
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim memUser As MembershipUser
        memUser = Membership.GetUser()
        If CheckBox1.Checked = True Then
            Profile.EmailBroker = "True"
        Else
            Profile.EmailBroker = "False"
        End If
        Membership.UpdateUser(memUser)
        Profile.Save()
    End Sub

    Protected Sub gridview1_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            If (e.Row.DataItemIndex Mod 2) = 0 Then
                e.Row.BackColor = Drawing.Color.LightGray
            Else
                e.Row.BackColor = Drawing.Color.Gray
            End If
        Else
            If e.Row.RowType = DataControlRowType.Header Then
                e.Row.ForeColor = Drawing.Color.Black
            End If
            e.Row.BackColor = Drawing.Color.SlateGray
        End If
    End Sub

End Class
