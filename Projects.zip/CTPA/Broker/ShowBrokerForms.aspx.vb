
Imports System.Security.Cryptography
Imports microsoft.reporting.webforms
Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data

Partial Class Broker_ShowBrokerForms
    Inherits System.Web.UI.Page
    Public Shared AgreementID As String
    Public Shared BrokerID As String

    'Protected Sub rbtnliChooseForm_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtnliChooseForm.SelectedIndexChanged

    '    AgreementID = Session("AgreementID")
    '    BrokerID = Session("BrokerID")
    '    If rbtnliChooseForm.Items(0).Selected Then
    '        ReportViewer1.ServerReport.ReportPath = "/Form500"
    '        Dim pInfo As ReportParameterInfoCollection
    '        Dim paramList As New Generic.List(Of ReportParameter)
    '        paramList.Add(New ReportParameter("AgreementID", AgreementID, False))
    '        paramList.Add(New ReportParameter("BrokerID", BrokerID, False))
    '        ReportViewer1.ServerReport.SetParameters(paramList)
    '        pInfo = ReportViewer1.ServerReport.GetParameters()
    '        '' Process and render the report
    '        'ReportViewer1.ServerReport.Refresh()
    '    Else
    '        If rbtnliChooseForm.Items(1).Selected Then
    '            ReportViewer1.ServerReport.ReportPath = "/Form501"
    '            Dim pInfo As ReportParameterInfoCollection
    '            Dim paramList As New Generic.List(Of ReportParameter)
    '            paramList.Add(New ReportParameter("AgreementID", AgreementID, False))
    '            paramList.Add(New ReportParameter("BrokerID", BrokerID, False))
    '            ReportViewer1.ServerReport.SetParameters(paramList)
    '            pInfo = ReportViewer1.ServerReport.GetParameters()
    '        Else
    '            If rbtnliChooseForm.Items(2).Selected Then
    '                ReportViewer1.ServerReport.ReportPath = "/Form502"
    '                Dim pInfo As ReportParameterInfoCollection
    '                Dim paramList As New Generic.List(Of ReportParameter)
    '                paramList.Add(New ReportParameter("AgreementID", AgreementID, False))
    '                paramList.Add(New ReportParameter("BrokerID", BrokerID, False))
    '                ReportViewer1.ServerReport.SetParameters(paramList)
    '                pInfo = ReportViewer1.ServerReport.GetParameters()
    '            Else
    '                'If rbtnliChooseForm.Items(3).Selected Then
    '                '    ReportViewer1.ServerReport.ReportPath = "/Form503"
    '                'Else
    '                'If rbtnliChooseForm.Items(4) Then
    '                ReportViewer1.ServerReport.ReportPath = "/Form504"
    '                Dim pInfo As ReportParameterInfoCollection
    '                Dim paramList As New Generic.List(Of ReportParameter)
    '                paramList.Add(New ReportParameter("AgreementID", AgreementID, False))
    '                paramList.Add(New ReportParameter("BrokerID", BrokerID, False))
    '                ReportViewer1.ServerReport.SetParameters(paramList)
    '                pInfo = ReportViewer1.ServerReport.GetParameters()
    '            End If
    '        End If
    '    End If
    '    'End If
    '    'End If
    '    ' Process and render the report
    '    ReportViewer1.ServerReport.Refresh()
    'End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            AgreementID = Session("AgreementID").ToString
            BrokerID = Session("BrokerID").ToString
            If Session("Form") = "Form500" Then
                ddlChooseForm.Items(0).Selected = True
                ReportViewer1.ServerReport.ReportPath = "/Form500"
                Dim pInfo As ReportParameterInfoCollection
                Dim paramList As New Generic.List(Of ReportParameter)
                paramList.Add(New ReportParameter("AgreementID", AgreementID, False))
                paramList.Add(New ReportParameter("BrokerID", BrokerID, False))
                ReportViewer1.ServerReport.SetParameters(paramList)
                pInfo = ReportViewer1.ServerReport.GetParameters()
                lblForm500Disclaimer.Visible = True
            Else
                If Session("Form") = "Form502" Then
                    ddlChooseForm.Items(3).Selected = True
                    ReportViewer1.ServerReport.ReportPath = "/Form502"
                    Dim pInfo As ReportParameterInfoCollection
                    Dim paramList As New Generic.List(Of ReportParameter)
                    paramList.Add(New ReportParameter("AgreementID", AgreementID, False))
                    paramList.Add(New ReportParameter("BrokerID", BrokerID, False))
                    ReportViewer1.ServerReport.SetParameters(paramList)
                    pInfo = ReportViewer1.ServerReport.GetParameters()
                Else
                    ddlChooseForm.Items(0).Selected = False
                    ddlChooseForm.Items(1).Selected = False
                    ddlChooseForm.Items(2).Selected = False
                    ddlChooseForm.Items(3).Selected = False
                End If
            End If
        End If
            ReportViewer1.ServerReport.Refresh()
    End Sub

    Protected Sub ddlChooseForm_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlChooseForm.SelectedIndexChanged
        AgreementID = Session("AgreementID")
        BrokerID = Session("BrokerID")
        If ddlChooseForm.Items(1).Selected Then
            ReportViewer1.ServerReport.ReportPath = "/Form500"
            Dim pInfo As ReportParameterInfoCollection
            Dim paramList As New Generic.List(Of ReportParameter)
            paramList.Add(New ReportParameter("AgreementID", AgreementID, False))
            paramList.Add(New ReportParameter("BrokerID", BrokerID, False))
            ReportViewer1.ServerReport.SetParameters(paramList)
            pInfo = ReportViewer1.ServerReport.GetParameters()
            '' Process and render the report
            'ReportViewer1.ServerReport.Refresh()
        Else
            If ddlChooseForm.Items(2).Selected Then
                ReportViewer1.ServerReport.ReportPath = "/Form501"
                Dim pInfo As ReportParameterInfoCollection
                Dim paramList As New Generic.List(Of ReportParameter)
                paramList.Add(New ReportParameter("AgreementID", AgreementID, False))
                paramList.Add(New ReportParameter("BrokerID", BrokerID, False))
                ReportViewer1.ServerReport.SetParameters(paramList)
                pInfo = ReportViewer1.ServerReport.GetParameters()
            Else
                If ddlChooseForm.Items(3).Selected Then
                    ReportViewer1.ServerReport.ReportPath = "/Form502"
                    Dim pInfo As ReportParameterInfoCollection
                    Dim paramList As New Generic.List(Of ReportParameter)
                    paramList.Add(New ReportParameter("AgreementID", AgreementID, False))
                    paramList.Add(New ReportParameter("BrokerID", BrokerID, False))
                    ReportViewer1.ServerReport.SetParameters(paramList)
                    pInfo = ReportViewer1.ServerReport.GetParameters()
                Else
                    'If rbtnliChooseForm.Items(3).Selected Then
                    '    ReportViewer1.ServerReport.ReportPath = "/Form503"
                    'Else
                    'If rbtnliChooseForm.Items(4) Then
                    ReportViewer1.ServerReport.ReportPath = "/Form504"
                    Dim pInfo As ReportParameterInfoCollection
                    Dim paramList As New Generic.List(Of ReportParameter)
                    paramList.Add(New ReportParameter("AgreementID", AgreementID, False))
                    paramList.Add(New ReportParameter("BrokerID", BrokerID, False))
                    ReportViewer1.ServerReport.SetParameters(paramList)
                    pInfo = ReportViewer1.ServerReport.GetParameters()
                End If
            End If
        End If
        'End If
        'End If
        ' Process and render the report
        ReportViewer1.ServerReport.Refresh()
    End Sub
End Class
