Imports RenewalStatementWebSvc.ReportingService2005
Imports microsoft.reporting.webforms

Partial Class Broker_Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim BrokerID As String = Profile.BrokerID
        Dim parm1(0) As ReportParameter
        parm1(0) = New Microsoft.Reporting.WebForms.ReportParameter("BrokerID", BrokerID)
        ReportViewer1.ServerReport.SetParameters(parm1)
        ReportViewer1.ShowParameterPrompts = False
    End Sub
End Class
