
Partial Class Createaccount
    Inherits System.Web.UI.Page

   
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub CreateUserWizard1_CreatedUser(ByVal sender As Object, ByVal e As System.EventArgs) Handles CreateUserWizard1.CreatedUser
        CDataFunctions.emailNewUser(CreateUserWizard1.UserName)
        If Not (Roles.IsUserInRole(CreateUserWizard1.UserName, "Unverified")) Then
            Roles.AddUserToRole(CreateUserWizard1.UserName, "Unverified")
        End If
        FormsAuthentication.SetAuthCookie(CreateUserWizard1.UserName, False)
        Response.Redirect("/CTPA/Login.aspx")
    End Sub
End Class
